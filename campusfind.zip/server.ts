import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcryptjs';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import {
  db,
  initDatabase,
  mapLifecycleToStatus,
  mapStatusToLifecycle,
  normalizeDomain,
  recordStudentActivity,
  type CollegeRow,
  type ItemLifecycleStatus,
  type UserRow,
  type ItemRow,
} from './src/server/db.ts';
import { requireAuth, requireAdmin, signAuthToken, verifyAuthToken, type AuthPayload } from './src/server/auth.ts';
import { compareDevicePairWithAI } from './src/server/aiMatcher.ts';
import {
  broadcastToCollege,
  broadcastToUser,
  registerRealtimeClient,
} from './src/server/realtime.ts';

initDatabase();

const app = express();
app.use(express.json({ limit: '6mb' }));
app.use(cookieParser());

const VALID_LIFECYCLE: ItemLifecycleStatus[] = [
  'submitted',
  'under_review',
  'possible_match',
  'verified',
  'recovered',
  'closed',
];

function sanitizeCollege(c: CollegeRow, includeAdminMeta = false) {
  let zones: string[] = [];
  let departments: string[] = [];
  let academicYears: string[] = [];
  try {
    zones = JSON.parse(c.zones_json);
  } catch {
    zones = [];
  }
  try {
    departments = JSON.parse(c.departments_json || '[]');
  } catch {
    departments = [];
  }
  try {
    academicYears = JSON.parse(c.academic_years_json || '[]');
  } catch {
    academicYears = [];
  }
  return {
    id: c.id,
    code: c.code,
    name: c.name,
    city: c.city,
    address: c.address,
    domain: c.domain,
    ...(includeAdminMeta
      ? {
          adminEmail: c.admin_email || '',
          studentAccessEnabled: Boolean(c.student_access_enabled),
          hasInitialPassword: Boolean(c.initial_student_password_hash),
        }
      : {
          studentAccessEnabled: Boolean(c.student_access_enabled),
        }),
    latitude: c.latitude,
    longitude: c.longitude,
    mapsUrl: c.maps_url,
    isPrimary: Boolean(c.is_primary),
    zones,
    departments,
    academicYears,
  };
}

function sanitizeUser(u: UserRow, college: CollegeRow) {
  return {
    id: u.id,
    collegeId: u.college_id,
    collegeCode: college.code,
    role: u.role,
    identifier: u.identifier,
    studentId: u.student_id,
    fullName: u.full_name,
    department: u.department,
    academicYear: u.academic_year || '',
    firstLoginCompleted: Boolean(u.first_login_completed),
    profileCompleted: Boolean(u.profile_completed),
  };
}

function createNotification(
  collegeId: number,
  userId: number,
  title: string,
  message: string,
  relatedMatchId: number | null = null,
  options?: {
    notificationType?: string;
    relatedLostItemId?: number | null;
    relatedFoundItemId?: number | null;
  }
) {
  const nType = options?.notificationType || 'system';
  const lostId = options?.relatedLostItemId ?? null;
  const foundId = options?.relatedFoundItemId ?? null;

  const res = db
    .prepare(
      `INSERT INTO notifications (
         college_id, user_id, title, message, related_match_id,
         notification_type, related_lost_item_id, related_found_item_id
       )
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(collegeId, userId, title, message, relatedMatchId, nType, lostId, foundId);

  const notification = db
    .prepare(
      `SELECT id, title, message, related_match_id, notification_type,
              related_lost_item_id, related_found_item_id, is_read, created_at
       FROM notifications WHERE id = ?`
    )
    .get(Number(res.lastInsertRowid));

  broadcastToUser(collegeId, userId, 'notification:created', { notification });
  return notification;
}

function lifecycleLabel(lc: ItemLifecycleStatus): string {
  switch (lc) {
    case 'submitted':
      return 'Submitted';
    case 'under_review':
      return 'Under Review';
    case 'possible_match':
      return 'Possible Match';
    case 'verified':
      return 'Verified';
    case 'recovered':
      return 'Recovered';
    case 'closed':
      return 'Closed';
  }
}

// Runtime Maps browser key discovery (reads injected Maps env var without hardcoding)
app.get('/api/config/maps', (_req, res) => {
  const apiKey =
    process.env.VITE_GOOGLE_MAPS_API_KEY ||
    process.env.GOOGLE_MAPS_API_KEY ||
    '';
  const configured = Boolean(apiKey && apiKey !== 'MY_GOOGLE_MAPS_API_KEY');
  res.json({ apiKey: configured ? apiKey : '', configured });
});

// Real-time Server-Sent Events (SSE) stream strictly scoped by authenticated collegeId & userId/role
app.get('/api/realtime/stream', (req, res) => {
  const authHeader = req.headers.authorization;
  const bearerToken = authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;
  const cookieToken = req.cookies?.cf_token as string | undefined;
  const queryToken = typeof req.query.token === 'string' ? req.query.token.trim() : null;
  const token = bearerToken || cookieToken || queryToken;

  if (!token) {
    res.status(401).json({ error: 'Authentication required for live updates.' });
    return;
  }

  const payload = verifyAuthToken(token);
  if (!payload) {
    res.status(401).json({ error: 'Session expired or invalid.' });
    return;
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();

  const cleanup = registerRealtimeClient(payload.collegeId, payload.userId, payload.role, res);

  req.on('close', () => {
    cleanup();
  });
});

// Public endpoint: college list for login selector (primary institution first; zero statistics or credentials)
app.get('/api/colleges', (_req, res) => {
  const colleges = db
    .prepare('SELECT * FROM colleges ORDER BY is_primary DESC, name ASC')
    .all() as CollegeRow[];
  res.json({
    colleges: colleges.map((c) => sanitizeCollege(c)),
  });
});

// Authentication: Student Login & College Admin Login
app.post('/api/auth/login', (req, res) => {
  const { collegeCode, identifier, password, role, rememberMe } = req.body ?? {};

  if (role !== 'user' && role !== 'admin') {
    res.status(400).json({ error: 'Invalid login role. Only Student Login and College Admin are supported.' });
    return;
  }

  if (!collegeCode || !identifier || !password) {
    res.status(400).json({ error: 'Please select your college and enter both your college email ID and password.' });
    return;
  }

  const normalizedCollegeCode = String(collegeCode).trim().toUpperCase();
  const normalizedIdentifier = String(identifier).trim().toLowerCase();

  const college = db
    .prepare('SELECT * FROM colleges WHERE UPPER(code) = ?')
    .get(normalizedCollegeCode) as CollegeRow | undefined;

  if (!college) {
    res.status(401).json({ error: 'Selected college institution was not found.' });
    return;
  }

  // Strict MSAJCE-only active institution policy enforced on backend
  if (college.code.toUpperCase() !== 'MSAJCE') {
    res.status(403).json({
      error: `${college.name} is currently disabled. Only Mohamed Sathak A.J. College of Engineering and Architecture (MSAJCE) is active.`,
    });
    return;
  }

  const plainPassword = String(password);
  let user: UserRow | undefined;

  if (role === 'user') {
    if (!college.student_access_enabled) {
      res.status(403).json({
        error: `Student portal access is currently disabled by ${college.name} administration.`,
      });
      return;
    }

    // Flexible local-part validation with exact @msajce-edu.in domain match
    const requiredDomain = normalizeDomain(college.domain);
    const emailParts = normalizedIdentifier.split('@');
    const localPart = emailParts[0] || '';
    const domainPart = emailParts[1] || '';
    const validLocalPattern = /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+$/i;

    if (
      emailParts.length !== 2 ||
      localPart.length === 0 ||
      localPart.length > 64 ||
      !validLocalPattern.test(localPart) ||
      domainPart !== requiredDomain
    ) {
      res.status(400).json({
        error: `Please enter a valid college email ending with @${requiredDomain} (for example: username@${requiredDomain}).`,
      });
      return;
    }

    user = db
      .prepare(
        `SELECT * FROM users
         WHERE college_id = ? AND role = 'user' AND LOWER(identifier) = ?`
      )
      .get(college.id, normalizedIdentifier) as UserRow | undefined;

    if (user) {
      if (!user.is_authorized) {
        res.status(403).json({
          error: 'Your student account access has been paused by your college administrator.',
        });
        return;
      }

      const matchesPersonalPassword = bcrypt.compareSync(plainPassword, user.password_hash);
      const matchesBootstrapPassword =
        !user.first_login_completed &&
        Boolean(college.initial_student_password_hash) &&
        bcrypt.compareSync(plainPassword, college.initial_student_password_hash);

      if (!matchesPersonalPassword && !matchesBootstrapPassword) {
        res.status(401).json({
          error: 'Incorrect password for this student account.',
        });
        return;
      }
    } else {
      // Flexible username onboarding using MSAJCE's configured hashed initial student password
      const matchesBootstrapPassword =
        Boolean(college.initial_student_password_hash) &&
        bcrypt.compareSync(plainPassword, college.initial_student_password_hash);

      if (!matchesBootstrapPassword) {
        res.status(401).json({
          error: 'Incorrect student password for MSAJCE.',
        });
        return;
      }

      const displayName = localPart
        .split(/[._-]+/)
        .filter(Boolean)
        .map((seg) => seg.charAt(0).toUpperCase() + seg.slice(1))
        .join(' ') || localPart;

      const created = db
        .prepare(
          `INSERT INTO users (college_id, role, identifier, student_id, full_name, department, password_hash, first_login_completed, is_authorized)
           VALUES (?, 'user', ?, NULL, ?, 'MSAJCE Student', ?, 0, 1)`
        )
        .run(college.id, normalizedIdentifier, displayName, college.initial_student_password_hash);

      user = db
        .prepare('SELECT * FROM users WHERE id = ?')
        .get(Number(created.lastInsertRowid)) as UserRow;
    }
  } else {
    user = db
      .prepare(
        `SELECT * FROM users
         WHERE college_id = ? AND role = 'admin'
         AND (LOWER(identifier) = ? OR LOWER(COALESCE(student_id, '')) = ?)`
      )
      .get(college.id, normalizedIdentifier, normalizedIdentifier) as UserRow | undefined;

    if (!user || !bcrypt.compareSync(plainPassword, user.password_hash)) {
      res.status(401).json({
        error: 'Invalid college administrator credentials for MSAJCE.',
      });
      return;
    }
  }

  // Record genuine student login event in backend activity log
  if (user.role === 'user') {
    recordStudentActivity({
      collegeId: college.id,
      userId: user.id,
      studentEmail: user.identifier,
      actionType: 'login',
      summary: 'Signed in to CampusFind student portal',
    });
    broadcastToCollege(college.id, 'activity:created', {
      studentEmail: user.identifier,
      actionType: 'login',
    });
  }

  const payload: AuthPayload = {
    userId: user.id,
    collegeId: college.id,
    collegeCode: college.code,
    role: user.role,
    identifier: user.identifier,
    fullName: user.full_name,
  };

  const token = signAuthToken(payload);
  const maxAge = rememberMe ? 7 * 24 * 60 * 60 * 1000 : 12 * 60 * 60 * 1000;

  res.cookie('cf_token', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge,
  });

  res.json({
    token,
    user: sanitizeUser(user, college),
    college: sanitizeCollege(college, role === 'admin'),
  });
});

// First-login password setup (YES – Change Password)
app.post('/api/auth/first-login-password', requireAuth, (req, res) => {
  const auth = req.auth!;
  const { email, newPassword, confirmPassword } = req.body ?? {};

  if (!newPassword || !confirmPassword) {
    res.status(400).json({ error: 'New Password and Confirm New Password are required.' });
    return;
  }

  if (String(newPassword) !== String(confirmPassword)) {
    res.status(400).json({ error: 'New Password and Confirm New Password do not match.' });
    return;
  }

  if (String(newPassword).length < 8) {
    res.status(400).json({ error: 'New password must be at least 8 characters long.' });
    return;
  }

  const user = db
    .prepare('SELECT * FROM users WHERE id = ? AND college_id = ?')
    .get(auth.userId, auth.collegeId) as UserRow | undefined;
  const college = db.prepare('SELECT * FROM colleges WHERE id = ?').get(auth.collegeId) as CollegeRow | undefined;

  if (!user || !college) {
    res.status(404).json({ error: 'Student account not found.' });
    return;
  }

  if (email && String(email).trim().toLowerCase() !== user.identifier.toLowerCase()) {
    res.status(403).json({
      error: 'The entered College Email ID does not match your signed-in student account.',
    });
    return;
  }

  const nextHash = bcrypt.hashSync(String(newPassword), 10);
  db.prepare(`UPDATE users SET password_hash = ?, first_login_completed = 1 WHERE id = ?`).run(nextHash, user.id);

  recordStudentActivity({
    collegeId: college.id,
    userId: user.id,
    studentEmail: user.identifier,
    actionType: 'password_changed',
    summary: 'Updated personal password during first-login security prompt',
  });
  broadcastToCollege(college.id, 'activity:created', {
    studentEmail: user.identifier,
    actionType: 'password_changed',
  });

  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id) as UserRow;
  res.json({ ok: true, user: sanitizeUser(updated, college) });
});

// First-login skip (NO – Continue with initial password)
app.post('/api/auth/first-login-skip', requireAuth, (req, res) => {
  const auth = req.auth!;
  db.prepare(`UPDATE users SET first_login_completed = 1 WHERE id = ? AND college_id = ?`).run(
    auth.userId,
    auth.collegeId
  );

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(auth.userId) as UserRow | undefined;
  const college = db.prepare('SELECT * FROM colleges WHERE id = ?').get(auth.collegeId) as CollegeRow | undefined;
  if (!user || !college) {
    res.status(404).json({ error: 'Account not found.' });
    return;
  }

  res.json({ ok: true, user: sanitizeUser(user, college) });
});

// Forgot password institutional request
app.post('/api/auth/forgot-password', (req, res) => {
  const { collegeCode, identifier } = req.body ?? {};
  if (!collegeCode || !identifier) {
    res.status(400).json({ error: 'Please provide both your institution and college email ID.' });
    return;
  }
  db.prepare(
    `INSERT INTO password_reset_requests (college_code, identifier) VALUES (?, ?)`
  ).run(String(collegeCode).trim().toUpperCase(), String(identifier).trim().toLowerCase());

  res.json({
    ok: true,
    message:
      'Password reset request logged with your College Administration Desk. If an authorized account matches, instructions will be provided.',
  });
});

// Student self-registration is explicitly disabled (authorized via college administration only)
app.post('/api/auth/register-student', (_req, res) => {
  res.status(403).json({
    error: 'Self-registration is disabled. Student accounts must be authorized by your college administrator.',
  });
});

app.post('/api/auth/logout', (_req, res) => {
  res.clearCookie('cf_token');
  res.json({ ok: true });
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  const auth = req.auth!;
  const user = db.prepare('SELECT * FROM users WHERE id = ? AND college_id = ?').get(auth.userId, auth.collegeId) as
    | UserRow
    | undefined;
  const college = db.prepare('SELECT * FROM colleges WHERE id = ?').get(auth.collegeId) as CollegeRow | undefined;

  if (!user || !college) {
    res.status(401).json({ error: 'Account no longer exists.' });
    return;
  }

  res.json({
    user: sanitizeUser(user, college),
    college: sanitizeCollege(college),
  });
});

// Mandatory student profile completion after first login (YES or NO password choice)
app.post('/api/profile/complete', requireAuth, (req, res) => {
  const auth = req.auth!;
  const { fullName, department, academicYear } = req.body ?? {};

  const cleanName = typeof fullName === 'string' ? fullName.trim() : '';
  const cleanDept = typeof department === 'string' ? department.trim() : '';
  const cleanYear = typeof academicYear === 'string' ? academicYear.trim() : '';

  if (!cleanName || !cleanDept || !cleanYear) {
    res.status(400).json({
      error: 'Student Name, Department, and Academic Year are all mandatory.',
    });
    return;
  }

  db.prepare(
    `UPDATE users
     SET full_name = ?, department = ?, academic_year = ?, profile_completed = 1, first_login_completed = 1
     WHERE id = ? AND college_id = ?`
  ).run(cleanName, cleanDept, cleanYear, auth.userId, auth.collegeId);

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(auth.userId) as UserRow;
  const college = db.prepare('SELECT * FROM colleges WHERE id = ?').get(auth.collegeId) as CollegeRow;

  res.json({ ok: true, user: sanitizeUser(user, college) });
});

// Update authenticated user profile
app.patch('/api/profile', requireAuth, (req, res) => {
  const auth = req.auth!;
  const { fullName, department, academicYear } = req.body ?? {};
  if (!fullName || !String(fullName).trim()) {
    res.status(400).json({ error: 'Full name cannot be empty.' });
    return;
  }

  const existing = db.prepare('SELECT academic_year FROM users WHERE id = ?').get(auth.userId) as
    | { academic_year: string }
    | undefined;
  const nextYear =
    typeof academicYear === 'string' && academicYear.trim()
      ? academicYear.trim()
      : existing?.academic_year || '';

  db.prepare(
    `UPDATE users SET full_name = ?, department = ?, academic_year = ? WHERE id = ? AND college_id = ?`
  ).run(
    String(fullName).trim(),
    department ? String(department).trim() : 'General Studies',
    nextYear,
    auth.userId,
    auth.collegeId
  );

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(auth.userId) as UserRow;
  const college = db.prepare('SELECT * FROM colleges WHERE id = ?').get(auth.collegeId) as CollegeRow;

  res.json({ user: sanitizeUser(user, college) });
});

// Admin: Update institution settings (campus zones & address)
app.patch('/api/institution', requireAuth, requireAdmin, (req, res) => {
  const auth = req.auth!;
  const { address, zones, mapsUrl } = req.body ?? {};
  const college = db.prepare('SELECT * FROM colleges WHERE id = ?').get(auth.collegeId) as CollegeRow | undefined;
  if (!college) {
    res.status(404).json({ error: 'Institution not found.' });
    return;
  }

  const cleanZones = Array.isArray(zones)
    ? zones.map((z) => String(z).trim()).filter(Boolean)
    : JSON.parse(college.zones_json || '[]');
  const cleanAddress = typeof address === 'string' && address.trim() ? address.trim() : college.address;
  const cleanMapsUrl = typeof mapsUrl === 'string' ? mapsUrl.trim() : college.maps_url;

  db.prepare(`UPDATE colleges SET address = ?, zones_json = ?, maps_url = ? WHERE id = ?`).run(
    cleanAddress,
    JSON.stringify(cleanZones),
    cleanMapsUrl,
    auth.collegeId
  );

  const updated = db.prepare('SELECT * FROM colleges WHERE id = ?').get(auth.collegeId) as CollegeRow;
  const sanitized = sanitizeCollege(updated);
  broadcastToCollege(auth.collegeId, 'institution:updated', { college: sanitized });
  res.json({ college: sanitized });
});

// Live database-driven dashboard summary
app.get('/api/dashboard/summary', requireAuth, (req, res) => {
  const auth = req.auth!;
  const collegeId = auth.collegeId;

  const counts = db
    .prepare(
      `SELECT
         SUM(CASE WHEN type = 'missing' AND status != 'archived' THEN 1 ELSE 0 END) as missingTotal,
         SUM(CASE WHEN type = 'missing' AND status = 'open' THEN 1 ELSE 0 END) as missingOpen,
         SUM(CASE WHEN type = 'found' AND status != 'archived' THEN 1 ELSE 0 END) as foundTotal,
         SUM(CASE WHEN type = 'found' AND status = 'open' THEN 1 ELSE 0 END) as foundOpen,
         SUM(CASE WHEN status = 'resolved' OR lifecycle_status = 'recovered' THEN 1 ELSE 0 END) as resolvedItems,
         SUM(CASE WHEN lifecycle_status IN ('submitted', 'under_review') AND status != 'archived' THEN 1 ELSE 0 END) as pendingVerification
       FROM items
       WHERE college_id = ?`
    )
    .get(collegeId) as {
    missingTotal: number | null;
    missingOpen: number | null;
    foundTotal: number | null;
    foundOpen: number | null;
    resolvedItems: number | null;
    pendingVerification: number | null;
  };

  const myCounts = db
    .prepare(
      `SELECT
         SUM(CASE WHEN type = 'missing' AND status != 'archived' THEN 1 ELSE 0 END) as myLostCount,
         SUM(CASE WHEN type = 'found' AND status != 'archived' THEN 1 ELSE 0 END) as myFoundCount,
         SUM(CASE WHEN status = 'resolved' OR lifecycle_status = 'recovered' THEN 1 ELSE 0 END) as myRecoveredCount
       FROM items
       WHERE college_id = ? AND reporter_user_id = ?`
    )
    .get(collegeId, auth.userId) as {
    myLostCount: number | null;
    myFoundCount: number | null;
    myRecoveredCount: number | null;
  };

  const matchCounts = db
    .prepare(
      `SELECT
         COUNT(*) as totalMatches,
         SUM(CASE WHEN status IN ('pending', 'verified') THEN 1 ELSE 0 END) as activeMatches,
         SUM(CASE WHEN status = 'claimed' THEN 1 ELSE 0 END) as claimedMatches
       FROM matches
       WHERE college_id = ?`
    )
    .get(collegeId) as {
    totalMatches: number | null;
    activeMatches: number | null;
    claimedMatches: number | null;
  };

  const memberCount = db
    .prepare(`SELECT COUNT(*) as count FROM users WHERE college_id = ? AND role = 'user'`)
    .get(collegeId) as { count: number };

  const unreadNotif = db
    .prepare(`SELECT COUNT(*) as count FROM notifications WHERE college_id = ? AND user_id = ? AND is_read = 0`)
    .get(collegeId, auth.userId) as { count: number };

  const totalActiveReports = (counts.missingTotal ?? 0) + (counts.foundTotal ?? 0);
  const resolved = counts.resolvedItems ?? 0;
  const recoveryRate = totalActiveReports > 0 ? Math.round((resolved / totalActiveReports) * 100) : 0;

  res.json({
    stats: {
      missingTotal: counts.missingTotal ?? 0,
      missingOpen: counts.missingOpen ?? 0,
      foundTotal: counts.foundTotal ?? 0,
      foundOpen: counts.foundOpen ?? 0,
      resolvedItems: resolved,
      pendingVerification: counts.pendingVerification ?? 0,
      recoveryRate,
      activeMatches: matchCounts.activeMatches ?? 0,
      claimedMatches: matchCounts.claimedMatches ?? 0,
      totalMatches: matchCounts.totalMatches ?? 0,
      registeredStudents: memberCount.count ?? 0,
      myLostCount: myCounts.myLostCount ?? 0,
      myFoundCount: myCounts.myFoundCount ?? 0,
      myRecoveredCount: myCounts.myRecoveredCount ?? 0,
      unreadNotifications: unreadNotif.count ?? 0,
    },
  });
});

// Fetch missing or found devices strictly for authenticated college
app.get('/api/items', requireAuth, (req, res) => {
  const auth = req.auth!;
  const collegeId = auth.collegeId;
  const typeFilter = req.query.type === 'missing' || req.query.type === 'found' ? req.query.type : null;
  const statusFilter =
    req.query.status === 'open' ||
    req.query.status === 'matched' ||
    req.query.status === 'resolved' ||
    req.query.status === 'archived'
      ? req.query.status
      : null;
  const lifecycleFilter =
    typeof req.query.lifecycle === 'string' && VALID_LIFECYCLE.includes(req.query.lifecycle as ItemLifecycleStatus)
      ? req.query.lifecycle
      : null;
  const mineOnly = req.query.mine === 'true';
  const search = typeof req.query.search === 'string' ? req.query.search.trim().toLowerCase() : '';

  let sql = `
    SELECT
      i.*,
      u.full_name as reporter_name,
      u.identifier as reporter_identifier,
      u.department as reporter_department
    FROM items i
    JOIN users u ON u.id = i.reporter_user_id
    WHERE i.college_id = ?
  `;
  const params: (string | number)[] = [collegeId];

  if (mineOnly) {
    sql += ' AND i.reporter_user_id = ?';
    params.push(auth.userId);
  }
  if (typeFilter) {
    sql += ' AND i.type = ?';
    params.push(typeFilter);
  }
  if (statusFilter) {
    sql += ' AND i.status = ?';
    params.push(statusFilter);
  }
  if (lifecycleFilter) {
    sql += ' AND i.lifecycle_status = ?';
    params.push(lifecycleFilter);
  }
  if (search) {
    sql +=
      ' AND (LOWER(i.title) LIKE ? OR LOWER(i.brand) LIKE ? OR LOWER(i.model) LIKE ? OR LOWER(i.location) LIKE ? OR LOWER(i.device_type) LIKE ? OR LOWER(i.description) LIKE ? OR LOWER(i.report_code) LIKE ?)';
    const like = `%${search}%`;
    params.push(like, like, like, like, like, like, like);
  }

  sql += ' ORDER BY i.id DESC';

  const rows = db.prepare(sql).all(...params) as Array<Record<string, unknown>>;
  const sanitized =
    auth.role === 'admin'
      ? rows
      : rows.map((row) =>
          row.reporter_user_id === auth.userId
            ? row
            : { ...row, reporter_identifier: '' }
        );
  res.json({ items: sanitized });
});

// Complete genuine device & public finder details (strictly same institution, privacy-safe)
app.get('/api/items/:id/details', requireAuth, (req, res) => {
  const auth = req.auth!;
  const itemId = Number(req.params.id);
  const row = db
    .prepare(
      `SELECT
         i.*,
         u.full_name as reporter_name,
         u.department as reporter_department,
         u.academic_year as reporter_academic_year,
         c.name as institution_name,
         c.code as institution_code
       FROM items i
       JOIN users u ON u.id = i.reporter_user_id
       JOIN colleges c ON c.id = i.college_id
       WHERE i.id = ? AND i.college_id = ?`
    )
    .get(itemId, auth.collegeId) as (ItemRow & {
      reporter_name: string;
      reporter_department: string;
      reporter_academic_year: string;
      institution_name: string;
      institution_code: string;
    }) | undefined;

  if (!row) {
    res.status(404).json({ error: 'Device report not found in your institution.' });
    return;
  }

  res.json({
    details: {
      id: row.id,
      reportCode: row.report_code || `CF-${row.institution_code}-${String(row.id).padStart(4, '0')}`,
      type: row.type,
      title: row.title,
      category: row.category,
      deviceType: row.device_type,
      brand: row.brand || '',
      model: row.model || '',
      color: row.color || '',
      description: row.description,
      additionalInfo: row.additional_info || '',
      imageData: row.image_data || null,
      location: row.location || '',
      latitude: row.latitude,
      longitude: row.longitude,
      reportedDate: row.reported_date,
      reportedTime: row.reported_time || '',
      lifecycleStatus: row.lifecycle_status,
      status: row.status,
      createdAt: row.created_at,
      institutionName: row.institution_name,
      institutionCode: row.institution_code,
      reporter: {
        name: row.reporter_name || 'Student',
        department: row.reporter_department || '',
        academicYear: row.reporter_academic_year || '',
      },
    },
  });
});

// Create a new lost or found device report with color/brand/model/time/coordinates/image + intelligent multi-signal matching
app.post('/api/items', requireAuth, async (req, res) => {
  const auth = req.auth!;
  const {
    type,
    title,
    category,
    deviceType,
    brand,
    model,
    color,
    location,
    latitude,
    longitude,
    description,
    additionalInfo,
    reportedDate,
    reportedTime,
    imageData,
  } = req.body ?? {};

  if (type !== 'missing' && type !== 'found') {
    res.status(400).json({ error: 'Report type must be either missing or found.' });
    return;
  }
  if (!title || !description) {
    res.status(400).json({ error: 'Device title and identifying details are required.' });
    return;
  }

  const cleanImage =
    typeof imageData === 'string' && imageData.startsWith('data:image/') && imageData.length <= 4_500_000
      ? imageData
      : null;

  const college = db.prepare('SELECT * FROM colleges WHERE id = ?').get(auth.collegeId) as CollegeRow;
  const latNum = typeof latitude === 'number' && Number.isFinite(latitude) ? latitude : null;
  const lngNum = typeof longitude === 'number' && Number.isFinite(longitude) ? longitude : null;
  const cleanDeviceType = deviceType ? String(deviceType).trim() : 'Smartphone';
  const cleanCategory = category ? String(category).trim() : 'Electronics';
  const cleanBrand = brand ? String(brand).trim() : '';
  const cleanModel = model ? String(model).trim() : '';
  const cleanColor = color ? String(color).trim() : '';
  const cleanAdditional = additionalInfo ? String(additionalInfo).trim() : '';
  const cleanDate = reportedDate ? String(reportedDate).slice(0, 10) : new Date().toISOString().slice(0, 10);
  const cleanTime = reportedTime ? String(reportedTime).slice(0, 16) : '';

  const insertResult = db
    .prepare(
      `INSERT INTO items (
         college_id, reporter_user_id, type, title, category, device_type, brand, model, color,
         location, latitude, longitude, description, additional_info, image_data,
         status, lifecycle_status, reported_date, reported_time
       )
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'open', 'submitted', ?, ?)`
    )
    .run(
      auth.collegeId,
      auth.userId,
      type,
      String(title).trim(),
      cleanCategory,
      cleanDeviceType,
      cleanBrand,
      cleanModel,
      cleanColor,
      location ? String(location).trim() : '',
      latNum,
      lngNum,
      String(description).trim(),
      cleanAdditional,
      cleanImage,
      cleanDate,
      cleanTime
    );

  const newItemId = Number(insertResult.lastInsertRowid);
  const reportCode = `CF-${college.code}-${String(newItemId).padStart(4, '0')}`;
  db.prepare(`UPDATE items SET report_code = ? WHERE id = ?`).run(reportCode, newItemId);

  if (auth.role === 'user') {
    recordStudentActivity({
      collegeId: auth.collegeId,
      userId: auth.userId,
      studentEmail: auth.identifier,
      actionType: type === 'missing' ? 'lost_report_submitted' : 'found_report_submitted',
      summary: `Submitted ${type === 'missing' ? 'lost' : 'found'} device report "${String(title).trim()}" (${reportCode})`,
      relatedItemId: newItemId,
    });
    broadcastToCollege(auth.collegeId, 'activity:created', {
      studentEmail: auth.identifier,
      actionType: type === 'missing' ? 'lost_report_submitted' : 'found_report_submitted',
      relatedItemId: newItemId,
    });
  }

  const newItem = db.prepare('SELECT * FROM items WHERE id = ?').get(newItemId) as ItemRow;

  // Intelligent multi-signal matching across different accounts within the same institution
  // NEVER matches on device category alone — requires corroborating brand/model/color/description/location signals
  const oppositeType = type === 'missing' ? 'found' : 'missing';
  const candidates = db
    .prepare(
      `SELECT * FROM items
       WHERE college_id = ?
         AND type = ?
         AND status IN ('open', 'matched')
         AND LOWER(device_type) = LOWER(?)`
    )
    .all(auth.collegeId, oppositeType, cleanDeviceType) as ItemRow[];

  const STOPWORDS = new Set([
    'the', 'and', 'for', 'with', 'near', 'from', 'that', 'this', 'have', 'lost', 'found',
    'missing', 'device', 'phone', 'mobile', 'laptop', 'tablet', 'watch', 'earbuds', 'college',
  ]);
  const tokenize = (s: string) =>
    Array.from(
      new Set(
        s
          .toLowerCase()
          .split(/[^a-z0-9]+/)
          .filter((w) => w.length >= 3 && !STOPWORDS.has(w))
      )
    );

  const scorePair = (a: ItemRow, b: ItemRow): { score: number; corroboration: number; reasons: string[] } => {
    let corroboration = 0;
    const reasons: string[] = [];

    const brandA = (a.brand || '').trim().toLowerCase();
    const brandB = (b.brand || '').trim().toLowerCase();
    if (brandA && brandB && (brandA === brandB || brandA.includes(brandB) || brandB.includes(brandA))) {
      corroboration += 30;
      reasons.push(`brand (${a.brand})`);
    } else if (brandA && brandB && brandA !== brandB) {
      // Conflicting explicit brands strongly penalize match likelihood
      corroboration -= 30;
    }

    const modelA = (a.model || '').trim().toLowerCase();
    const modelB = (b.model || '').trim().toLowerCase();
    if (modelA && modelB) {
      const mTokA = tokenize(modelA);
      const mTokB = new Set(tokenize(modelB));
      const mOverlap = mTokA.filter((t) => mTokB.has(t)).length;
      if (modelA === modelB || modelA.includes(modelB) || modelB.includes(modelA) || mOverlap > 0) {
        corroboration += 28;
        reasons.push(`model (${a.model})`);
      }
    }

    const colorA = (a.color || '').trim().toLowerCase();
    const colorB = (b.color || '').trim().toLowerCase();
    if (colorA && colorB && (colorA === colorB || colorA.includes(colorB) || colorB.includes(colorA))) {
      corroboration += 20;
      reasons.push(`colour (${a.color})`);
    } else if (colorA && colorB && colorA !== colorB) {
      corroboration -= 15;
    }

    const locA = tokenize(a.location || '');
    const locB = new Set(tokenize(b.location || ''));
    const locOverlap = locA.filter((t) => locB.has(t)).length;
    if (locOverlap > 0) {
      corroboration += 14;
      reasons.push('campus location');
    }

    const descA = tokenize(`${a.title} ${a.description} ${a.additional_info || ''}`);
    const descB = new Set(tokenize(`${b.title} ${b.description} ${b.additional_info || ''}`));
    const descOverlap = descA.filter((t) => descB.has(t)).length;
    if (descOverlap > 0) {
      corroboration += Math.min(22, descOverlap * 7);
      reasons.push('identifying details');
    }

    // Date proximity bonus (only adds weight if other corroborating signals exist)
    if (corroboration > 0 && a.reported_date && b.reported_date) {
      const da = Date.parse(a.reported_date);
      const dbTime = Date.parse(b.reported_date);
      if (Number.isFinite(da) && Number.isFinite(dbTime)) {
        const diffDays = Math.abs(da - dbTime) / (1000 * 60 * 60 * 24);
        if (diffDays <= 14) {
          corroboration += 8;
          reasons.push('date proximity');
        }
      }
    }

    const score = Math.min(96, Math.max(0, 22 + corroboration));
    return { score, corroboration, reasons };
  };

  let bestCandidate: ItemRow | null = null;
  let bestScore = 0;
  let bestReasons: string[] = [];

  for (const candidate of candidates) {
    const evaluated = scorePair(newItem, candidate);
    if (evaluated.corroboration >= 34 && evaluated.score > bestScore) {
      bestScore = evaluated.score;
      bestCandidate = candidate;
      bestReasons = evaluated.reasons;
    }
  }

  let matchNotes =
    bestReasons.length > 0
      ? `Possible match based on ${bestReasons.join(', ')}. Verify in person before claiming.`
      : 'Possible match identified. Verify in person before claiming.';

  // If images are available on either item and a candidate exists, refine via Gemini AI Vision
  if (bestCandidate && (newItem.image_data || bestCandidate.image_data) && process.env.GEMINI_API_KEY) {
    try {
      const missingRef = type === 'missing' ? newItem : bestCandidate;
      const foundRef = type === 'found' ? newItem : bestCandidate;
      const aiRes = await compareDevicePairWithAI(missingRef, foundRef);
      bestScore = aiRes.confidence;
      matchNotes = `AI Visual Analysis (${aiRes.confidence}%): ${aiRes.reasoning}`;
    } catch {
      // Retain deterministic multi-signal score if Gemini call is unavailable
    }
  }

  let createdMatchId: number | null = null;
  if (bestCandidate && bestScore >= 56) {
    const missingItem = type === 'missing' ? newItem : bestCandidate;
    const foundItem = type === 'found' ? newItem : bestCandidate;

    // Prevent duplicate match records & duplicate notifications for the same lost/found pair
    const existingMatch = db
      .prepare(
        `SELECT id FROM matches WHERE college_id = ? AND missing_item_id = ? AND found_item_id = ?`
      )
      .get(auth.collegeId, missingItem.id, foundItem.id) as { id: number } | undefined;

    if (!existingMatch) {
      const matchRes = db
        .prepare(
          `INSERT INTO matches (college_id, missing_item_id, found_item_id, confidence, status, workflow_status, notes)
           VALUES (?, ?, ?, ?, 'pending', 'POSSIBLE_MATCH', ?)`
        )
        .run(auth.collegeId, missingItem.id, foundItem.id, bestScore, matchNotes);
      createdMatchId = Number(matchRes.lastInsertRowid);

      // Classify as possible_match without ever auto-recovering or closing the lost report
      db.prepare(
        `UPDATE items SET status = 'matched', lifecycle_status = 'possible_match'
         WHERE id IN (?, ?) AND college_id = ? AND status = 'open'`
      ).run(missingItem.id, foundItem.id, auth.collegeId);

      // Notify the original lost-report owner with complete link to the found report
      createNotification(
        auth.collegeId,
        missingItem.reporter_user_id,
        'Possible Match Found for Your Lost Device',
        `Good news! A possible match for your lost device has been found. Found report: "${foundItem.title}"${foundItem.location ? ` at ${foundItem.location}` : ''}.`,
        createdMatchId,
        {
          notificationType: 'match_found',
          relatedLostItemId: missingItem.id,
          relatedFoundItemId: foundItem.id,
        }
      );

      broadcastToCollege(auth.collegeId, 'match:created', {
        matchId: createdMatchId,
        missingItemId: missingItem.id,
        foundItemId: foundItem.id,
        confidence: bestScore,
      });
    }
  }

  const created = db
    .prepare(
      `SELECT i.*, u.full_name as reporter_name, u.identifier as reporter_identifier, u.department as reporter_department
       FROM items i JOIN users u ON u.id = i.reporter_user_id WHERE i.id = ?`
    )
    .get(newItemId);

  broadcastToCollege(auth.collegeId, 'report:created', {
    item: created,
    autoMatchCreated: createdMatchId !== null,
    matchId: createdMatchId,
  });

  res.status(201).json({
    item: created,
    autoMatchCreated: createdMatchId !== null,
    matchId: createdMatchId,
  });
});

// Update item status / lifecycle status (strictly isolated to college + live SSE broadcast & student notification)
app.patch('/api/items/:id', requireAuth, (req, res) => {
  const auth = req.auth!;
  const itemId = Number(req.params.id);
  const { status, lifecycleStatus } = req.body ?? {};

  let nextLifecycle: ItemLifecycleStatus | null = null;
  let nextStatus: 'open' | 'matched' | 'resolved' | 'archived' | null = null;

  if (lifecycleStatus && VALID_LIFECYCLE.includes(lifecycleStatus)) {
    nextLifecycle = lifecycleStatus as ItemLifecycleStatus;
    nextStatus = mapLifecycleToStatus(nextLifecycle);
  } else if (status && ['open', 'matched', 'resolved', 'archived'].includes(status)) {
    nextStatus = status;
    nextLifecycle = mapStatusToLifecycle(status);
  } else {
    res.status(400).json({ error: 'Invalid status or lifecycle value.' });
    return;
  }

  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(itemId) as ItemRow | undefined;
  if (!item || item.college_id !== auth.collegeId) {
    res.status(404).json({ error: 'Device report not found in your college workspace.' });
    return;
  }

  if (auth.role !== 'admin' && item.reporter_user_id !== auth.userId) {
    res.status(403).json({ error: 'You can only update reports you submitted.' });
    return;
  }

  // Students can only mark their own report as recovered or closed
  if (auth.role !== 'admin' && !['recovered', 'closed', 'submitted'].includes(nextLifecycle)) {
    res.status(403).json({ error: 'Only college administrators can set verification statuses.' });
    return;
  }

  db.prepare('UPDATE items SET status = ?, lifecycle_status = ? WHERE id = ? AND college_id = ?').run(
    nextStatus,
    nextLifecycle,
    itemId,
    auth.collegeId
  );

  const updated = db
    .prepare(
      `SELECT i.*, u.full_name as reporter_name, u.identifier as reporter_identifier, u.department as reporter_department
       FROM items i JOIN users u ON u.id = i.reporter_user_id WHERE i.id = ?`
    )
    .get(itemId);

  // If admin updated a student's report, notify the student live
  if (auth.role === 'admin' && item.reporter_user_id !== auth.userId) {
    createNotification(
      auth.collegeId,
      item.reporter_user_id,
      `Report Status Updated: ${lifecycleLabel(nextLifecycle)}`,
      `Your ${item.type === 'missing' ? 'lost' : 'found'} device report "${item.title}" (${item.report_code || `#${item.id}`}) is now marked as ${lifecycleLabel(nextLifecycle)}.`,
      null
    );
  }

  broadcastToCollege(auth.collegeId, 'report:updated', {
    item: updated,
    lifecycleStatus: nextLifecycle,
  });

  res.json({ item: updated });
});

app.delete('/api/items/:id', requireAuth, requireAdmin, (req, res) => {
  const auth = req.auth!;
  const itemId = Number(req.params.id);
  const result = db.prepare('DELETE FROM items WHERE id = ? AND college_id = ?').run(itemId, auth.collegeId);
  if (result.changes === 0) {
    res.status(404).json({ error: 'Device report not found in your college workspace.' });
    return;
  }
  broadcastToCollege(auth.collegeId, 'report:deleted', { itemId });
  res.json({ ok: true });
});

const ENRICHED_MATCH_SELECT = `
  SELECT
    m.id,
    m.confidence,
    m.status,
    COALESCE(m.workflow_status, 'POSSIBLE_MATCH') as workflow_status,
    m.notes,
    m.created_at,
    m.accepted_by_user_id,
    m.accepted_at,
    m.rejected_by_user_id,
    m.rejected_at,
    COALESCE(m.lost_owner_handover_confirmed, 0) as lost_owner_handover_confirmed,
    m.lost_owner_handover_at,
    COALESCE(m.found_owner_handover_confirmed, 0) as found_owner_handover_confirmed,
    m.found_owner_handover_at,
    m.recovered_at,
    mi.id as missing_item_id,
    mi.report_code as missing_report_code,
    mi.title as missing_title,
    mi.device_type as missing_device_type,
    mi.category as missing_category,
    mi.location as missing_location,
    mi.reported_date as missing_date,
    mi.image_data as missing_image,
    mi.lifecycle_status as missing_lifecycle_status,
    mi.reporter_user_id as missing_reporter_user_id,
    mu.full_name as missing_reporter_name,
    fi.id as found_item_id,
    fi.report_code as found_report_code,
    fi.title as found_title,
    fi.location as found_location,
    fi.reported_date as found_date,
    fi.image_data as found_image,
    fi.lifecycle_status as found_lifecycle_status,
    fi.reporter_user_id as found_reporter_user_id,
    fu.full_name as found_reporter_name
  FROM matches m
  JOIN items mi ON mi.id = m.missing_item_id
  JOIN users mu ON mu.id = mi.reporter_user_id
  JOIN items fi ON fi.id = m.found_item_id
  JOIN users fu ON fu.id = fi.reporter_user_id
`;

function fetchEnrichedMatchById(matchId: number, collegeId: number) {
  return db
    .prepare(`${ENRICHED_MATCH_SELECT} WHERE m.id = ? AND m.college_id = ?`)
    .get(matchId, collegeId) as Record<string, unknown> | undefined;
}

// Fetch matches strictly for the authenticated college (includes device photos, reporter IDs & workflow status)
app.get('/api/matches', requireAuth, (req, res) => {
  const auth = req.auth!;
  const collegeId = auth.collegeId;
  const mineOnly = req.query.mine === 'true';

  let sql = `${ENRICHED_MATCH_SELECT} WHERE m.college_id = ?`;
  const params: number[] = [collegeId];

  if (mineOnly) {
    sql += ' AND (mi.reporter_user_id = ? OR fi.reporter_user_id = ?)';
    params.push(auth.userId, auth.userId);
  }

  sql += ' ORDER BY m.id DESC';

  const rows = db.prepare(sql).all(...params);
  res.json({ matches: rows });
});

// Fetch a single match strictly for authorized participants (lost owner, found owner) or college admin
app.get('/api/matches/:id', requireAuth, (req, res) => {
  const auth = req.auth!;
  const matchId = Number(req.params.id);
  const match = fetchEnrichedMatchById(matchId, auth.collegeId);
  if (!match) {
    res.status(404).json({ error: 'Match record not found in your institution.' });
    return;
  }
  const isParticipant =
    auth.role === 'admin' ||
    Number(match.missing_reporter_user_id) === auth.userId ||
    Number(match.found_reporter_user_id) === auth.userId;
  if (!isParticipant) {
    res.status(403).json({ error: 'You are not authorized to view this match record.' });
    return;
  }
  res.json({ match });
});

// User 1 (original lost-report owner ONLY): Accept a possible match -> MATCH_ACCEPTED (NOT yet RECOVERED)
app.post('/api/matches/:id/accept', requireAuth, (req, res) => {
  const auth = req.auth!;
  const matchId = Number(req.params.id);

  type TxResult =
    | { ok: true; match: Record<string, unknown>; foundOwnerId: number; missingItemId: number; foundItemId: number; foundReportCode: string; acceptedAt: string }
    | { ok: false; status: number; error: string };

  const acceptTx = db.transaction((): TxResult => {
    const row = db
      .prepare(
        `SELECT m.id, m.college_id, m.missing_item_id, m.found_item_id,
                COALESCE(m.workflow_status, 'POSSIBLE_MATCH') as workflow_status,
                mi.reporter_user_id as missing_owner_id, mi.title as missing_title,
                fi.reporter_user_id as found_owner_id, fi.title as found_title, fi.report_code as found_report_code
         FROM matches m
         JOIN items mi ON mi.id = m.missing_item_id
         JOIN items fi ON fi.id = m.found_item_id
         WHERE m.id = ? AND m.college_id = ?`
      )
      .get(matchId, auth.collegeId) as
      | {
          id: number;
          college_id: number;
          missing_item_id: number;
          found_item_id: number;
          workflow_status: string;
          missing_owner_id: number;
          missing_title: string;
          found_owner_id: number;
          found_title: string;
          found_report_code: string;
        }
      | undefined;

    if (!row) {
      return { ok: false, status: 404, error: 'Match record not found in your institution.' };
    }
    if (row.missing_owner_id !== auth.userId) {
      return { ok: false, status: 403, error: 'Only the student who reported the lost device can accept this match.' };
    }
    if (row.workflow_status === 'MATCH_ACCEPTED' || row.workflow_status === 'HANDOVER_PENDING') {
      return { ok: false, status: 409, error: 'This match has already been accepted.' };
    }
    if (row.workflow_status === 'RECOVERED') {
      return { ok: false, status: 409, error: 'This device has already been recovered.' };
    }
    if (row.workflow_status === 'MATCH_REJECTED') {
      return { ok: false, status: 409, error: 'This match was previously rejected and cannot be accepted.' };
    }

    const acceptedAt = new Date().toISOString();
    db.prepare(
      `UPDATE matches
       SET workflow_status = 'MATCH_ACCEPTED',
           status = 'verified',
           accepted_by_user_id = ?,
           accepted_at = ?
       WHERE id = ? AND college_id = ?`
    ).run(auth.userId, acceptedAt, matchId, auth.collegeId);

    // Keep both reports active (NOT recovered) — handover has not happened yet
    db.prepare(
      `UPDATE items
       SET status = 'matched', lifecycle_status = 'possible_match'
       WHERE id IN (?, ?) AND college_id = ? AND lifecycle_status NOT IN ('recovered', 'closed')`
    ).run(row.missing_item_id, row.found_item_id, auth.collegeId);

    // Mark User 1's match_found notification as read
    db.prepare(
      `UPDATE notifications
       SET is_read = 1
       WHERE college_id = ? AND user_id = ? AND related_match_id = ? AND notification_type = 'match_found'`
    ).run(auth.collegeId, auth.userId, matchId);

    const updated = fetchEnrichedMatchById(matchId, auth.collegeId)!;
    return {
      ok: true,
      match: updated,
      foundOwnerId: row.found_owner_id,
      missingItemId: row.missing_item_id,
      foundItemId: row.found_item_id,
      foundReportCode: row.found_report_code || `CF-${row.found_item_id}`,
      acceptedAt,
    };
  });

  const result = acceptTx();
  if (!result.ok) {
    res.status(result.status).json({ error: result.error });
    return;
  }

  // Notify User 2 (the student who submitted the found report)
  createNotification(
    auth.collegeId,
    result.foundOwnerId,
    'Possible Match Accepted',
    `Your found device report has been accepted as a possible match by the student who reported the device lost.`,
    matchId,
    {
      notificationType: 'match_accepted',
      relatedLostItemId: result.missingItemId,
      relatedFoundItemId: result.foundItemId,
    }
  );

  broadcastToCollege(auth.collegeId, 'match:updated', {
    matchId,
    workflowStatus: 'MATCH_ACCEPTED',
    missingItemId: result.missingItemId,
    foundItemId: result.foundItemId,
  });

  res.json({
    ok: true,
    match: result.match,
    message: 'Match accepted! The found student has been notified.',
  });
});

// User 1 (original lost-report owner ONLY): Reject a possible match -> MATCH_REJECTED (preserves both reports)
app.post('/api/matches/:id/reject', requireAuth, (req, res) => {
  const auth = req.auth!;
  const matchId = Number(req.params.id);

  type TxResult =
    | { ok: true; match: Record<string, unknown>; missingItemId: number; foundItemId: number }
    | { ok: false; status: number; error: string };

  const rejectTx = db.transaction((): TxResult => {
    const row = db
      .prepare(
        `SELECT m.id, m.college_id, m.missing_item_id, m.found_item_id,
                COALESCE(m.workflow_status, 'POSSIBLE_MATCH') as workflow_status,
                mi.reporter_user_id as missing_owner_id
         FROM matches m
         JOIN items mi ON mi.id = m.missing_item_id
         WHERE m.id = ? AND m.college_id = ?`
      )
      .get(matchId, auth.collegeId) as
      | {
          id: number;
          college_id: number;
          missing_item_id: number;
          found_item_id: number;
          workflow_status: string;
          missing_owner_id: number;
        }
      | undefined;

    if (!row) {
      return { ok: false, status: 404, error: 'Match record not found in your institution.' };
    }
    if (row.missing_owner_id !== auth.userId) {
      return { ok: false, status: 403, error: 'Only the student who reported the lost device can reject this match.' };
    }
    if (row.workflow_status === 'MATCH_REJECTED') {
      return { ok: false, status: 409, error: 'This match has already been rejected.' };
    }
    if (row.workflow_status === 'RECOVERED') {
      return { ok: false, status: 409, error: 'Cannot reject a match that has already been recovered.' };
    }
    if (row.workflow_status === 'MATCH_ACCEPTED' || row.workflow_status === 'HANDOVER_PENDING') {
      return { ok: false, status: 409, error: 'Cannot reject a match that has already been accepted.' };
    }

    const rejectedAt = new Date().toISOString();
    db.prepare(
      `UPDATE matches
       SET workflow_status = 'MATCH_REJECTED',
           status = 'dismissed',
           rejected_by_user_id = ?,
           rejected_at = ?
       WHERE id = ? AND college_id = ?`
    ).run(auth.userId, rejectedAt, matchId, auth.collegeId);

    // Preserve both reports without deleting or marking recovered; reopen if no other active match exists
    for (const itemId of [row.missing_item_id, row.found_item_id]) {
      const otherActive = db
        .prepare(
          `SELECT id FROM matches
           WHERE college_id = ? AND id != ?
             AND (missing_item_id = ? OR found_item_id = ?)
             AND COALESCE(workflow_status, 'POSSIBLE_MATCH') NOT IN ('MATCH_REJECTED')`
        )
        .get(auth.collegeId, matchId, itemId, itemId);
      if (!otherActive) {
        db.prepare(
          `UPDATE items
           SET status = 'open', lifecycle_status = 'submitted'
           WHERE id = ? AND college_id = ? AND lifecycle_status NOT IN ('recovered', 'closed')`
        ).run(itemId, auth.collegeId);
      }
    }

    // Ensure rejected match notification is marked read so it never repeatedly notifies User 1
    db.prepare(
      `UPDATE notifications
       SET is_read = 1
       WHERE college_id = ? AND user_id = ? AND related_match_id = ?`
    ).run(auth.collegeId, auth.userId, matchId);

    const updated = fetchEnrichedMatchById(matchId, auth.collegeId)!;
    return {
      ok: true,
      match: updated,
      missingItemId: row.missing_item_id,
      foundItemId: row.found_item_id,
    };
  });

  const result = rejectTx();
  if (!result.ok) {
    res.status(result.status).json({ error: result.error });
    return;
  }

  broadcastToCollege(auth.collegeId, 'match:updated', {
    matchId,
    workflowStatus: 'MATCH_REJECTED',
    missingItemId: result.missingItemId,
    foundItemId: result.foundItemId,
  });

  res.json({
    ok: true,
    match: result.match,
    message: 'Match rejected. Both reports remain active in the campus registry.',
  });
});

// Physical Handover Confirmation (User 1: "I have received my device." / User 2: "I have handed over the device.")
// Marks match + both lost & found reports as RECOVERED ONLY after BOTH participants confirm.
app.post('/api/matches/:id/handover', requireAuth, (req, res) => {
  const auth = req.auth!;
  const matchId = Number(req.params.id);

  type TxResult =
    | {
        ok: true;
        match: Record<string, unknown>;
        recovered: boolean;
        actorRole: 'lost_owner' | 'found_owner';
        missingOwnerId: number;
        foundOwnerId: number;
        missingItemId: number;
        foundItemId: number;
        missingTitle: string;
        foundTitle: string;
      }
    | { ok: false; status: number; error: string };

  const handoverTx = db.transaction((): TxResult => {
    const row = db
      .prepare(
        `SELECT m.id, m.college_id, m.missing_item_id, m.found_item_id,
                COALESCE(m.workflow_status, 'POSSIBLE_MATCH') as workflow_status,
                COALESCE(m.lost_owner_handover_confirmed, 0) as lost_confirmed,
                COALESCE(m.found_owner_handover_confirmed, 0) as found_confirmed,
                mi.reporter_user_id as missing_owner_id, mi.title as missing_title,
                fi.reporter_user_id as found_owner_id, fi.title as found_title
         FROM matches m
         JOIN items mi ON mi.id = m.missing_item_id
         JOIN items fi ON fi.id = m.found_item_id
         WHERE m.id = ? AND m.college_id = ?`
      )
      .get(matchId, auth.collegeId) as
      | {
          id: number;
          college_id: number;
          missing_item_id: number;
          found_item_id: number;
          workflow_status: string;
          lost_confirmed: number;
          found_confirmed: number;
          missing_owner_id: number;
          missing_title: string;
          found_owner_id: number;
          found_title: string;
        }
      | undefined;

    if (!row) {
      return { ok: false, status: 404, error: 'Match record not found in your institution.' };
    }

    const isLostOwner = row.missing_owner_id === auth.userId;
    const isFoundOwner = row.found_owner_id === auth.userId;
    if (!isLostOwner && !isFoundOwner) {
      return {
        ok: false,
        status: 403,
        error: 'Only the two authorized students involved in this match can confirm handover.',
      };
    }

    if (row.workflow_status === 'POSSIBLE_MATCH') {
      return {
        ok: false,
        status: 400,
        error: 'The lost-device owner must accept the match before confirming physical handover.',
      };
    }
    if (row.workflow_status === 'MATCH_REJECTED') {
      return { ok: false, status: 409, error: 'Cannot confirm handover for a rejected match.' };
    }
    if (row.workflow_status === 'RECOVERED') {
      return { ok: false, status: 409, error: 'Device recovery has already been completed.' };
    }

    if (isLostOwner && row.lost_confirmed === 1) {
      return { ok: false, status: 409, error: 'You have already confirmed receiving this device.' };
    }
    if (isFoundOwner && row.found_confirmed === 1) {
      return { ok: false, status: 409, error: 'You have already confirmed handing over this device.' };
    }

    const now = new Date().toISOString();
    const nextLostConfirmed = isLostOwner ? 1 : row.lost_confirmed;
    const nextFoundConfirmed = isFoundOwner ? 1 : row.found_confirmed;
    const bothConfirmed = nextLostConfirmed === 1 && nextFoundConfirmed === 1;

    if (isLostOwner) {
      db.prepare(
        `UPDATE matches
         SET lost_owner_handover_confirmed = 1,
             lost_owner_handover_at = ?,
             lost_owner_handover_user_id = ?
         WHERE id = ? AND college_id = ?`
      ).run(now, auth.userId, matchId, auth.collegeId);
    } else {
      db.prepare(
        `UPDATE matches
         SET found_owner_handover_confirmed = 1,
             found_owner_handover_at = ?,
             found_owner_handover_user_id = ?
         WHERE id = ? AND college_id = ?`
      ).run(now, auth.userId, matchId, auth.collegeId);
    }

    if (bothConfirmed) {
      db.prepare(
        `UPDATE matches
         SET workflow_status = 'RECOVERED',
             status = 'claimed',
             recovered_at = ?
         WHERE id = ? AND college_id = ?`
      ).run(now, matchId, auth.collegeId);

      // Update BOTH original Lost and Found reports to RECOVERED without changing type or ownership
      db.prepare(
        `UPDATE items
         SET status = 'resolved', lifecycle_status = 'recovered'
         WHERE id IN (?, ?) AND college_id = ?`
      ).run(row.missing_item_id, row.found_item_id, auth.collegeId);
    } else {
      db.prepare(
        `UPDATE matches
         SET workflow_status = 'HANDOVER_PENDING',
             status = 'verified'
         WHERE id = ? AND college_id = ?`
      ).run(matchId, auth.collegeId);
    }

    const updated = fetchEnrichedMatchById(matchId, auth.collegeId)!;
    return {
      ok: true,
      match: updated,
      recovered: bothConfirmed,
      actorRole: isLostOwner ? 'lost_owner' : 'found_owner',
      missingOwnerId: row.missing_owner_id,
      foundOwnerId: row.found_owner_id,
      missingItemId: row.missing_item_id,
      foundItemId: row.found_item_id,
      missingTitle: row.missing_title,
      foundTitle: row.found_title,
    };
  });

  const result = handoverTx();
  if (!result.ok) {
    res.status(result.status).json({ error: result.error });
    return;
  }

  if (result.recovered) {
    createNotification(
      auth.collegeId,
      result.missingOwnerId,
      'Device Recovery Completed',
      `Both students confirmed physical handover. Your lost device "${result.missingTitle}" is now marked as RECOVERED.`,
      matchId,
      {
        notificationType: 'recovery_completed',
        relatedLostItemId: result.missingItemId,
        relatedFoundItemId: result.foundItemId,
      }
    );
    if (result.foundOwnerId !== result.missingOwnerId) {
      createNotification(
        auth.collegeId,
        result.foundOwnerId,
        'Device Recovery Completed',
        `Both students confirmed physical handover. Your found device report "${result.foundTitle}" is now marked as RECOVERED.`,
        matchId,
        {
          notificationType: 'recovery_completed',
          relatedLostItemId: result.missingItemId,
          relatedFoundItemId: result.foundItemId,
        }
      );
    }
  } else {
    const otherUserId =
      result.actorRole === 'lost_owner' ? result.foundOwnerId : result.missingOwnerId;
    const msg =
      result.actorRole === 'lost_owner'
        ? 'The lost-device owner confirmed receiving the device. Please confirm "I have handed over the device" to complete recovery.'
        : 'The student who found the device confirmed handing it over. Please confirm "I have received my device" to complete recovery.';
    createNotification(
      auth.collegeId,
      otherUserId,
      'Handover Confirmation Pending',
      msg,
      matchId,
      {
        notificationType: 'handover_pending',
        relatedLostItemId: result.missingItemId,
        relatedFoundItemId: result.foundItemId,
      }
    );
  }

  broadcastToCollege(auth.collegeId, 'match:updated', {
    matchId,
    workflowStatus: result.recovered ? 'RECOVERED' : 'HANDOVER_PENDING',
    missingItemId: result.missingItemId,
    foundItemId: result.foundItemId,
  });
  if (result.recovered) {
    broadcastToCollege(auth.collegeId, 'report:updated', {
      lifecycleStatus: 'recovered',
      missingItemId: result.missingItemId,
      foundItemId: result.foundItemId,
    });
  }

  res.json({
    ok: true,
    match: result.match,
    recovered: result.recovered,
    message: result.recovered
      ? 'Physical handover confirmed by both students! Device is now marked as RECOVERED.'
      : 'Your handover confirmation has been recorded. Waiting for the other student to confirm.',
  });
});

// AI-Powered Visual Device Comparison endpoint (server-side @google/genai)
app.post('/api/matches/ai-compare', requireAuth, async (req, res) => {
  const auth = req.auth!;
  const { missingItemId, foundItemId, saveMatch } = req.body ?? {};

  const missingItem = db
    .prepare(`SELECT * FROM items WHERE id = ? AND college_id = ? AND type = 'missing'`)
    .get(Number(missingItemId), auth.collegeId) as ItemRow | undefined;

  const foundItem = db
    .prepare(`SELECT * FROM items WHERE id = ? AND college_id = ? AND type = 'found'`)
    .get(Number(foundItemId), auth.collegeId) as ItemRow | undefined;

  if (!missingItem || !foundItem) {
    res.status(404).json({ error: 'Both lost and found device reports must exist within your college.' });
    return;
  }

  try {
    const result = await compareDevicePairWithAI(missingItem, foundItem);

    let createdMatchId: number | null = null;
    if (saveMatch && auth.role === 'admin') {
      const insert = db
        .prepare(
          `INSERT INTO matches (college_id, missing_item_id, found_item_id, confidence, status, notes, updated_by_admin_id)
           VALUES (?, ?, ?, ?, 'pending', ?, ?)`
        )
        .run(
          auth.collegeId,
          missingItem.id,
          foundItem.id,
          result.confidence,
          `AI Comparison (${result.confidence}%): ${result.reasoning}`,
          auth.userId
        );
      createdMatchId = Number(insert.lastInsertRowid);
      db.prepare(
        `UPDATE items SET status = 'matched', lifecycle_status = 'possible_match' WHERE id IN (?, ?) AND college_id = ?`
      ).run(missingItem.id, foundItem.id, auth.collegeId);
      createNotification(
        auth.collegeId,
        missingItem.reporter_user_id,
        'AI Visual Match Ready for Verification',
        `Your missing "${missingItem.title}" has a ${result.confidence}% match candidate. Please verify in person before claiming.`,
        createdMatchId
      );
      broadcastToCollege(auth.collegeId, 'match:created', {
        matchId: createdMatchId,
        missingItemId: missingItem.id,
        foundItemId: foundItem.id,
        confidence: result.confidence,
      });
    }

    res.json({ comparison: result, createdMatchId });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'AI comparison failed.';
    res.status(502).json({ error: message });
  }
});

// College Admin: Create a verified match manually
app.post('/api/matches', requireAuth, requireAdmin, (req, res) => {
  const auth = req.auth!;
  const { missingItemId, foundItemId, notes, confidence } = req.body ?? {};

  const missingItem = db
    .prepare(`SELECT * FROM items WHERE id = ? AND college_id = ? AND type = 'missing'`)
    .get(Number(missingItemId), auth.collegeId) as ItemRow | undefined;

  const foundItem = db
    .prepare(`SELECT * FROM items WHERE id = ? AND college_id = ? AND type = 'found'`)
    .get(Number(foundItemId), auth.collegeId) as ItemRow | undefined;

  if (!missingItem || !foundItem) {
    res.status(404).json({ error: 'Both missing and found reports must exist within your college.' });
    return;
  }

  const score = Math.min(98, Math.max(50, Number(confidence) || 90));
  const result = db
    .prepare(
      `INSERT INTO matches (college_id, missing_item_id, found_item_id, confidence, status, notes, updated_by_admin_id)
       VALUES (?, ?, ?, ?, 'verified', ?, ?)`
    )
    .run(
      auth.collegeId,
      missingItem.id,
      foundItem.id,
      score,
      String(notes || 'Linked by college administrator — awaiting owner verification.'),
      auth.userId
    );

  const matchId = Number(result.lastInsertRowid);
  db.prepare(
    `UPDATE items SET status = 'matched', lifecycle_status = 'verified' WHERE id IN (?, ?) AND college_id = ?`
  ).run(missingItem.id, foundItem.id, auth.collegeId);

  createNotification(
    auth.collegeId,
    missingItem.reporter_user_id,
    'Administrator Linked a Possible Match',
    `A college administrator linked "${foundItem.title}" with your missing "${missingItem.title}". Please complete human verification.`,
    matchId
  );

  broadcastToCollege(auth.collegeId, 'match:created', {
    matchId,
    missingItemId: missingItem.id,
    foundItemId: foundItem.id,
    confidence: score,
  });

  res.status(201).json({ id: matchId, ok: true });
});

// College Admin: Update match status
app.patch('/api/matches/:id', requireAuth, requireAdmin, (req, res) => {
  const auth = req.auth!;
  const matchId = Number(req.params.id);
  const { status, notes } = req.body ?? {};

  if (!['pending', 'verified', 'claimed', 'dismissed'].includes(status)) {
    res.status(400).json({ error: 'Invalid match status.' });
    return;
  }

  const match = db
    .prepare('SELECT * FROM matches WHERE id = ? AND college_id = ?')
    .get(matchId, auth.collegeId) as
    | { id: number; missing_item_id: number; found_item_id: number; notes: string }
    | undefined;

  if (!match) {
    res.status(404).json({ error: 'Match record not found in your college.' });
    return;
  }

  db.prepare('UPDATE matches SET status = ?, notes = ?, updated_by_admin_id = ? WHERE id = ? AND college_id = ?').run(
    status,
    typeof notes === 'string' ? notes.trim() : match.notes,
    auth.userId,
    matchId,
    auth.collegeId
  );

  const missingItem = db.prepare('SELECT * FROM items WHERE id = ?').get(match.missing_item_id) as ItemRow | undefined;
  const foundItem = db.prepare('SELECT * FROM items WHERE id = ?').get(match.found_item_id) as ItemRow | undefined;

  if (status === 'claimed') {
    db.prepare(
      `UPDATE items SET status = 'resolved', lifecycle_status = 'recovered' WHERE id IN (?, ?) AND college_id = ?`
    ).run(match.missing_item_id, match.found_item_id, auth.collegeId);
    if (missingItem) {
      createNotification(
        auth.collegeId,
        missingItem.reporter_user_id,
        'Device Recovery Confirmed',
        `Your "${missingItem.title}" has been verified and marked as recovered.`,
        matchId
      );
    }
    if (foundItem && foundItem.reporter_user_id !== missingItem?.reporter_user_id) {
      createNotification(
        auth.collegeId,
        foundItem.reporter_user_id,
        'Found Device Returned to Owner',
        `Thank you — "${foundItem.title}" has been verified and returned to its owner.`,
        matchId
      );
    }
  } else if (status === 'dismissed') {
    db.prepare(
      `UPDATE items SET status = 'open', lifecycle_status = 'under_review' WHERE id IN (?, ?) AND college_id = ?`
    ).run(match.missing_item_id, match.found_item_id, auth.collegeId);
  } else if (status === 'verified') {
    db.prepare(
      `UPDATE items SET status = 'matched', lifecycle_status = 'verified' WHERE id IN (?, ?) AND college_id = ?`
    ).run(match.missing_item_id, match.found_item_id, auth.collegeId);
    if (missingItem) {
      createNotification(
        auth.collegeId,
        missingItem.reporter_user_id,
        'Match Verified by Administrator',
        `Please visit the Campus Security Desk with proof of ownership to claim "${missingItem.title}".`,
        matchId
      );
    }
  }

  broadcastToCollege(auth.collegeId, 'match:updated', {
    matchId,
    status,
    missingItemId: match.missing_item_id,
    foundItemId: match.found_item_id,
  });

  res.json({ ok: true });
});

// Notifications (strictly isolated to authenticated user & college, enriched with match/found-device summary)
app.get('/api/notifications', requireAuth, (req, res) => {
  const auth = req.auth!;
  const notifications = db
    .prepare(
      `SELECT
         n.id,
         n.title,
         n.message,
         n.related_match_id,
         n.notification_type,
         n.related_lost_item_id,
         n.related_found_item_id,
         n.is_read,
         n.created_at,
         fi.title as found_title,
         fi.device_type as found_device_type,
         fi.brand as found_brand,
         fi.model as found_model,
         fi.color as found_color,
         fi.location as found_location,
         fi.reported_date as found_date,
         fi.report_code as found_report_code,
         COALESCE(m.workflow_status, 'POSSIBLE_MATCH') as match_workflow_status,
         m.accepted_at as match_accepted_at,
         COALESCE(m.lost_owner_handover_confirmed, 0) as lost_owner_handover_confirmed,
         COALESCE(m.found_owner_handover_confirmed, 0) as found_owner_handover_confirmed,
         m.recovered_at as match_recovered_at
       FROM notifications n
       LEFT JOIN items fi ON fi.id = n.related_found_item_id AND fi.college_id = n.college_id
       LEFT JOIN matches m ON m.id = n.related_match_id AND m.college_id = n.college_id
       WHERE n.college_id = ? AND n.user_id = ?
       ORDER BY n.id DESC
       LIMIT 40`
    )
    .all(auth.collegeId, auth.userId);
  res.json({ notifications });
});

app.patch('/api/notifications/read-all', requireAuth, (req, res) => {
  const auth = req.auth!;
  db.prepare(`UPDATE notifications SET is_read = 1 WHERE college_id = ? AND user_id = ?`).run(
    auth.collegeId,
    auth.userId
  );
  res.json({ ok: true });
});

app.patch('/api/notifications/:id/read', requireAuth, (req, res) => {
  const auth = req.auth!;
  db.prepare(
    `UPDATE notifications SET is_read = 1 WHERE id = ? AND college_id = ? AND user_id = ?`
  ).run(Number(req.params.id), auth.collegeId, auth.userId);
  res.json({ ok: true });
});

// Admin Location Intelligence (live SQLite-driven hotspots & monthly analytics — zero fake data)
app.get('/api/analytics/locations', requireAuth, requireAdmin, (req, res) => {
  const collegeId = req.auth!.collegeId;

  const hotspots = db
    .prepare(
      `SELECT
         location,
         SUM(CASE WHEN type = 'missing' THEN 1 ELSE 0 END) as missing_count,
         SUM(CASE WHEN type = 'found' THEN 1 ELSE 0 END) as found_count,
         SUM(CASE WHEN status = 'resolved' OR lifecycle_status = 'recovered' THEN 1 ELSE 0 END) as recovered_count,
         AVG(latitude) as avg_lat,
         AVG(longitude) as avg_lng
       FROM items
       WHERE college_id = ? AND status != 'archived'
       GROUP BY location
       ORDER BY (missing_count + found_count) DESC`
    )
    .all(collegeId);

  const monthly = db
    .prepare(
      `SELECT
         substr(reported_date, 1, 7) as month,
         SUM(CASE WHEN type = 'missing' THEN 1 ELSE 0 END) as missing_count,
         SUM(CASE WHEN type = 'found' THEN 1 ELSE 0 END) as found_count,
         SUM(CASE WHEN status = 'resolved' OR lifecycle_status = 'recovered' THEN 1 ELSE 0 END) as recovered_count
       FROM items
       WHERE college_id = ?
       GROUP BY substr(reported_date, 1, 7)
       ORDER BY month ASC`
    )
    .all(collegeId);

  const deviceBreakdown = db
    .prepare(
      `SELECT
         device_type,
         COUNT(*) as total,
         SUM(CASE WHEN status = 'resolved' OR lifecycle_status = 'recovered' THEN 1 ELSE 0 END) as recovered
       FROM items
       WHERE college_id = ? AND status != 'archived'
       GROUP BY device_type
       ORDER BY total DESC`
    )
    .all(collegeId);

  res.json({ hotspots, monthly, deviceBreakdown });
});

// College Admin: Export CSV of all college reports
app.get('/api/admin/export', requireAuth, requireAdmin, (req, res) => {
  const auth = req.auth!;
  const rows = db
    .prepare(
      `SELECT i.report_code, i.type, i.device_type, i.brand, i.model, i.title, i.location,
              i.reported_date, i.reported_time, i.lifecycle_status, u.full_name as reporter_name, u.identifier as reporter_email
       FROM items i
       JOIN users u ON u.id = i.reporter_user_id
       WHERE i.college_id = ?
       ORDER BY i.id DESC`
    )
    .all(auth.collegeId) as Record<string, string | null>[];

  const headers = [
    'Report Code',
    'Type',
    'Device Category',
    'Brand',
    'Model',
    'Title',
    'Location',
    'Date',
    'Time',
    'Status',
    'Reporter',
    'Email',
  ];
  const escape = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const csvLines = [
    headers.join(','),
    ...rows.map((r) =>
      [
        r.report_code,
        r.type,
        r.device_type,
        r.brand,
        r.model,
        r.title,
        r.location,
        r.reported_date,
        r.reported_time,
        r.lifecycle_status,
        r.reporter_name,
        r.reporter_email,
      ]
        .map(escape)
        .join(',')
    ),
  ];

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="campusfind-${auth.collegeCode.toLowerCase()}-reports.csv"`);
  res.send(csvLines.join('\n'));
});

// Admin: List all configured institutions (never exposes password hashes)
app.get('/api/admin/institutions', requireAuth, requireAdmin, (_req, res) => {
  const rows = db
    .prepare('SELECT * FROM colleges ORDER BY is_primary DESC, name ASC')
    .all() as CollegeRow[];
  res.json({ institutions: rows.map((c) => sanitizeCollege(c, true)) });
});

// Admin: Creating/activating additional institutions is disabled (MSAJCE-only deployment)
app.post('/api/admin/institutions', requireAuth, requireAdmin, (_req, res) => {
  res.status(403).json({
    error: 'Only Mohamed Sathak A.J. College of Engineering and Architecture (MSAJCE) is active for this deployment. Adding or activating other institutions is restricted.',
  });
});

// Admin: Update institution settings — strictly locked to MSAJCE only; other colleges cannot be enabled
app.patch('/api/admin/institutions/:id', requireAuth, requireAdmin, (req, res) => {
  const instId = Number(req.params.id);
  const college = db.prepare('SELECT * FROM colleges WHERE id = ?').get(instId) as CollegeRow | undefined;
  if (!college) {
    res.status(404).json({ error: 'Institution not found.' });
    return;
  }

  if (college.code.toUpperCase() !== 'MSAJCE') {
    res.status(403).json({
      error: `${college.name} is permanently disabled for this deployment. Only MSAJCE may remain active.`,
    });
    return;
  }

  const { initialStudentPassword, address, mapsUrl, zones } = req.body ?? {};

  const nextAddress = typeof address === 'string' ? address.trim() : college.address;
  const nextMapsUrl = typeof mapsUrl === 'string' ? mapsUrl.trim() : college.maps_url;
  const nextZones = Array.isArray(zones)
    ? JSON.stringify(zones.map((z: unknown) => String(z).trim()).filter(Boolean))
    : college.zones_json;

  let nextHash = college.initial_student_password_hash;
  if (typeof initialStudentPassword === 'string' && initialStudentPassword.trim().length > 0) {
    if (initialStudentPassword.trim().length < 8) {
      res.status(400).json({ error: 'Initial common student password must be at least 8 characters.' });
      return;
    }
    nextHash = bcrypt.hashSync(initialStudentPassword.trim(), 10);
  }

  db.prepare(
    `UPDATE colleges
     SET initial_student_password_hash = ?, student_access_enabled = 1, address = ?, maps_url = ?, zones_json = ?
     WHERE id = ?`
  ).run(nextHash, nextAddress, nextMapsUrl, nextZones, instId);

  const updated = db.prepare('SELECT * FROM colleges WHERE id = ?').get(instId) as CollegeRow;
  const sanitized = sanitizeCollege(updated, true);
  broadcastToCollege(instId, 'institution:updated', { college: sanitized });
  res.json({ institution: sanitized });
});

// College Admin: Genuine recorded student login & activity audit log (zero fabricated records)
app.get('/api/admin/activity', requireAuth, requireAdmin, (req, res) => {
  const collegeId = req.auth!.collegeId;
  const activities = db
    .prepare(
      `SELECT
         a.id,
         a.user_id,
         a.student_email,
         u.full_name as student_name,
         a.action_type,
         a.summary,
         a.related_item_id,
         a.created_at
       FROM student_activities a
       LEFT JOIN users u ON u.id = a.user_id
       WHERE a.college_id = ?
       ORDER BY a.id DESC
       LIMIT 100`
    )
    .all(collegeId);

  res.json({ activities });
});

// College Admin: View registered/authorized students strictly for their own college
app.get('/api/admin/members', requireAuth, requireAdmin, (req, res) => {
  const collegeId = req.auth!.collegeId;
  const members = db
    .prepare(
      `SELECT
         u.id,
         u.identifier,
         u.student_id,
         u.full_name,
         u.department,
         u.academic_year,
         u.is_authorized,
         u.first_login_completed,
         u.profile_completed,
         u.created_at,
         (SELECT COUNT(*) FROM items i WHERE i.reporter_user_id = u.id AND i.college_id = u.college_id) as report_count
       FROM users u
       WHERE u.college_id = ? AND u.role = 'user'
       ORDER BY u.full_name ASC`
    )
    .all(collegeId);

  res.json({ members });
});

// College Admin: Create / authorize a new student account (uses college's configured initial student password)
app.post('/api/admin/members', requireAuth, requireAdmin, (req, res) => {
  const auth = req.auth!;
  const { fullName, email, studentId, department } = req.body ?? {};
  if (!fullName || !email) {
    res.status(400).json({ error: 'Student full name and college email ID are required.' });
    return;
  }

  const college = db.prepare('SELECT * FROM colleges WHERE id = ?').get(auth.collegeId) as CollegeRow | undefined;
  if (!college) {
    res.status(404).json({ error: 'Institution not found.' });
    return;
  }

  const cleanEmail = String(email).trim().toLowerCase();
  const requiredDomain = normalizeDomain(college.domain);
  if (!cleanEmail.endsWith(`@${requiredDomain}`)) {
    res.status(400).json({
      error: `Student email must belong to the configured college domain @${requiredDomain}.`,
    });
    return;
  }

  const exists = db
    .prepare(`SELECT id FROM users WHERE college_id = ? AND role = 'user' AND LOWER(identifier) = ?`)
    .get(auth.collegeId, cleanEmail);
  if (exists) {
    res.status(409).json({ error: 'A student with this email is already authorized at this college.' });
    return;
  }

  const initialHash = college.initial_student_password_hash || bcrypt.hashSync('Student@2026', 10);
  const insertRes = db
    .prepare(
      `INSERT INTO users (college_id, role, identifier, student_id, full_name, department, password_hash, first_login_completed, is_authorized)
       VALUES (?, 'user', ?, ?, ?, ?, ?, 0, 1)`
    )
    .run(
      auth.collegeId,
      cleanEmail,
      studentId ? String(studentId).trim().toUpperCase() : null,
      String(fullName).trim(),
      department ? String(department).trim() : 'General Studies',
      initialHash
    );

  const member = db
    .prepare(
      `SELECT u.id, u.identifier, u.student_id, u.full_name, u.department, u.is_authorized, u.first_login_completed, u.created_at, 0 as report_count
       FROM users u WHERE u.id = ?`
    )
    .get(Number(insertRes.lastInsertRowid));

  res.status(201).json({ member });
});

// College Admin: Enable/disable student access or reset first-login prompt
app.patch('/api/admin/members/:id', requireAuth, requireAdmin, (req, res) => {
  const auth = req.auth!;
  const memberId = Number(req.params.id);
  const { isAuthorized, resetFirstLogin } = req.body ?? {};

  const existing = db
    .prepare(`SELECT id FROM users WHERE id = ? AND college_id = ? AND role = 'user'`)
    .get(memberId, auth.collegeId);
  if (!existing) {
    res.status(404).json({ error: 'Student account not found in your college.' });
    return;
  }

  if (typeof isAuthorized === 'boolean') {
    db.prepare(`UPDATE users SET is_authorized = ? WHERE id = ?`).run(isAuthorized ? 1 : 0, memberId);
  }
  if (resetFirstLogin === true) {
    db.prepare(`UPDATE users SET first_login_completed = 0 WHERE id = ?`).run(memberId);
  }

  res.json({ ok: true });
});

async function startServer() {
  const PORT = 3000;
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(path.resolve(process.cwd(), 'dist/index.html'));

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CampusFind server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
