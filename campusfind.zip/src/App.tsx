import { useCallback, useEffect, useState } from 'react';
import { FastForward, RotateCcw } from 'lucide-react';
import { campusApi } from './lib/api';
import type { AuthUser, BeamScreenState, CollegeSummary } from './types/campusfind';
import { CinematicIntro } from './components/cinematic/CinematicIntro';
import { FlashlightReveal } from './components/cinematic/FlashlightReveal';
import { AuthenticationPanel } from './components/auth/AuthenticationPanel';
import { FirstLoginCharacter } from './components/auth/FirstLoginCharacter';
import { StudentDashboard } from './components/dashboard/StudentDashboard';
import { AdminDashboard } from './components/dashboard/AdminDashboard';

const INITIAL_BEAM: BeamScreenState = {
  x: 0.5,
  y: 0.5,
  intensity: 0,
  radius: 0,
  logoReveal: 0,
  headingReveal: 0,
  panelReveal: 0,
  fullReveal: 0,
  worldDarkness: 0,
  phase: 'white-studio',
};

export default function App() {
  const [sessionChecked, setSessionChecked] = useState(false);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [college, setCollege] = useState<CollegeSummary | null>(null);
  const [colleges, setColleges] = useState<CollegeSummary[]>([]);
  const [mapsApiKey, setMapsApiKey] = useState<string>(
    import.meta.env.VITE_GOOGLE_MAPS_API_KEY || ''
  );
  const [mapsQuotaExceeded, setMapsQuotaExceeded] = useState(false);

  const [beam, setBeam] = useState<BeamScreenState>(INITIAL_BEAM);
  const [introComplete, setIntroComplete] = useState(false);
  const [skipRequested, setSkipRequested] = useState(false);
  const [replayKey, setReplayKey] = useState(0);

  const refreshColleges = useCallback(async () => {
    try {
      const res = await campusApi.getColleges();
      setColleges(res.colleges);
    } catch {
      // Keep current list on transient error
    }
  }, []);

  useEffect(() => {
    const onQuotaExceeded = () => setMapsQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuotaExceeded);
  }, []);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const [collegesRes, mapsRes] = await Promise.all([
          campusApi.getColleges(),
          campusApi.getMapsConfig().catch(() => ({ apiKey: '', configured: false })),
        ]);
        if (active) {
          setColleges(collegesRes.colleges);
          if (!import.meta.env.VITE_GOOGLE_MAPS_API_KEY && mapsRes.apiKey) {
            setMapsApiKey(mapsRes.apiKey);
          }
        }
      } catch {
        // Keep empty until retry
      }

      try {
        const meRes = await campusApi.me();
        if (active) {
          setUser(meRes.user);
          setCollege(meRes.college);
        }
      } catch {
        // Unauthenticated — show cinematic intro & phone login
      } finally {
        if (active) setSessionChecked(true);
      }
    })();

    return () => {
      active = false;
    };
  }, []);

  const handleBeamUpdate = useCallback((next: BeamScreenState) => {
    setBeam(next);
  }, []);

  const handleIntroComplete = useCallback(() => {
    setIntroComplete(true);
  }, []);

  const handleSkipIntro = () => {
    setSkipRequested(true);
    setIntroComplete(true);
    setBeam({
      x: 0.5,
      y: 0.5,
      intensity: 1,
      radius: 148,
      logoReveal: 1,
      headingReveal: 1,
      panelReveal: 1,
      fullReveal: 1,
      worldDarkness: 1,
      phase: 'complete',
    });
  };

  const handleReplayIntro = () => {
    setSkipRequested(false);
    setIntroComplete(false);
    setBeam(INITIAL_BEAM);
    setReplayKey((k) => k + 1);
  };

  const handleLogout = async () => {
    try {
      await campusApi.logout();
    } catch {
      // Clear local state regardless
    }
    setUser(null);
    setCollege(null);
    void refreshColleges();
    setSkipRequested(true);
    setIntroComplete(true);
    setBeam({
      x: 0.5,
      y: 0.5,
      intensity: 1,
      radius: 148,
      logoReveal: 1,
      headingReveal: 1,
      panelReveal: 1,
      fullReveal: 1,
      worldDarkness: 1,
      phase: 'complete',
    });
  };

  const quotaBanner = mapsQuotaExceeded ? (
    <div className="bg-[#D98252]/15 border-b border-[#D98252]/40 text-[#7A3A1B] px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50">
      <span>
        Google Maps Platform quota reached. If you are the app owner, visit{' '}
        <a
          href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
          target="_blank"
          rel="noopener noreferrer"
          className="underline font-semibold text-[#174C4A]"
        >
          maps developer site
        </a>{' '}
        for instructions to update your account.
      </span>
    </div>
  ) : null;

  if (!sessionChecked) {
    return <div className="min-h-screen w-full bg-white" />;
  }

  if (user && college) {
    if (user.role === 'user' && (!user.firstLoginCompleted || !user.profileCompleted)) {
      return (
        <>
          {quotaBanner}
          <FirstLoginCharacter
            user={user}
            college={college}
            onComplete={(updatedUser) => setUser(updatedUser)}
          />
        </>
      );
    }

    return (
      <>
        {quotaBanner}
        {user.role === 'admin' ? (
          <AdminDashboard
            user={user}
            college={college}
            mapsApiKey={mapsApiKey}
            onUserUpdated={setUser}
            onCollegeUpdated={(updated) => {
              setCollege(updated);
              void refreshColleges();
            }}
            onLogout={handleLogout}
          />
        ) : (
          <StudentDashboard
            user={user}
            college={college}
            mapsApiKey={mapsApiKey}
            onUserUpdated={setUser}
            onLogout={handleLogout}
          />
        )}
      </>
    );
  }

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden bg-[#F4F1E8]">
      {quotaBanner}

      {!introComplete && (
        <CinematicIntro
          skipRequested={skipRequested}
          replayKey={replayKey}
          onBeamUpdate={handleBeamUpdate}
          onIntroComplete={handleIntroComplete}
        />
      )}

      {!introComplete && (
        <button
          type="button"
          onClick={handleSkipIntro}
          className="fixed bottom-6 right-6 z-40 h-10 px-4 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all duration-300 cursor-pointer bg-[#174C4A] text-[#F4F1E8] hover:bg-[#123D3B] shadow-md"
        >
          <span>Skip Intro</span>
          <FastForward className="w-3.5 h-3.5" />
        </button>
      )}

      <FlashlightReveal beam={beam} introComplete={introComplete}>
        <main className="min-h-screen w-full flex flex-col items-center justify-center px-4 py-8">
          <AuthenticationPanel
            colleges={colleges}
            beam={beam}
            introComplete={introComplete}
            onAuthSuccess={(authUser, authCollege) => {
              setUser(authUser);
              setCollege(authCollege);
            }}
          />

          {introComplete && (
            <button
              type="button"
              onClick={handleReplayIntro}
              className="mt-6 inline-flex items-center gap-1.5 text-xs font-medium text-[#55615F] hover:text-[#174C4A] transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Replay 3D Intro</span>
            </button>
          )}
        </main>
      </FlashlightReveal>
    </div>
  );
}
