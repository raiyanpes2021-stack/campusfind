import type {
  AiComparisonResponse,
  AuthUser,
  CampusItem,
  CampusMatch,
  CampusNotification,
  CollegeMember,
  CollegeSummary,
  DashboardStats,
  DeviceBreakdownStat,
  FoundDeviceDetails,
  ItemLifecycleStatus,
  LocationHotspot,
  LoginRole,
  MonthlyLocationStat,
  RealtimeMessage,
  StudentActivityRecord,
} from '../types/campusfind';

const TOKEN_KEY = 'campusfind_auth_token';

export function getStoredToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setStoredToken(token: string | null, remember = false): void {
  try {
    if (token) {
      if (remember) {
        localStorage.setItem(TOKEN_KEY, token);
        sessionStorage.removeItem(TOKEN_KEY);
      } else {
        sessionStorage.setItem(TOKEN_KEY, token);
        localStorage.removeItem(TOKEN_KEY);
      }
    } else {
      sessionStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(TOKEN_KEY);
    }
  } catch {
    // Ignore storage errors in restricted frames
  }
}

async function apiRequest<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers = new Headers(options.headers);
  if (!headers.has('Content-Type') && options.body) {
    headers.set('Content-Type', 'application/json');
  }
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const res = await fetch(path, {
    ...options,
    headers,
    credentials: 'include',
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data as T;
}

export function subscribeRealtime(
  onEvent: (msg: RealtimeMessage) => void,
  onStatusChange?: (connected: boolean) => void
): () => void {
  let closed = false;
  let es: EventSource | null = null;
  let retryTimer: number | null = null;
  let retryDelay = 1200;

  const eventTypes = [
    'connected',
    'report:created',
    'report:updated',
    'report:deleted',
    'match:created',
    'match:updated',
    'notification:created',
    'institution:updated',
    'activity:created',
  ];

  const connect = () => {
    if (closed) return;
    const token = getStoredToken();
    const url = token
      ? `/api/realtime/stream?token=${encodeURIComponent(token)}`
      : '/api/realtime/stream';

    es = new EventSource(url, { withCredentials: true });

    es.onopen = () => {
      retryDelay = 1200;
      onStatusChange?.(true);
    };

    for (const type of eventTypes) {
      es.addEventListener(type, (evt: MessageEvent) => {
        try {
          const parsed = JSON.parse(evt.data) as RealtimeMessage;
          onEvent(parsed);
        } catch {
          // Ignore malformed keepalive frames
        }
      });
    }

    es.onerror = () => {
      onStatusChange?.(false);
      es?.close();
      es = null;
      if (!closed) {
        retryTimer = window.setTimeout(() => {
          retryDelay = Math.min(12000, Math.round(retryDelay * 1.6));
          connect();
        }, retryDelay);
      }
    };
  };

  connect();

  return () => {
    closed = true;
    if (retryTimer !== null) window.clearTimeout(retryTimer);
    es?.close();
  };
}

export const campusApi = {
  getMapsConfig: () => apiRequest<{ apiKey: string; configured: boolean }>('/api/config/maps'),

  getColleges: () => apiRequest<{ colleges: CollegeSummary[] }>('/api/colleges'),

  login: async (payload: {
    collegeCode: string;
    identifier: string;
    password: string;
    role: LoginRole;
    rememberMe?: boolean;
  }) => {
    const res = await apiRequest<{ token: string; user: AuthUser; college: CollegeSummary }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    setStoredToken(res.token, Boolean(payload.rememberMe));
    return res;
  },

  firstLoginChangePassword: (payload: { email?: string; newPassword: string; confirmPassword: string }) =>
    apiRequest<{ ok: boolean; user: AuthUser }>('/api/auth/first-login-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  firstLoginSkip: () =>
    apiRequest<{ ok: boolean; user: AuthUser }>('/api/auth/first-login-skip', {
      method: 'POST',
    }),

  completeProfile: (payload: { fullName: string; department: string; academicYear: string }) =>
    apiRequest<{ ok: boolean; user: AuthUser }>('/api/profile/complete', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  forgotPassword: (payload: { collegeCode: string; identifier: string }) =>
    apiRequest<{ ok: boolean; message: string }>('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  logout: async () => {
    setStoredToken(null);
    return apiRequest<{ ok: boolean }>('/api/auth/logout', { method: 'POST' });
  },

  me: () => apiRequest<{ user: AuthUser; college: CollegeSummary }>('/api/auth/me'),

  updateProfile: (payload: { fullName: string; department: string; academicYear?: string }) =>
    apiRequest<{ user: AuthUser }>('/api/profile', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  // Admin Institution Management
  getAdminInstitutions: () => apiRequest<{ institutions: CollegeSummary[] }>('/api/admin/institutions'),

  createInstitution: (payload: {
    name: string;
    code: string;
    city?: string;
    address?: string;
    domain: string;
    adminEmail: string;
    adminPassword?: string;
    initialStudentPassword: string;
    studentAccessEnabled: boolean;
    zones?: string[];
  }) =>
    apiRequest<{ institution: CollegeSummary }>('/api/admin/institutions', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateInstitutionById: (
    id: number,
    payload: {
      name?: string;
      domain?: string;
      adminEmail?: string;
      initialStudentPassword?: string;
      studentAccessEnabled?: boolean;
      address?: string;
      mapsUrl?: string;
      zones?: string[];
    }
  ) =>
    apiRequest<{ institution: CollegeSummary }>(`/api/admin/institutions/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  // Admin Student Management
  getAdminMembers: () => apiRequest<{ members: CollegeMember[] }>('/api/admin/members'),

  createAuthorizedStudent: (payload: {
    fullName: string;
    email: string;
    studentId?: string;
    department?: string;
  }) =>
    apiRequest<{ member: CollegeMember }>('/api/admin/members', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateStudentAccess: (id: number, payload: { isAuthorized?: boolean; resetFirstLogin?: boolean }) =>
    apiRequest<{ ok: boolean }>(`/api/admin/members/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  getAdminActivity: () => apiRequest<{ activities: StudentActivityRecord[] }>('/api/admin/activity'),

  getSummary: () => apiRequest<{ stats: DashboardStats }>('/api/dashboard/summary'),

  getItems: (params?: {
    type?: 'missing' | 'found';
    status?: string;
    lifecycle?: ItemLifecycleStatus;
    mine?: boolean;
    search?: string;
  }) => {
    const query = new URLSearchParams();
    if (params?.type) query.set('type', params.type);
    if (params?.status) query.set('status', params.status);
    if (params?.lifecycle) query.set('lifecycle', params.lifecycle);
    if (params?.mine) query.set('mine', 'true');
    if (params?.search) query.set('search', params.search);
    const qs = query.toString();
    return apiRequest<{ items: CampusItem[] }>(`/api/items${qs ? `?${qs}` : ''}`);
  },

  getItemDetails: (id: number) =>
    apiRequest<{ details: FoundDeviceDetails }>(`/api/items/${id}/details`),

  createItem: (payload: {
    type: 'missing' | 'found';
    title: string;
    category: string;
    deviceType: string;
    brand?: string;
    model?: string;
    color?: string;
    location: string;
    latitude?: number;
    longitude?: number;
    description: string;
    additionalInfo?: string;
    reportedDate: string;
    reportedTime?: string;
    imageData?: string | null;
  }) =>
    apiRequest<{ item: CampusItem; autoMatchCreated: boolean; matchId: number | null }>('/api/items', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateItemLifecycle: (id: number, lifecycleStatus: ItemLifecycleStatus) =>
    apiRequest<{ item: CampusItem }>(`/api/items/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ lifecycleStatus }),
    }),

  deleteItem: (id: number) =>
    apiRequest<{ ok: boolean }>(`/api/items/${id}`, {
      method: 'DELETE',
    }),

  getMatches: (params?: { mine?: boolean }) => {
    const qs = params?.mine ? '?mine=true' : '';
    return apiRequest<{ matches: CampusMatch[] }>(`/api/matches${qs}`);
  },

  getMatch: (id: number) => apiRequest<{ match: CampusMatch }>(`/api/matches/${id}`),

  acceptMatch: (id: number) =>
    apiRequest<{ ok: boolean; match: CampusMatch; message: string }>(`/api/matches/${id}/accept`, {
      method: 'POST',
    }),

  rejectMatch: (id: number) =>
    apiRequest<{ ok: boolean; match: CampusMatch; message: string }>(`/api/matches/${id}/reject`, {
      method: 'POST',
    }),

  confirmMatchHandover: (id: number) =>
    apiRequest<{ ok: boolean; match: CampusMatch; recovered: boolean; message: string }>(
      `/api/matches/${id}/handover`,
      {
        method: 'POST',
      }
    ),

  aiCompareDevices: (payload: { missingItemId: number; foundItemId: number; saveMatch?: boolean }) =>
    apiRequest<{ comparison: AiComparisonResponse; createdMatchId: number | null }>('/api/matches/ai-compare', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateMatchStatus: (id: number, status: CampusMatch['status'], notes?: string) =>
    apiRequest<{ ok: boolean }>(`/api/matches/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ status, notes }),
    }),

  getNotifications: () => apiRequest<{ notifications: CampusNotification[] }>('/api/notifications'),

  markNotificationRead: (id: number) =>
    apiRequest<{ ok: boolean }>(`/api/notifications/${id}/read`, { method: 'PATCH' }),

  markAllNotificationsRead: () =>
    apiRequest<{ ok: boolean }>('/api/notifications/read-all', { method: 'PATCH' }),

  getLocationAnalytics: () =>
    apiRequest<{
      hotspots: LocationHotspot[];
      monthly: MonthlyLocationStat[];
      deviceBreakdown: DeviceBreakdownStat[];
    }>('/api/analytics/locations'),

  exportReportsCsv: async () => {
    const token = getStoredToken();
    const headers = new Headers();
    if (token) headers.set('Authorization', `Bearer ${token}`);
    const res = await fetch('/api/admin/export', { headers, credentials: 'include' });
    if (!res.ok) throw new Error('Failed to export CSV report.');
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `campusfind-reports-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  },
};
