import { GoogleGenAI, Type } from '@google/genai';
import type { ItemRow } from './db.ts';

export interface AiComparisonResult {
  confidence: number;
  visualCharacteristics: string[];
  reasoning: string;
  requiresHumanVerification: boolean;
  usedImages: boolean;
}

function parseDataUrl(dataUrl: string | null): { mimeType: string; data: string } | null {
  if (!dataUrl || !dataUrl.startsWith('data:image/')) return null;
  const match = dataUrl.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
  if (!match) return null;
  return { mimeType: match[1], data: match[2] };
}

export async function compareDevicePairWithAI(
  missingItem: ItemRow,
  foundItem: ItemRow
): Promise<AiComparisonResult> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY is not configured on the server. Add it in Settings > Secrets to run AI visual comparison.');
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const missingImg = parseDataUrl(missingItem.image_data);
  const foundImg = parseDataUrl(foundItem.image_data);

  const parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }> = [];

  parts.push({
    text: [
      'You are an intelligent Campus Lost & Found device matching assistant.',
      'Compare the LOST electronic device and the FOUND electronic device below.',
      'Evaluate visual characteristics (color, form factor, case, camera layout, wear, stickers) and metadata.',
      'IMPORTANT: Never claim two devices are 100% identical based on image or text similarity alone. Always state that human verification (serial/IMEI/unlock check) is required.',
      '',
      `LOST DEVICE: Title="${missingItem.title}", DeviceType="${missingItem.device_type}", Location="${missingItem.location}", Date="${missingItem.reported_date}", Description="${missingItem.description}"`,
      `FOUND DEVICE: Title="${foundItem.title}", DeviceType="${foundItem.device_type}", Location="${foundItem.location}", Date="${foundItem.reported_date}", Description="${foundItem.description}"`,
    ].join('\n'),
  });

  if (missingImg) {
    parts.push({ text: 'Image 1 (Lost Device Photo):' });
    parts.push({ inlineData: missingImg });
  }
  if (foundImg) {
    parts.push({ text: 'Image 2 (Found Device Photo):' });
    parts.push({ inlineData: foundImg });
  }

  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: { parts },
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          confidence: {
            type: Type.INTEGER,
            description: 'Calibrated match confidence score from 0 to 98 (never 100 because human verification is required).',
          },
          visualCharacteristics: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: 'Key visual or physical characteristics compared (3 to 5 concise bullets).',
          },
          reasoning: {
            type: Type.STRING,
            description: 'Concise 1-2 sentence explanation of why these devices may or may not match, reminding that human verification is required.',
          },
        },
        required: ['confidence', 'visualCharacteristics', 'reasoning'],
      },
    },
  });

  const rawText = (response.text ?? '{}').trim();
  const parsed = JSON.parse(rawText) as {
    confidence?: number;
    visualCharacteristics?: string[];
    reasoning?: string;
  };

  return {
    confidence: Math.max(5, Math.min(98, Math.round(Number(parsed.confidence) || 50))),
    visualCharacteristics: Array.isArray(parsed.visualCharacteristics)
      ? parsed.visualCharacteristics.slice(0, 5)
      : ['Device category and physical description compared'],
    reasoning:
      parsed.reasoning ||
      'Similarity evaluated from submitted device details. Human verification is required before confirming recovery.',
    requiresHumanVerification: true,
    usedImages: Boolean(missingImg || foundImg),
  };
}
