import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import path from 'path';

const DB_PATH = path.resolve(process.cwd(), 'campusfind.db');

export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export interface CollegeRow {
  id: number;
  code: string;
  name: string;
  city: string;
  address: string;
  domain: string;
  admin_email: string;
  initial_student_password_hash: string;
  student_access_enabled: number;
  latitude: number;
  longitude: number;
  maps_url: string;
  is_primary: number;
  zones_json: string;
  departments_json: string;
  academic_years_json: string;
  created_at: string;
}

export interface UserRow {
  id: number;
  college_id: number;
  role: 'user' | 'admin';
  identifier: string;
  student_id: string | null;
  full_name: string;
  department: string;
  academic_year: string;
  password_hash: string;
  first_login_completed: number;
  profile_completed: number;
  is_authorized: number;
  created_at: string;
}

export type ItemLifecycleStatus =
  | 'submitted'
  | 'under_review'
  | 'possible_match'
  | 'verified'
  | 'recovered'
  | 'closed';

export interface ItemRow {
  id: number;
  college_id: number;
  reporter_user_id: number;
  type: 'missing' | 'found';
  title: string;
  category: string;
  device_type: string;
  brand: string;
  model: string;
  color: string;
  location: string;
  latitude: number | null;
  longitude: number | null;
  description: string;
  additional_info: string;
  image_data: string | null;
  status: 'open' | 'matched' | 'resolved' | 'archived';
  lifecycle_status: ItemLifecycleStatus;
  report_code: string;
  reported_date: string;
  reported_time: string;
  created_at: string;
}

export type MatchWorkflowStatus =
  | 'POSSIBLE_MATCH'
  | 'MATCH_ACCEPTED'
  | 'MATCH_REJECTED'
  | 'HANDOVER_PENDING'
  | 'RECOVERED';

export interface MatchRow {
  id: number;
  college_id: number;
  missing_item_id: number;
  found_item_id: number;
  confidence: number;
  status: 'pending' | 'verified' | 'claimed' | 'dismissed';
  workflow_status: MatchWorkflowStatus;
  notes: string;
  updated_by_admin_id: number | null;
  accepted_by_user_id: number | null;
  accepted_at: string | null;
  rejected_by_user_id: number | null;
  rejected_at: string | null;
  lost_owner_handover_confirmed: number;
  lost_owner_handover_at: string | null;
  lost_owner_handover_user_id: number | null;
  found_owner_handover_confirmed: number;
  found_owner_handover_at: string | null;
  found_owner_handover_user_id: number | null;
  recovered_at: string | null;
  created_at: string;
}

function ensureColumn(table: string, column: string, definition: string): void {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all() as { name: string }[];
  if (!cols.some((c) => c.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}

export function mapStatusToLifecycle(status: string): ItemLifecycleStatus {
  switch (status) {
    case 'matched':
      return 'possible_match';
    case 'resolved':
      return 'recovered';
    case 'archived':
      return 'closed';
    default:
      return 'submitted';
  }
}

export function mapLifecycleToStatus(lifecycle: ItemLifecycleStatus): 'open' | 'matched' | 'resolved' | 'archived' {
  switch (lifecycle) {
    case 'possible_match':
      return 'matched';
    case 'recovered':
      return 'resolved';
    case 'closed':
      return 'archived';
    case 'verified':
    case 'under_review':
    case 'submitted':
    default:
      return 'open';
  }
}

export function normalizeDomain(raw: string): string {
  return String(raw || '')
    .trim()
    .toLowerCase()
    .replace(/^@+/, '');
}

export function initDatabase(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS colleges (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      city TEXT NOT NULL,
      address TEXT NOT NULL DEFAULT '',
      domain TEXT NOT NULL,
      admin_email TEXT NOT NULL DEFAULT '',
      initial_student_password_hash TEXT NOT NULL DEFAULT '',
      student_access_enabled INTEGER NOT NULL DEFAULT 1,
      latitude REAL NOT NULL DEFAULT 12.83595,
      longitude REAL NOT NULL DEFAULT 80.21845,
      maps_url TEXT NOT NULL DEFAULT '',
      is_primary INTEGER NOT NULL DEFAULT 0,
      zones_json TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      college_id INTEGER NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('user', 'admin')),
      identifier TEXT NOT NULL,
      student_id TEXT,
      full_name TEXT NOT NULL,
      department TEXT NOT NULL DEFAULT 'General Studies',
      password_hash TEXT NOT NULL,
      first_login_completed INTEGER NOT NULL DEFAULT 0,
      is_authorized INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (college_id) REFERENCES colleges(id) ON DELETE CASCADE,
      UNIQUE (college_id, identifier, role)
    );

    CREATE TABLE IF NOT EXISTS items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      college_id INTEGER NOT NULL,
      reporter_user_id INTEGER NOT NULL,
      type TEXT NOT NULL CHECK (type IN ('missing', 'found')),
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      device_type TEXT NOT NULL DEFAULT 'Smartphone',
      brand TEXT NOT NULL DEFAULT '',
      model TEXT NOT NULL DEFAULT '',
      location TEXT NOT NULL,
      latitude REAL,
      longitude REAL,
      description TEXT NOT NULL,
      additional_info TEXT NOT NULL DEFAULT '',
      image_data TEXT,
      status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'matched', 'resolved', 'archived')),
      lifecycle_status TEXT NOT NULL DEFAULT 'submitted',
      report_code TEXT NOT NULL DEFAULT '',
      reported_date TEXT NOT NULL,
      reported_time TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (college_id) REFERENCES colleges(id) ON DELETE CASCADE,
      FOREIGN KEY (reporter_user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS matches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      college_id INTEGER NOT NULL,
      missing_item_id INTEGER NOT NULL,
      found_item_id INTEGER NOT NULL,
      confidence INTEGER NOT NULL DEFAULT 80,
      status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'verified', 'claimed', 'dismissed')),
      notes TEXT NOT NULL DEFAULT '',
      updated_by_admin_id INTEGER,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (college_id) REFERENCES colleges(id) ON DELETE CASCADE,
      FOREIGN KEY (missing_item_id) REFERENCES items(id) ON DELETE CASCADE,
      FOREIGN KEY (found_item_id) REFERENCES items(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      college_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      related_match_id INTEGER,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (college_id) REFERENCES colleges(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS password_reset_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      college_code TEXT NOT NULL,
      identifier TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS student_activities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      college_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      student_email TEXT NOT NULL,
      action_type TEXT NOT NULL,
      summary TEXT NOT NULL,
      related_item_id INTEGER,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (college_id) REFERENCES colleges(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);

  // Safe non-destructive migrations for existing databases
  ensureColumn('colleges', 'address', `TEXT NOT NULL DEFAULT ''`);
  ensureColumn('colleges', 'admin_email', `TEXT NOT NULL DEFAULT ''`);
  ensureColumn('colleges', 'initial_student_password_hash', `TEXT NOT NULL DEFAULT ''`);
  ensureColumn('colleges', 'student_access_enabled', `INTEGER NOT NULL DEFAULT 1`);
  ensureColumn('colleges', 'latitude', `REAL NOT NULL DEFAULT 12.83595`);
  ensureColumn('colleges', 'longitude', `REAL NOT NULL DEFAULT 80.21845`);
  ensureColumn('colleges', 'maps_url', `TEXT NOT NULL DEFAULT ''`);
  ensureColumn('colleges', 'is_primary', `INTEGER NOT NULL DEFAULT 0`);
  ensureColumn('colleges', 'departments_json', `TEXT NOT NULL DEFAULT '[]'`);
  ensureColumn('colleges', 'academic_years_json', `TEXT NOT NULL DEFAULT '[]'`);

  ensureColumn('users', 'first_login_completed', `INTEGER NOT NULL DEFAULT 0`);
  ensureColumn('users', 'academic_year', `TEXT NOT NULL DEFAULT ''`);
  ensureColumn('users', 'profile_completed', `INTEGER NOT NULL DEFAULT 0`);
  ensureColumn('users', 'is_authorized', `INTEGER NOT NULL DEFAULT 1`);

  ensureColumn('items', 'device_type', `TEXT NOT NULL DEFAULT 'Smartphone'`);
  ensureColumn('items', 'brand', `TEXT NOT NULL DEFAULT ''`);
  ensureColumn('items', 'model', `TEXT NOT NULL DEFAULT ''`);
  ensureColumn('items', 'color', `TEXT NOT NULL DEFAULT ''`);
  ensureColumn('items', 'additional_info', `TEXT NOT NULL DEFAULT ''`);
  ensureColumn('items', 'latitude', `REAL`);
  ensureColumn('items', 'longitude', `REAL`);
  ensureColumn('items', 'image_data', `TEXT`);
  ensureColumn('items', 'lifecycle_status', `TEXT NOT NULL DEFAULT 'submitted'`);
  ensureColumn('items', 'report_code', `TEXT NOT NULL DEFAULT ''`);
  ensureColumn('items', 'reported_time', `TEXT NOT NULL DEFAULT ''`);

  ensureColumn('notifications', 'notification_type', `TEXT NOT NULL DEFAULT 'system'`);
  ensureColumn('notifications', 'related_lost_item_id', `INTEGER`);
  ensureColumn('notifications', 'related_found_item_id', `INTEGER`);

  // Match acceptance & physical handover workflow columns (non-destructive)
  ensureColumn('matches', 'workflow_status', `TEXT NOT NULL DEFAULT 'POSSIBLE_MATCH'`);
  ensureColumn('matches', 'accepted_by_user_id', `INTEGER`);
  ensureColumn('matches', 'accepted_at', `TEXT`);
  ensureColumn('matches', 'rejected_by_user_id', `INTEGER`);
  ensureColumn('matches', 'rejected_at', `TEXT`);
  ensureColumn('matches', 'lost_owner_handover_confirmed', `INTEGER NOT NULL DEFAULT 0`);
  ensureColumn('matches', 'lost_owner_handover_at', `TEXT`);
  ensureColumn('matches', 'lost_owner_handover_user_id', `INTEGER`);
  ensureColumn('matches', 'found_owner_handover_confirmed', `INTEGER NOT NULL DEFAULT 0`);
  ensureColumn('matches', 'found_owner_handover_at', `TEXT`);
  ensureColumn('matches', 'found_owner_handover_user_id', `INTEGER`);
  ensureColumn('matches', 'recovered_at', `TEXT`);

  ensureFourInstitutionsAndSeed();
  purgeUnauthorizedDemoRecords();
  enforceMsajceOnlyActive();
  ensureInstitutionAcademicConfig();

  // Backfill report_code and lifecycle_status for any genuine pre-existing items
  const missingCodes = db
    .prepare(
      `SELECT i.id, i.status, i.lifecycle_status, i.report_code, c.code as college_code
       FROM items i JOIN colleges c ON c.id = i.college_id
       WHERE i.report_code = '' OR i.lifecycle_status = ''`
    )
    .all() as { id: number; status: string; lifecycle_status: string; report_code: string; college_code: string }[];

  if (missingCodes.length > 0) {
    const upd = db.prepare(`UPDATE items SET report_code = ?, lifecycle_status = ? WHERE id = ?`);
    const tx = db.transaction(() => {
      for (const row of missingCodes) {
        const code = row.report_code || `CF-${row.college_code}-${String(row.id).padStart(4, '0')}`;
        const lc =
          row.lifecycle_status && row.lifecycle_status !== 'submitted'
            ? row.lifecycle_status
            : mapStatusToLifecycle(row.status);
        upd.run(code, lc, row.id);
      }
    });
    tx();
  }
}

function purgeUnauthorizedDemoRecords(): void {
  const tx = db.transaction(() => {
    // 1. Remove legacy unconfigured demo colleges if present
    db.prepare(`DELETE FROM colleges WHERE code IN ('CAM-TECH', 'WEST-UNI')`).run();

    // 2. Remove ONLY the exact legacy seeded demo items (preserves all genuine user-submitted reports)
    const demoTitles = [
      'iPhone 15 Pro — Natural Titanium',
      'Titanium Smartphone in Clear MagSafe Case',
      'MacBook Air M3 13" — Midnight',
      'Apple AirPods Pro (2nd Gen) Charging Case',
      'Galaxy Watch 6 Classic — Black Strap',
      'Silver Bezel Smartwatch with Black Band',
    ];
    const placeholders = demoTitles.map(() => '?').join(', ');
    db.prepare(`DELETE FROM items WHERE title IN (${placeholders})`).run(...demoTitles);

    // 3. Remove ONLY legacy seeded demo/test notifications and notifications referencing deleted matches
    db.prepare(
      `DELETE FROM notifications
       WHERE (related_match_id IS NOT NULL AND related_match_id NOT IN (SELECT id FROM matches))
          OR message LIKE '%Central Library matches your missing iPhone 15 Pro report%'
          OR message LIKE '%Match #1 (iPhone 15 Pro — Central Library)%'
          OR message LIKE '%Sony WH-1000XM5 Midnight Blue%'`
    ).run();
  });
  tx();
}

function enforceMsajceOnlyActive(): void {
  // Preserve all existing college records while ensuring only MSAJCE is active
  db.prepare(`UPDATE colleges SET student_access_enabled = 1, is_primary = 1 WHERE UPPER(code) = 'MSAJCE'`).run();
  db.prepare(`UPDATE colleges SET student_access_enabled = 0, is_primary = 0 WHERE UPPER(code) != 'MSAJCE'`).run();
}

function ensureInstitutionAcademicConfig(): void {
  const msajceDepts = JSON.stringify([
    'Computer Science and Engineering (CSE)',
    'Artificial Intelligence and Data Science (AI & DS)',
    'Information Technology (IT)',
    'Electronics and Communication Engineering (ECE)',
    'Electrical and Electronics Engineering (EEE)',
    'Mechanical Engineering',
    'Civil Engineering',
    'Architecture (B.Arch)',
    'Master of Business Administration (MBA)',
  ]);
  const msajceYears = JSON.stringify([
    '1st Year',
    '2nd Year',
    '3rd Year',
    '4th Year',
    '5th Year (B.Arch)',
  ]);
  db.prepare(
    `UPDATE colleges
     SET departments_json = CASE WHEN departments_json = '[]' OR departments_json = '' THEN ? ELSE departments_json END,
         academic_years_json = CASE WHEN academic_years_json = '[]' OR academic_years_json = '' THEN ? ELSE academic_years_json END
     WHERE UPPER(code) = 'MSAJCE'`
  ).run(msajceDepts, msajceYears);
}

export function recordStudentActivity(params: {
  collegeId: number;
  userId: number;
  studentEmail: string;
  actionType: 'login' | 'lost_report_submitted' | 'found_report_submitted' | 'password_changed';
  summary: string;
  relatedItemId?: number | null;
}): void {
  db.prepare(
    `INSERT INTO student_activities (college_id, user_id, student_email, action_type, summary, related_item_id)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(
    params.collegeId,
    params.userId,
    params.studentEmail,
    params.actionType,
    params.summary,
    params.relatedItemId ?? null
  );
}

function ensureFourInstitutionsAndSeed(): void {
  const hash = (plain: string) => bcrypt.hashSync(plain, 10);

  const insertCollege = db.prepare(`
    INSERT INTO colleges (
      code, name, city, address, domain, admin_email, initial_student_password_hash,
      student_access_enabled, latitude, longitude, maps_url, is_primary, zones_json
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?)
  `);

  const insertUser = db.prepare(`
    INSERT INTO users (college_id, role, identifier, student_id, full_name, department, password_hash, first_login_completed, is_authorized)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
  `);

  // 1. Primary Institution: Mohamed Sathak A J College of Engineering and Architecture
  const existingMsajce = db
    .prepare(`SELECT id, initial_student_password_hash, admin_email FROM colleges WHERE code = 'MSAJCE'`)
    .get() as { id: number; initial_student_password_hash: string; admin_email: string } | undefined;

  if (!existingMsajce) {
    const msajceBootstrapHash = hash('Student@2026');
    const seedMsajce = db.transaction(() => {
      db.prepare(`UPDATE colleges SET is_primary = 0`).run();

      const msajceId = Number(
        insertCollege.run(
          'MSAJCE',
          'Mohamed Sathak A J College of Engineering and Architecture',
          'Siruseri, Chennai',
          '34, Rajiv Gandhi Salai (OMR), SIPCOT IT Park, Siruseri, Chennai, Tamil Nadu 603103',
          'msajce-edu.in',
          'admin@msajce-edu.in',
          msajceBootstrapHash,
          12.83595,
          80.21845,
          'https://share.google/xphkpUHfbk8wPRPYV',
          1,
          JSON.stringify([
            'Main Academic Block',
            'Architecture Studio Wing',
            'Central Library & Digital Center',
            'CSE & AI Innovation Lab',
            'Auditorium & Seminar Hall',
            'Campus Cafeteria & Quad',
          ])
        ).lastInsertRowid
      );

      insertUser.run(
        msajceId,
        'user',
        'aarav.rahman@msajce-edu.in',
        'MSAJCE-2026-101',
        'Aarav Rahman',
        'Computer Science & Engineering',
        msajceBootstrapHash,
        0
      );

      insertUser.run(
        msajceId,
        'admin',
        'admin@msajce-edu.in',
        'ADM-MSAJCE-01',
        'MSAJCE Administrator',
        'Campus Administration',
        hash('AdminMsajce@2026'),
        1
      );
    });
    seedMsajce();
  } else if (!existingMsajce.initial_student_password_hash || !existingMsajce.admin_email) {
    db.prepare(
      `UPDATE colleges
       SET admin_email = CASE WHEN admin_email = '' THEN 'admin@msajce-edu.in' ELSE admin_email END,
           initial_student_password_hash = CASE WHEN initial_student_password_hash = '' THEN ? ELSE initial_student_password_hash END
       WHERE id = ?`
    ).run(hash('Student@2026'), existingMsajce.id);
  }

  // Ensure 5 distinct authorized student accounts exist for MSAJCE (no demo reports/notifications)
  const msajceRow = db
    .prepare(`SELECT id, initial_student_password_hash FROM colleges WHERE code = 'MSAJCE'`)
    .get() as { id: number; initial_student_password_hash: string } | undefined;
  if (msajceRow) {
    const bootHash = msajceRow.initial_student_password_hash || hash('Student@2026');
    const insertIgnoreUser = db.prepare(`
      INSERT OR IGNORE INTO users (college_id, role, identifier, student_id, full_name, department, password_hash, first_login_completed, is_authorized)
      VALUES (?, 'user', ?, ?, ?, ?, ?, 0, 1)
    `);
    const extraMsajceStudents = [
      ['aarav.rahman@msajce-edu.in', 'MSAJCE-2026-101', 'Aarav Rahman', 'Computer Science & Engineering'],
      ['priya.sharma@msajce-edu.in', 'MSAJCE-2026-102', 'Priya Sharma', 'Electronics & Communication'],
      ['karthik.v@msajce-edu.in', 'MSAJCE-2026-103', 'Karthik Venkatesh', 'Information Technology'],
      ['ananya.s@msajce-edu.in', 'MSAJCE-2026-104', 'Ananya Sundaram', 'Architecture'],
      ['imran.khan@msajce-edu.in', 'MSAJCE-2026-105', 'Imran Khan', 'Mechanical Engineering'],
    ];
    for (const [email, sid, name, dept] of extraMsajceStudents) {
      insertIgnoreUser.run(msajceRow.id, email, sid, name, dept, bootHash);
    }
  }

  // Ensure the other four configured institutions exist with independent domains & login accounts (NO demo reports/matches/notifications)
  const requiredInstitutions = [
    {
      code: 'SRMIST',
      name: 'SRM Institute of Science and Technology',
      city: 'Kattankulathur, Chennai',
      address: 'SRM Nagar, Kattankulathur, Chengalpattu, Tamil Nadu 603203',
      domain: 'srmist.edu.in',
      adminEmail: 'admin@srmist.edu.in',
      adminPassword: 'AdminSrm@2026',
      studentBootstrap: 'SrmStudent@2026',
      studentEmail: 'rohan.kumar@srmist.edu.in',
      studentId: 'RA2611003010045',
      studentName: 'Rohan Kumar',
      studentDept: 'Computer Science & Engineering',
      adminName: 'SRMIST Administrator',
      lat: 12.8230,
      lng: 80.0444,
      zones: [
        'University Building',
        'Tech Park',
        'Central Library',
        'TP Ganesan Auditorium',
        'Java Canteen',
      ],
    },
    {
      code: 'SATHYABAMA',
      name: 'Sathyabama Institute of Science and Technology',
      city: 'Sholinganallur, Chennai',
      address: 'Jeppiaar Nagar, Rajiv Gandhi Salai (OMR), Chennai, Tamil Nadu 600119',
      domain: 'sathyabama.ac.in',
      adminEmail: 'admin@sathyabama.ac.in',
      adminPassword: 'AdminSathyabama@2026',
      studentBootstrap: 'SistStudent@2026',
      studentEmail: 'divya.menon@sathyabama.ac.in',
      studentId: 'SIST-2026-118',
      studentName: 'Divya Menon',
      studentDept: 'Electronics & Communication',
      adminName: 'Sathyabama Administrator',
      lat: 12.8729,
      lng: 80.2261,
      zones: [
        'Main Administrative Block',
        'Central Library',
        'Centre for Ocean Research',
        'Engineering Academic Wing',
        'Campus Mess & Plaza',
      ],
    },
    {
      code: 'CRESCENT',
      name: 'B.S. Abdur Rahman Crescent Institute of Science and Technology',
      city: 'Vandalur, Chennai',
      address: 'GST Road, Vandalur, Chennai, Tamil Nadu 600048',
      domain: 'crescent.education',
      adminEmail: 'admin@crescent.education',
      adminPassword: 'AdminCrescent@2026',
      studentBootstrap: 'Crescent@2026',
      studentEmail: 'farhan.ali@crescent.education',
      studentId: 'CRES-2026-209',
      studentName: 'Farhan Ali',
      studentDept: 'Information Technology',
      adminName: 'Crescent Administrator',
      lat: 12.8753,
      lng: 80.0837,
      zones: [
        'Convention Centre',
        'Crescent School of Architecture',
        'Central Library',
        'Computer Science Block',
        'Student Activity Centre',
      ],
    },
    {
      code: 'SSN',
      name: 'Sri Sivasubramaniya Nadar College of Engineering',
      city: 'Kalavakkam, Chennai',
      address: 'Rajiv Gandhi Salai (OMR), Kalavakkam, Tamil Nadu 603110',
      domain: 'ssn.edu.in',
      adminEmail: 'admin@ssn.edu.in',
      adminPassword: 'AdminSsn@2026',
      studentBootstrap: 'SsnStudent@2026',
      studentEmail: 'kavya.nair@ssn.edu.in',
      studentId: 'SSN-2026-142',
      studentName: 'Kavya Nair',
      studentDept: 'Computer Science & Engineering',
      adminName: 'SSN Administrator',
      lat: 12.7520,
      lng: 80.1973,
      zones: [
        'Clock Tower & Main Lawn',
        'Central Library',
        'CSE Department Block',
        'Main Auditorium',
        'Student Canteen',
      ],
    },
  ];

  for (const inst of requiredInstitutions) {
    const exists = db.prepare(`SELECT id FROM colleges WHERE code = ?`).get(inst.code) as
      | { id: number }
      | undefined;
    if (!exists) {
      const bootHash = hash(inst.studentBootstrap);
      const seedInst = db.transaction(() => {
        const collegeId = Number(
          insertCollege.run(
            inst.code,
            inst.name,
            inst.city,
            inst.address,
            inst.domain,
            inst.adminEmail,
            bootHash,
            inst.lat,
            inst.lng,
            '',
            0,
            JSON.stringify(inst.zones)
          ).lastInsertRowid
        );

        insertUser.run(
          collegeId,
          'user',
          inst.studentEmail,
          inst.studentId,
          inst.studentName,
          inst.studentDept,
          bootHash,
          0
        );

        insertUser.run(
          collegeId,
          'admin',
          inst.adminEmail,
          `ADM-${inst.code}-01`,
          inst.adminName,
          'Campus Administration',
          hash(inst.adminPassword),
          1
        );
      });
      seedInst();
    }
  }
}
