import type { Response } from 'express';

export type RealtimeEventType =
  | 'connected'
  | 'report:created'
  | 'report:updated'
  | 'report:deleted'
  | 'match:created'
  | 'match:updated'
  | 'notification:created'
  | 'institution:updated'
  | 'activity:created';

interface ConnectedClient {
  id: string;
  collegeId: number;
  userId: number;
  role: 'user' | 'admin';
  res: Response;
}

const clients = new Set<ConnectedClient>();
let clientSeq = 1;

export function registerRealtimeClient(
  collegeId: number,
  userId: number,
  role: 'user' | 'admin',
  res: Response
): () => void {
  const id = `sse_${Date.now()}_${clientSeq++}`;
  const client: ConnectedClient = { id, collegeId, userId, role, res };
  clients.add(client);

  // Send initial connected handshake
  sendPayload(client, 'connected', {
    clientId: id,
    collegeId,
    role,
    timestamp: new Date().toISOString(),
  });

  // Heartbeat every 25s to keep proxy/iframe SSE connections alive
  const heartbeat = setInterval(() => {
    try {
      res.write(`: heartbeat ${Date.now()}\n\n`);
    } catch {
      cleanup();
    }
  }, 25000);

  const cleanup = () => {
    clearInterval(heartbeat);
    clients.delete(client);
  };

  return cleanup;
}

function sendPayload(client: ConnectedClient, event: RealtimeEventType, data: Record<string, unknown>): void {
  try {
    const payload = JSON.stringify({
      event,
      timestamp: new Date().toISOString(),
      ...data,
    });
    client.res.write(`event: ${event}\ndata: ${payload}\n\n`);
  } catch {
    clients.delete(client);
  }
}

export function broadcastToCollege(
  collegeId: number,
  event: RealtimeEventType,
  data: Record<string, unknown>,
  filter?: (client: ConnectedClient) => boolean
): void {
  for (const client of clients) {
    if (client.collegeId !== collegeId) continue;
    if (filter && !filter(client)) continue;
    sendPayload(client, event, data);
  }
}

export function broadcastToAdmins(
  collegeId: number,
  event: RealtimeEventType,
  data: Record<string, unknown>
): void {
  broadcastToCollege(collegeId, event, data, (c) => c.role === 'admin');
}

export function broadcastToUser(
  collegeId: number,
  userId: number,
  event: RealtimeEventType,
  data: Record<string, unknown>
): void {
  broadcastToCollege(collegeId, event, data, (c) => c.userId === userId);
}
