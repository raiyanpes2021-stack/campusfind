import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Wifi, BatteryFull } from 'lucide-react';
import type { AuthUser, BeamScreenState, CollegeSummary, LoginRole } from '../../types/campusfind';
import { UserLogin } from './UserLogin';
import { CollegeAdminLogin } from './CollegeAdminLogin';

interface AuthenticationPanelProps {
  colleges: CollegeSummary[];
  beam: BeamScreenState;
  introComplete: boolean;
  onAuthSuccess: (user: AuthUser, college: CollegeSummary) => void;
}

export function AuthenticationPanel({
  colleges,
  beam,
  introComplete,
  onAuthSuccess,
}: AuthenticationPanelProps) {
  const [role, setRole] = useState<LoginRole>('user');

  const reveal = introComplete ? 1 : Math.min(1, Math.max(0, beam.panelReveal));
  const scale = introComplete ? 1 : 0.86 + reveal * 0.14;
  const translateY = introComplete ? 0 : (1 - reveal) * 28;

  return (
    <div
      className="w-full max-w-[390px] mx-auto transition-all duration-500 ease-out"
      style={{
        opacity: reveal,
        transform: `translateY(${translateY}px) scale(${scale})`,
      }}
    >
      {/* Realistic Smartphone Chassis */}
      <div className="relative rounded-[44px] bg-[#142322] p-[11px] shadow-[0_32px_80px_rgba(23,76,74,0.22),0_6px_20px_rgba(28,37,36,0.14)] ring-1 ring-[#174C4A]/30">
        {/* Side Hardware Buttons */}
        <div
          className="hidden sm:block absolute -left-[3px] top-24 w-[3px] h-9 rounded-l-sm bg-[#27403E]"
          aria-hidden="true"
        />
        <div
          className="hidden sm:block absolute -left-[3px] top-36 w-[3px] h-12 rounded-l-sm bg-[#27403E]"
          aria-hidden="true"
        />
        <div
          className="hidden sm:block absolute -right-[3px] top-32 w-[3px] h-14 rounded-r-sm bg-[#27403E]"
          aria-hidden="true"
        />

        {/* Smartphone Display Screen — Warm Ivory (#F4F1E8) */}
        <div className="relative rounded-[34px] bg-[#F4F1E8] overflow-hidden border border-[#E5DEC9]/60">
          {/* Status Bar & Dynamic Camera Pill */}
          <div className="px-6 pt-3 pb-2 flex items-center justify-between text-[11px] font-semibold text-[#174C4A]">
            <span className="font-mono-tabular">9:41</span>
            <div className="w-24 h-5 rounded-full bg-[#142322] flex items-center justify-end pr-2">
              <span className="w-2 h-2 rounded-full bg-[#1F3A38] ring-1 ring-[#2D5552]" />
            </div>
            <div className="flex items-center gap-1.5">
              <Wifi className="w-3.5 h-3.5" />
              <BatteryFull className="w-4 h-4" />
            </div>
          </div>

          {/* App Header inside the Phone */}
          <div className="px-6 pt-3 pb-4 text-center">
            <div className="w-12 h-12 rounded-2xl bg-[#174C4A] mx-auto flex items-center justify-center shadow-sm">
              <svg
                viewBox="0 0 24 24"
                className="w-6 h-6 text-[#F4F1E8]"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.1"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <circle cx="11" cy="11" r="6.5" />
                <path d="M16 16l4 4" stroke="#D98252" strokeWidth="2.4" />
                <circle cx="11" cy="11" r="2" fill="#D98252" stroke="none" />
              </svg>
            </div>
            <h1 className="mt-2.5 font-display text-xl font-bold tracking-tight text-[#174C4A]">
              CampusFind
            </h1>
          </div>

          {/* Two-Role Segmented Switcher */}
          <div className="px-5">
            <div
              role="tablist"
              aria-label="Login role selection"
              className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-[#EAE4D5] border border-[#DDD5C2]"
            >
              <button
                type="button"
                role="tab"
                aria-selected={role === 'user'}
                onClick={() => setRole('user')}
                className={`h-9 px-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  role === 'user'
                    ? 'bg-[#174C4A] text-[#F4F1E8] shadow-xs'
                    : 'text-[#55615F] hover:text-[#174C4A]'
                }`}
              >
                Student Login
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={role === 'admin'}
                onClick={() => setRole('admin')}
                className={`h-9 px-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  role === 'admin'
                    ? 'bg-[#174C4A] text-[#F4F1E8] shadow-xs'
                    : 'text-[#55615F] hover:text-[#174C4A]'
                }`}
              >
                College Admin
              </button>
            </div>
          </div>

          {/* Login Form Body */}
          <div className="px-5 pt-4 pb-5">
            <AnimatePresence mode="wait">
              <motion.div
                key={role}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
              >
                {role === 'user' ? (
                  <UserLogin colleges={colleges} onAuthSuccess={onAuthSuccess} />
                ) : (
                  <CollegeAdminLogin colleges={colleges} onAuthSuccess={onAuthSuccess} />
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Bottom Home Indicator Bar */}
          <div className="pb-3 pt-1 flex justify-center">
            <div className="w-28 h-1 rounded-full bg-[#D98252]/70" />
          </div>
        </div>
      </div>
    </div>
  );
}
