import { useState, type FormEvent } from 'react';
import {
  Eye,
  EyeOff,
  Loader2,
  ArrowRight,
  Building2,
  Mail,
  Lock,
  AlertCircle,
} from 'lucide-react';
import { campusApi } from '../../lib/api';
import type { AuthUser, CollegeSummary } from '../../types/campusfind';

interface UserLoginProps {
  colleges: CollegeSummary[];
  onAuthSuccess: (user: AuthUser, college: CollegeSummary) => void;
}

export function UserLogin({ colleges, onAuthSuccess }: UserLoginProps) {
  const [mode, setMode] = useState<'login' | 'forgot'>('login');
  const activeCollege =
    colleges.find((c) => c.code === 'MSAJCE') ||
    colleges.find((c) => c.studentAccessEnabled !== false) ||
    colleges[0];
  const [collegeCode, setCollegeCode] = useState(activeCollege?.code || 'MSAJCE');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const selectedCode =
    colleges.find((c) => c.code === collegeCode && c.studentAccessEnabled !== false)?.code ||
    activeCollege?.code ||
    'MSAJCE';
  const selectedCollege = colleges.find((c) => c.code === selectedCode) || activeCollege;
  const domainHint = selectedCollege?.domain || 'msajce-edu.in';
  const accessDisabled = selectedCollege?.studentAccessEnabled === false;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!selectedCode) {
      setError('Please select your college institution.');
      return;
    }

    setLoading(true);
    try {
      if (mode === 'forgot') {
        const res = await campusApi.forgotPassword({
          collegeCode: selectedCode,
          identifier: identifier.trim(),
        });
        setSuccess(res.message);
      } else {
        const res = await campusApi.login({
          collegeCode: selectedCode,
          identifier: identifier.trim(),
          password,
          role: 'user',
          rememberMe,
        });
        setSuccess(`Welcome to ${res.college.code}. Opening portal...`);
        setTimeout(() => onAuthSuccess(res.user, res.college), 220);
      }
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Authentication failed. Please check your credentials.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3.5">
      <div className="space-y-1">
        <label htmlFor="user-college" className="block text-[11px] font-semibold text-[#174C4A]">
          College Institution
        </label>
        <div className="relative">
          <Building2 className="w-4 h-4 text-[#174C4A] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <select
            id="user-college"
            value={selectedCode}
            onChange={(e) => {
              setCollegeCode(e.target.value);
              setError(null);
              setSuccess(null);
            }}
            required
            className="w-full h-10 pl-9 pr-3 rounded-xl bg-white border border-[#D8D0BE] text-xs font-medium text-[#1C2524] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15 transition-all"
          >
            {colleges.map((c) => {
              const disabled = c.code !== 'MSAJCE' || c.studentAccessEnabled === false;
              return (
                <option
                  key={c.code}
                  value={c.code}
                  disabled={disabled}
                  className="bg-white text-[#1C2524]"
                >
                  {c.name} ({c.code}){disabled ? ' — Disabled' : ''}
                </option>
              );
            })}
          </select>
        </div>
        <p className="text-[11px] text-[#55615F]">
          Use any valid <span className="font-semibold text-[#174C4A]">@{domainHint}</span> college email ID.
        </p>
      </div>

      {accessDisabled && (
        <div className="px-3 py-2 rounded-xl bg-[#D98252]/15 border border-[#D98252]/40 text-[11px] text-[#7A3A1B] flex items-start gap-2">
          <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-[#D98252]" />
          <span>This institution is currently disabled. Only MSAJCE is active.</span>
        </div>
      )}

      <div className="space-y-1">
        <label htmlFor="user-identifier" className="block text-[11px] font-semibold text-[#174C4A]">
          College Email ID
        </label>
        <div className="relative">
          <Mail className="w-4 h-4 text-[#55615F] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id="user-identifier"
            type="email"
            required
            autoComplete="username"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            placeholder={`username@${domainHint}`}
            className="w-full h-10 pl-9 pr-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15 transition-all"
          />
        </div>
      </div>

      {mode === 'login' && (
        <div className="space-y-1">
          <label htmlFor="user-password" className="block text-[11px] font-semibold text-[#174C4A]">
            Password
          </label>
          <div className="relative">
            <Lock className="w-4 h-4 text-[#55615F] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id="user-password"
              type={showPassword ? 'text' : 'password'}
              required
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter institutional or personal password"
              className="w-full h-10 pl-9 pr-10 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15 transition-all"
            />
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              aria-label={showPassword ? 'Hide password' : 'Show password'}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 flex items-center justify-center rounded-lg text-[#55615F] hover:text-[#174C4A] transition-colors cursor-pointer"
            >
              {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      )}

      {mode === 'login' ? (
        <div className="flex items-center justify-between text-[11px]">
          <label className="inline-flex items-center gap-1.5 text-[#55615F] cursor-pointer select-none">
            <input
              type="checkbox"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="w-3.5 h-3.5 rounded border-[#C8BFB0] accent-[#174C4A]"
            />
            <span>Remember me</span>
          </label>
          <button
            type="button"
            onClick={() => {
              setError(null);
              setSuccess(null);
              setMode('forgot');
            }}
            className="text-[#D98252] hover:text-[#B96436] font-medium transition-colors cursor-pointer"
          >
            Forgot password?
          </button>
        </div>
      ) : (
        <div className="flex justify-end text-[11px]">
          <button
            type="button"
            onClick={() => {
              setError(null);
              setSuccess(null);
              setMode('login');
            }}
            className="text-[#174C4A] hover:underline font-medium cursor-pointer"
          >
            Back to Student Sign In
          </button>
        </div>
      )}

      {error && (
        <div
          role="alert"
          className="px-3 py-2 rounded-xl bg-[#D98252]/15 border border-[#D98252]/40 text-[11px] text-[#7A3A1B] leading-relaxed"
        >
          {error}
        </div>
      )}

      {success && (
        <div
          role="status"
          className="px-3 py-2 rounded-xl bg-[#174C4A]/10 border border-[#174C4A]/25 text-[11px] text-[#174C4A] leading-relaxed"
        >
          {success}
        </div>
      )}

      <button
        type="submit"
        disabled={loading || accessDisabled}
        className="w-full h-10 px-4 rounded-xl bg-[#174C4A] text-[#F4F1E8] font-semibold text-xs flex items-center justify-center gap-2 hover:bg-[#123D3B] active:scale-[0.99] disabled:opacity-55 disabled:cursor-not-allowed transition-all shadow-sm cursor-pointer"
      >
        {loading ? (
          <>
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
            <span>{mode === 'forgot' ? 'Submitting request...' : 'Signing in...'}</span>
          </>
        ) : (
          <>
            <span>{mode === 'forgot' ? 'Request Password Reset' : 'Sign In'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </>
        )}
      </button>

      <p className="text-[11px] text-[#55615F] text-center leading-relaxed pt-0.5">
        Access is managed by your College Administrator using institutional email credentials.
      </p>
    </form>
  );
}
