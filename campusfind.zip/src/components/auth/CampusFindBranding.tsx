import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import type { BeamScreenState } from '../../types/campusfind';

interface CampusFindBrandingProps {
  beam: BeamScreenState;
  introComplete: boolean;
}

interface CampusNodeDef {
  label: string;
  pos: [number, number, number];
}

const CAMPUS_NODES: CampusNodeDef[] = [
  { label: 'Central Library', pos: [-1.45, 0.55, 0.25] },
  { label: 'Engineering Hall', pos: [0.15, 0.95, -0.3] },
  { label: 'Student Commons', pos: [1.55, 0.35, 0.2] },
  { label: 'Innovation Labs', pos: [-0.85, -0.65, 0.45] },
  { label: 'North Quad', pos: [0.9, -0.7, -0.25] },
  { label: 'Transit Hub', pos: [0.05, 0.05, 0.65] },
];

const CAMPUS_EDGES: [number, number][] = [
  [0, 1],
  [1, 2],
  [0, 3],
  [3, 5],
  [5, 1],
  [5, 2],
  [5, 4],
  [4, 2],
  [3, 4],
];

function detectSoftwareGl(): boolean {
  try {
    const gl = document.createElement('canvas').getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export function CampusFindBranding({ beam, introComplete }: CampusFindBrandingProps) {
  const networkCanvasRef = useRef<HTMLDivElement | null>(null);
  const labelRefs = useRef<(HTMLDivElement | null)[]>([]);

  const logoVisible = introComplete ? 1 : beam.logoReveal;
  const headingVisible = introComplete ? 1 : beam.headingReveal;

  useEffect(() => {
    const container = networkCanvasRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareGl();
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: !isSoftwareGl, alpha: true });
    } catch {
      return;
    }

    const width = container.clientWidth || 460;
    const height = container.clientHeight || 280;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, width / Math.max(1, height), 0.1, 50);
    camera.position.set(0, 0.25, 4.35);

    const networkGroup = new THREE.Group();
    scene.add(networkGroup);

    // Subtle ground architectural ring
    const ringGeo = new THREE.RingGeometry(1.75, 1.775, 64);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x22d3ee,
      transparent: true,
      opacity: 0.18,
      side: THREE.DoubleSide,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2 - 0.15;
    ring.position.y = -0.85;
    networkGroup.add(ring);

    // Node markers (outer glass shell + bright cyan core)
    const nodeCoreGeo = new THREE.SphereGeometry(0.075, 16, 16);
    const nodeHaloGeo = new THREE.SphereGeometry(0.145, 16, 16);
    const nodeCoreMat = new THREE.MeshBasicMaterial({ color: 0x67e8f9 });
    const nodeHaloMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      transparent: true,
      opacity: 0.24,
    });

    const nodeVectors = CAMPUS_NODES.map((n) => new THREE.Vector3(...n.pos));
    const nodeMeshes: THREE.Mesh[] = [];

    nodeVectors.forEach((vec) => {
      const core = new THREE.Mesh(nodeCoreGeo, nodeCoreMat);
      core.position.copy(vec);
      const halo = new THREE.Mesh(nodeHaloGeo, nodeHaloMat);
      halo.position.copy(vec);
      networkGroup.add(core, halo);
      nodeMeshes.push(core);
    });

    // Connected campus edges
    const edgePositions: number[] = [];
    for (const [a, b] of CAMPUS_EDGES) {
      edgePositions.push(
        nodeVectors[a].x,
        nodeVectors[a].y,
        nodeVectors[a].z,
        nodeVectors[b].x,
        nodeVectors[b].y,
        nodeVectors[b].z
      );
    }
    const edgeGeo = new THREE.BufferGeometry();
    edgeGeo.setAttribute('position', new THREE.Float32BufferAttribute(edgePositions, 3));
    const edgeMat = new THREE.LineBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.38,
    });
    const edgeLines = new THREE.LineSegments(edgeGeo, edgeMat);
    networkGroup.add(edgeLines);

    // Animated signal pulse travelling along edges
    const pulseGeo = new THREE.SphereGeometry(0.042, 10, 10);
    const pulseMat = new THREE.MeshBasicMaterial({ color: 0xe0faff });
    const pulses = CAMPUS_EDGES.slice(0, 4).map(() => {
      const m = new THREE.Mesh(pulseGeo, pulseMat);
      networkGroup.add(m);
      return m;
    });

    const _proj = new THREE.Vector3();
    let pointerX = 0;
    let pointerY = 0;
    const onPointerMove = (e: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      pointerX = ((e.clientX - rect.left) / Math.max(1, rect.width) - 0.5) * 2;
      pointerY = ((e.clientY - rect.top) / Math.max(1, rect.height) - 0.5) * 2;
    };
    window.addEventListener('pointermove', onPointerMove);

    let disposed = false;
    let frameId = 0;
    const start = performance.now();

    const afterDraw = (cb: () => void) => {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 6);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 85);
        }
      };
      frameId = window.setTimeout(poll, 6);
    };

    const tick = () => {
      if (disposed) return;
      const elapsed = (performance.now() - start) / 1000;

      const targetRotY = elapsed * 0.14 + pointerX * 0.18;
      const targetRotX = 0.08 + pointerY * 0.1;
      networkGroup.rotation.y += (targetRotY - networkGroup.rotation.y) * 0.08;
      networkGroup.rotation.x += (targetRotX - networkGroup.rotation.x) * 0.08;

      pulses.forEach((pulse, idx) => {
        const [a, b] = CAMPUS_EDGES[idx * 2];
        const t = (elapsed * 0.42 + idx * 0.27) % 1;
        pulse.position.lerpVectors(nodeVectors[a], nodeVectors[b], t);
      });

      networkGroup.updateMatrixWorld(true);
      renderer.render(scene, camera);

      // Update floating HTML location markers synced to 3D node positions
      const cw = container.clientWidth || width;
      const ch = container.clientHeight || height;
      nodeMeshes.forEach((mesh, i) => {
        const el = labelRefs.current[i];
        if (!el) return;
        mesh.getWorldPosition(_proj);
        _proj.project(camera);
        const sx = (_proj.x * 0.5 + 0.5) * cw;
        const sy = (-_proj.y * 0.5 + 0.5) * ch;
        el.style.transform = `translate3d(${sx.toFixed(1)}px, ${(sy - 18).toFixed(1)}px, 0) translate(-50%, -100%)`;
        el.style.opacity = _proj.z < 1 ? '0.92' : '0';
      });

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    const onResize = () => {
      if (!container || disposed) return;
      const w = container.clientWidth || 460;
      const h = Math.max(1, container.clientHeight || 280);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    frameId = requestAnimationFrame(tick);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('resize', onResize);
      ringGeo.dispose();
      ringMat.dispose();
      nodeCoreGeo.dispose();
      nodeHaloGeo.dispose();
      nodeCoreMat.dispose();
      nodeHaloMat.dispose();
      edgeGeo.dispose();
      edgeMat.dispose();
      pulseGeo.dispose();
      pulseMat.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div className="flex flex-col justify-between h-full py-4 lg:py-8 pr-0 lg:pr-8">
      {/* Brand Wordmark & Heading */}
      <div
        className="space-y-6 transition-all duration-700"
        style={{
          opacity: Math.max(0.12, logoVisible),
          transform: `translateY(${(1 - logoVisible) * 14}px)`,
        }}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-[#0D1B30] border border-[#00C8FF]/35 flex items-center justify-center shadow-[0_0_24px_rgba(0,200,255,0.2)]">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <circle cx="11" cy="11" r="6.5" stroke="#00C8FF" strokeWidth="1.9" />
              <circle cx="11" cy="11" r="2.2" fill="#99ECFF" />
              <path d="M16.2 16.2L20.5 20.5" stroke="#00C8FF" strokeWidth="2.1" strokeLinecap="round" />
            </svg>
          </div>
          <span className="font-display text-2xl font-semibold tracking-tight text-white">
            CampusFind
          </span>
        </div>

        <div
          className="space-y-4 transition-all duration-700"
          style={{
            opacity: Math.max(0.08, headingVisible),
            transform: `translateY(${(1 - headingVisible) * 16}px)`,
          }}
        >
          <h1
            className="font-display text-4xl sm:text-5xl font-semibold tracking-tight text-white leading-[1.12] max-w-xl"
            style={{ textWrap: 'balance' }}
          >
            Illuminate what matters across the campus.
          </h1>
          <p className="text-base sm:text-lg text-slate-300/90 leading-relaxed max-w-lg">
            AI-Powered Smart Lost &amp; Found Device Platform for Mohamed Sathak A.J. College of Engineering and Architecture. Report, discover, verify, and recover lost electronic devices in real time.
          </p>
        </div>
      </div>

      {/* 3D Campus Network Visualization with floating location markers */}
      <div
        className="relative mt-8 lg:mt-10 w-full h-64 sm:h-72 rounded-2xl border border-[#00C8FF]/20 bg-[#0D1B30]/80 overflow-hidden transition-all duration-700"
        style={{
          opacity: Math.max(0.05, headingVisible),
          transform: `translateY(${(1 - headingVisible) * 18}px)`,
        }}
      >
        <div ref={networkCanvasRef} className="w-full h-full" aria-hidden="true" />

        {/* Synchronized floating campus node labels */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          {CAMPUS_NODES.map((node, i) => (
            <div
              key={node.label}
              ref={(el) => {
                labelRefs.current[i] = el;
              }}
              className="absolute top-0 left-0 text-[11px] font-medium tracking-wide text-cyan-100/90 whitespace-nowrap px-2 py-0.5 rounded bg-[#071426]/90 border border-[#00C8FF]/25"
              style={{ willChange: 'transform', opacity: 0 }}
            >
              {node.label}
            </div>
          ))}
        </div>

        <div className="pointer-events-none absolute bottom-3.5 left-4 right-4 flex items-center justify-between text-xs text-slate-400">
          <span>Connected Campus Network</span>
          <span>Live Institutional Recovery</span>
        </div>
      </div>
    </div>
  );
}
