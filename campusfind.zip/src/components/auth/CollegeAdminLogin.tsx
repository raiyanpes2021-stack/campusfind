import { useState, type FormEvent } from 'react';
import { Eye, EyeOff, Loader2, ShieldCheck, Building2, KeyRound, Lock } from 'lucide-react';
import { campusApi } from '../../lib/api';
import type { AuthUser, CollegeSummary } from '../../types/campusfind';

interface CollegeAdminLoginProps {
  colleges: CollegeSummary[];
  onAuthSuccess: (user: AuthUser, college: CollegeSummary) => void;
}

export function CollegeAdminLogin({ colleges, onAuthSuccess }: CollegeAdminLoginProps) {
  const activeCollege =
    colleges.find((c) => c.code === 'MSAJCE') ||
    colleges.find((c) => c.studentAccessEnabled !== false) ||
    colleges[0];
  const [collegeCode, setCollegeCode] = useState(activeCollege?.code || 'MSAJCE');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const selectedCode =
    colleges.find((c) => c.code === collegeCode && c.code === 'MSAJCE')?.code ||
    activeCollege?.code ||
    'MSAJCE';
  const selectedCollege = colleges.find((c) => c.code === selectedCode) || activeCollege;
  const domainHint = selectedCollege?.domain || 'msajce-edu.in';

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!selectedCode) {
      setError('Please select your college institution.');
      return;
    }

    setLoading(true);
    try {
      const res = await campusApi.login({
        collegeCode: selectedCode,
        identifier: identifier.trim(),
        password,
        role: 'admin',
        rememberMe,
      });
      setSuccess(`Verified administrator for ${res.college.code}. Opening console...`);
      setTimeout(() => onAuthSuccess(res.user, res.college), 220);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Invalid college administrator credentials for this institution.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3.5">
      <div className="space-y-1">
        <label htmlFor="admin-college" className="block text-[11px] font-semibold text-[#174C4A]">
          Assigned College Institution
        </label>
        <div className="relative">
          <Building2 className="w-4 h-4 text-[#174C4A] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <select
            id="admin-college"
            value={selectedCode}
            onChange={(e) => {
              setCollegeCode(e.target.value);
              setError(null);
              setSuccess(null);
            }}
            required
            className="w-full h-10 pl-9 pr-3 rounded-xl bg-white border border-[#D8D0BE] text-xs font-medium text-[#1C2524] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15 transition-all"
          >
            {colleges.map((c) => {
              const disabled = c.code !== 'MSAJCE' || c.studentAccessEnabled === false;
              return (
                <option
                  key={c.code}
                  value={c.code}
                  disabled={disabled}
                  className="bg-white text-[#1C2524]"
                >
                  {c.name} ({c.code}){disabled ? ' — Disabled' : ''}
                </option>
              );
            })}
          </select>
        </div>
      </div>

      <div className="space-y-1">
        <label htmlFor="admin-identifier" className="block text-[11px] font-semibold text-[#174C4A]">
          Administrator Email or ID
        </label>
        <div className="relative">
          <KeyRound className="w-4 h-4 text-[#55615F] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id="admin-identifier"
            type="text"
            required
            autoComplete="username"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            placeholder={`admin@${domainHint}`}
            className="w-full h-10 pl-9 pr-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15 transition-all"
          />
        </div>
      </div>

      <div className="space-y-1">
        <label htmlFor="admin-password" className="block text-[11px] font-semibold text-[#174C4A]">
          Administrator Password
        </label>
        <div className="relative">
          <Lock className="w-4 h-4 text-[#55615F] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id="admin-password"
            type={showPassword ? 'text' : 'password'}
            required
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter administrator password"
            className="w-full h-10 pl-9 pr-10 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15 transition-all"
          />
          <button
            type="button"
            onClick={() => setShowPassword((v) => !v)}
            aria-label={showPassword ? 'Hide password' : 'Show password'}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 flex items-center justify-center rounded-lg text-[#55615F] hover:text-[#174C4A] transition-colors cursor-pointer"
          >
            {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      <label className="inline-flex items-center gap-1.5 text-[11px] text-[#55615F] cursor-pointer select-none">
        <input
          type="checkbox"
          checked={rememberMe}
          onChange={(e) => setRememberMe(e.target.checked)}
          className="w-3.5 h-3.5 rounded border-[#C8BFB0] accent-[#174C4A]"
        />
        <span>Keep administrator session active</span>
      </label>

      {error && (
        <div
          role="alert"
          className="px-3 py-2 rounded-xl bg-[#D98252]/15 border border-[#D98252]/40 text-[11px] text-[#7A3A1B] leading-relaxed"
        >
          {error}
        </div>
      )}

      {success && (
        <div
          role="status"
          className="px-3 py-2 rounded-xl bg-[#174C4A]/10 border border-[#174C4A]/25 text-[11px] text-[#174C4A] leading-relaxed"
        >
          {success}
        </div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="w-full h-10 px-4 rounded-xl bg-[#174C4A] text-[#F4F1E8] font-semibold text-xs flex items-center justify-center gap-2 hover:bg-[#123D3B] active:scale-[0.99] disabled:opacity-55 disabled:cursor-not-allowed transition-all shadow-sm cursor-pointer"
      >
        {loading ? (
          <>
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
            <span>Verifying administrator...</span>
          </>
        ) : (
          <>
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Sign In as Admin</span>
          </>
        )}
      </button>

      <p className="text-[11px] text-[#55615F] text-center leading-relaxed pt-0.5">
        Institutional access is isolated per college with verified administrator roles.
      </p>
    </form>
  );
}
