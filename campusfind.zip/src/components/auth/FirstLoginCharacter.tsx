import { useEffect, useRef, useState, type FormEvent } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  ArrowRight,
  Building2,
  CheckCircle2,
  Eye,
  EyeOff,
  GraduationCap,
  KeyRound,
  Loader2,
  User as UserIcon,
} from 'lucide-react';
import { createRealisticStudentCharacter } from '../cinematic/RealisticStudentCharacter';
import { campusApi } from '../../lib/api';
import type { AuthUser, CollegeSummary } from '../../types/campusfind';

interface FirstLoginCharacterProps {
  user: AuthUser;
  college: CollegeSummary;
  onComplete: (updatedUser: AuthUser) => void;
}

type OnboardingStep = 'prompt' | 'change-password' | 'profile-setup' | 'thanks';

export function FirstLoginCharacter({ user, college, onComplete }: FirstLoginCharacterProps) {
  const initialStep: OnboardingStep = !user.firstLoginCompleted ? 'prompt' : 'profile-setup';
  const stageRef = useRef<HTMLDivElement | null>(null);
  const pointerRef = useRef({ x: 0, y: 0 });
  const stepRef = useRef<OnboardingStep>(initialStep);
  const [step, setStep] = useState<OnboardingStep>(initialStep);
  const [webglReady, setWebglReady] = useState(true);

  const departments =
    college.departments && college.departments.length > 0
      ? college.departments
      : [
          'Computer Science and Engineering',
          'Information Technology',
          'Artificial Intelligence and Data Science',
          'Electronics and Communication Engineering',
          'Electrical and Electronics Engineering',
          'Mechanical Engineering',
          'Civil Engineering',
        ];
  const academicYears =
    college.academicYears && college.academicYears.length > 0
      ? college.academicYears
      : ['1st Year', '2nd Year', '3rd Year', '4th Year'];

  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [studentName, setStudentName] = useState(
    user.fullName && !user.fullName.includes('@') ? user.fullName : ''
  );
  const [department, setDepartment] = useState(
    user.department && departments.includes(user.department) ? user.department : ''
  );
  const [academicYear, setAcademicYear] = useState(
    user.academicYear && academicYears.includes(user.academicYear) ? user.academicYear : ''
  );
  const [completedUser, setCompletedUser] = useState<AuthUser>(user);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    stepRef.current = step;
  }, [step]);

  // Render lifelike 3D college student character in a Warm Ivory college corridor backdrop
  useEffect(() => {
    const container = stageRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    } catch {
      setWebglReady(false);
      return;
    }

    const gl = renderer.getContext();
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    const gpuStr = dbg ? String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL)) : '';
    const isSoftwareGl = /SwiftShader|llvmpipe|Software/i.test(gpuStr);

    const w = container.clientWidth || 340;
    const h = container.clientHeight || 400;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, isSoftwareGl ? 1 : 2));
    renderer.setSize(w, h);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.04;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTarget = pmrem.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envTarget.texture;
    pmrem.dispose();

    // Portrait framing from waist-up with natural 35mm lens feel
    const camera = new THREE.PerspectiveCamera(30, w / Math.max(1, h), 0.1, 25);
    camera.position.set(0.06, 1.49, 1.52);
    camera.lookAt(0, 1.4, 0);

    // Three-point studio lighting calibrated for natural skin & fabric depth
    const hemi = new THREE.HemisphereLight(0xfffaf2, 0xd8cfc0, 1.15);
    scene.add(hemi);

    const keyLight = new THREE.DirectionalLight(0xfff6e9, 1.75);
    keyLight.position.set(1.8, 2.8, 2.4);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.bias = -0.0004;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xdce8e7, 0.65);
    fillLight.position.set(-2.2, 1.9, 1.6);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xf6d3b8, 0.55);
    rimLight.position.set(-0.9, 2.2, -1.8);
    scene.add(rimLight);

    // Subtle Warm Ivory college corridor architectural backdrop
    const backdropGroup = new THREE.Group();
    const wallMat = new THREE.MeshStandardMaterial({ color: '#ece6da', roughness: 0.92 });
    const trimMat = new THREE.MeshStandardMaterial({ color: '#174C4A', roughness: 0.72 });
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: '#f8f5ee',
      roughness: 0.18,
      transmission: 0.25,
      transparent: true,
      opacity: 0.55,
    });

    const backWallGeo = new THREE.PlaneGeometry(4.2, 3.0);
    const backWall = new THREE.Mesh(backWallGeo, wallMat);
    backWall.position.set(0, 1.5, -1.15);
    backWall.receiveShadow = true;
    backdropGroup.add(backWall);

    const pillarGeo = new THREE.BoxGeometry(0.18, 2.8, 0.18);
    const pillarL = new THREE.Mesh(pillarGeo, wallMat);
    pillarL.position.set(-0.92, 1.4, -0.95);
    backdropGroup.add(pillarL);

    const pillarR = new THREE.Mesh(pillarGeo, wallMat);
    pillarR.position.set(0.92, 1.4, -0.95);
    backdropGroup.add(pillarR);

    const trimGeo = new THREE.BoxGeometry(3.6, 0.045, 0.04);
    const trim = new THREE.Mesh(trimGeo, trimMat);
    trim.position.set(0, 1.08, -1.12);
    backdropGroup.add(trim);

    const windowGeo = new THREE.PlaneGeometry(1.4, 0.95);
    const windowPanel = new THREE.Mesh(windowGeo, glassMat);
    windowPanel.position.set(0, 1.72, -1.12);
    backdropGroup.add(windowPanel);

    scene.add(backdropGroup);

    const student = createRealisticStudentCharacter();
    student.root.position.set(0, 0, 0);
    student.root.rotation.y = -0.1;
    scene.add(student.root);

    let disposed = false;
    let frameId = 0;
    let lastTime = performance.now();
    const startTime = lastTime;

    const tick = () => {
      if (disposed) return;
      const now = performance.now();
      const elapsed = (now - startTime) / 1000;
      const delta = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      const isSpeaking =
        stepRef.current === 'prompt' ||
        stepRef.current === 'profile-setup' ||
        stepRef.current === 'thanks';
      student.update(elapsed, delta, pointerRef.current.x, pointerRef.current.y, isSpeaking);
      renderer.render(scene, camera);

      const afterDraw = performance.now();
      if (isSoftwareGl && afterDraw - now > 24) {
        window.setTimeout(() => {
          if (!disposed) frameId = requestAnimationFrame(tick);
        }, 16);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };
    frameId = requestAnimationFrame(tick);

    const onPointerMove = (ev: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      const nx = ((ev.clientX - rect.left) / Math.max(1, rect.width)) * 2 - 1;
      const ny = ((ev.clientY - rect.top) / Math.max(1, rect.height)) * 2 - 1;
      pointerRef.current.x = THREE.MathUtils.clamp(nx, -1, 1);
      pointerRef.current.y = THREE.MathUtils.clamp(ny, -1, 1);
    };
    window.addEventListener('pointermove', onPointerMove, { passive: true });

    const onResize = () => {
      if (!container || disposed) return;
      const cw = container.clientWidth || 340;
      const ch = Math.max(1, container.clientHeight || 400);
      camera.aspect = cw / ch;
      camera.updateProjectionMatrix();
      renderer.setSize(cw, ch);
    };
    window.addEventListener('resize', onResize);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('resize', onResize);
      student.dispose();
      backWallGeo.dispose();
      pillarGeo.dispose();
      trimGeo.dispose();
      windowGeo.dispose();
      wallMat.dispose();
      trimMat.dispose();
      glassMat.dispose();
      envTarget.dispose();
      renderer.dispose();
    };
  }, []);

  const handleDeclineChange = async () => {
    setError(null);
    setLoading(true);
    try {
      const res = await campusApi.firstLoginSkip();
      setCompletedUser(res.user);
      if (!res.user.profileCompleted) {
        setStep('profile-setup');
      } else {
        setStep('thanks');
        window.setTimeout(() => {
          onComplete(res.user);
        }, 1200);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to continue right now.');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    if (newPassword !== confirmPassword) {
      setError('New Password and Confirm New Password must match.');
      return;
    }
    if (newPassword.length < 8) {
      setError('Please choose a password with at least 8 characters.');
      return;
    }

    setLoading(true);
    try {
      const res = await campusApi.firstLoginChangePassword({
        newPassword,
        confirmPassword,
      });
      setCompletedUser(res.user);
      if (!res.user.profileCompleted) {
        setStep('profile-setup');
      } else {
        setStep('thanks');
        window.setTimeout(() => {
          onComplete(res.user);
        }, 1200);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not update password.');
    } finally {
      setLoading(false);
    }
  };

  const handleProfileSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!studentName.trim() || studentName.trim().length < 2) {
      setError('Please enter your full student name.');
      return;
    }
    if (!department.trim()) {
      setError('Please select your department.');
      return;
    }
    if (!academicYear.trim()) {
      setError('Please select your academic year.');
      return;
    }

    setLoading(true);
    try {
      const res = await campusApi.completeProfile({
        fullName: studentName.trim(),
        department: department.trim(),
        academicYear: academicYear.trim(),
      });
      setCompletedUser(res.user);
      setStep('thanks');
      window.setTimeout(() => {
        onComplete(res.user);
      }, 1300);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save your student profile.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#F4F1E8] text-[#1C2524] flex items-center justify-center p-4 sm:p-8">
      <div className="w-full max-w-4xl rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] shadow-[0_20px_60px_rgba(23,76,74,0.08)] overflow-hidden grid grid-cols-1 md:grid-cols-12">
        {/* Left: Realistic 3D College Student Character */}
        <div className="md:col-span-5 bg-[#EFEAE0] border-b md:border-b-0 md:border-r border-[#E2DCCB] flex flex-col items-center justify-end relative min-h-[300px] md:min-h-[440px] overflow-hidden">
          {webglReady ? (
            <div
              ref={stageRef}
              className="w-full h-[300px] md:h-[410px]"
              aria-label="CampusFind Student Guide"
            />
          ) : (
            <div className="w-full h-[300px] md:h-[410px] flex items-center justify-center p-6 text-center text-xs text-[#55615F]">
              Welcome to {college.name}
            </div>
          )}
          <div className="pb-4 text-center z-10">
            <p className="text-xs font-semibold text-[#174C4A] tracking-wide uppercase">
              {college.code} Student Orientation
            </p>
          </div>
        </div>

        {/* Right: Speech Bubble Dialogue & Action Flow */}
        <div className="md:col-span-7 p-6 sm:p-10 flex flex-col justify-center space-y-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#174C4A] flex items-center justify-center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <circle cx="11" cy="11" r="6.5" stroke="#F4F1E8" strokeWidth="2.1" />
                <circle cx="11" cy="11" r="2.2" fill="#D98252" />
                <path
                  d="M16.2 16.2L20.5 20.5"
                  stroke="#F4F1E8"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                />
              </svg>
            </div>
            <span className="font-display text-lg font-semibold text-[#174C4A]">CampusFind</span>
          </div>

          {step === 'prompt' && (
            <div className="space-y-6">
              <div className="rounded-xl bg-[#F4F1E8] border border-[#E2DCCB] p-5 space-y-2.5">
                <p className="font-display text-xl font-semibold text-[#174C4A] leading-snug">
                  Hey there! Welcome to CampusFind!
                </p>
                <p className="text-sm text-[#42504E] leading-relaxed">
                  Would you like to change your initial password?
                </p>
              </div>

              {error && (
                <div
                  role="alert"
                  className="px-3.5 py-2.5 rounded-lg bg-[#D98252]/12 border border-[#D98252]/40 text-xs text-[#8C3B16]"
                >
                  {error}
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  type="button"
                  disabled={loading}
                  onClick={() => {
                    setError(null);
                    setStep('change-password');
                  }}
                  className="flex-1 h-11 px-5 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-sm font-semibold hover:bg-[#123D3B] transition-colors cursor-pointer"
                >
                  YES – Change Password
                </button>
                <button
                  type="button"
                  disabled={loading}
                  onClick={handleDeclineChange}
                  className="flex-1 h-11 px-5 rounded-xl bg-[#F4F1E8] border border-[#D98252] text-[#174C4A] text-sm font-semibold hover:bg-[#D98252]/12 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                  <span>NO – Keep Initial Password</span>
                </button>
              </div>

              <p className="text-xs text-[#6B7674]">
                Signed in as <span className="font-medium text-[#174C4A]">{user.identifier}</span>
              </p>
            </div>
          )}

          {step === 'change-password' && (
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <div>
                <h2 className="font-display text-xl font-semibold text-[#174C4A]">
                  Set Your Personal Password
                </h2>
                <p className="text-xs text-[#55615F] mt-1">
                  Choose a secure new password (minimum 8 characters) for{' '}
                  <span className="font-medium text-[#174C4A]">{user.identifier}</span>.
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-[#174C4A]">New Password</label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-[#6B7674] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={8}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="At least 8 characters"
                    className="w-full h-11 pl-10 pr-10 rounded-xl bg-white border border-[#D8D1C0] text-sm text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6B7674] hover:text-[#174C4A]"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-[#174C4A]">
                  Confirm New Password
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={8}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter new password"
                  className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D1C0] text-sm text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                />
              </div>

              {error && (
                <div
                  role="alert"
                  className="px-3.5 py-2.5 rounded-lg bg-[#D98252]/12 border border-[#D98252]/40 text-xs text-[#8C3B16]"
                >
                  {error}
                </div>
              )}

              <div className="flex items-center gap-3 pt-1">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 h-11 px-5 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-sm font-semibold hover:bg-[#123D3B] disabled:opacity-60 flex items-center justify-center gap-2 cursor-pointer"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                  <span>Update Password &amp; Continue</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setError(null);
                    setStep('prompt');
                  }}
                  className="h-11 px-4 rounded-xl border border-[#D8D1C0] text-xs font-medium text-[#55615F] hover:text-[#174C4A] cursor-pointer"
                >
                  Back
                </button>
              </div>
            </form>
          )}

          {step === 'profile-setup' && (
            <form onSubmit={handleProfileSubmit} className="space-y-4">
              <div className="rounded-xl bg-[#F4F1E8] border border-[#E2DCCB] p-4 space-y-1">
                <p className="font-display text-lg font-semibold text-[#174C4A] leading-snug">
                  Before entering CampusFind, let&apos;s complete your student profile.
                </p>
                <p className="text-xs text-[#55615F]">
                  Your name, department, and academic year help identify you on campus lost &amp;
                  found reports without exposing your private email.
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#174C4A] flex items-center gap-1.5">
                  <UserIcon className="w-3.5 h-3.5 text-[#D98252]" />
                  <span>Student Name</span>
                </label>
                <input
                  type="text"
                  required
                  minLength={2}
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="Enter your full name"
                  className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D1C0] text-sm text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#174C4A] flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-[#D98252]" />
                  <span>Department</span>
                </label>
                <select
                  required
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D1C0] text-sm text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                >
                  <option value="">Select your department</option>
                  {departments.map((dept) => (
                    <option key={dept} value={dept}>
                      {dept}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#174C4A] flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-[#D98252]" />
                  <span>Academic Year</span>
                </label>
                <select
                  required
                  value={academicYear}
                  onChange={(e) => setAcademicYear(e.target.value)}
                  className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D1C0] text-sm text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                >
                  <option value="">Select your academic year</option>
                  {academicYears.map((yr) => (
                    <option key={yr} value={yr}>
                      {yr}
                    </option>
                  ))}
                </select>
              </div>

              {error && (
                <div
                  role="alert"
                  className="px-3.5 py-2.5 rounded-lg bg-[#D98252]/12 border border-[#D98252]/40 text-xs text-[#8C3B16]"
                >
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full h-11 px-5 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-sm font-semibold hover:bg-[#123D3B] disabled:opacity-60 flex items-center justify-center gap-2 cursor-pointer"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                <span>Save Profile &amp; Enter CampusFind</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {step === 'thanks' && (
            <div className="rounded-xl bg-[#F4F1E8] border border-[#174C4A]/25 p-6 space-y-3">
              <div className="flex items-center gap-2.5 text-[#174C4A]">
                <CheckCircle2 className="w-6 h-6 text-[#D98252]" />
                <p className="font-display text-xl font-semibold">
                  Welcome to CampusFind, {completedUser.fullName}!
                </p>
              </div>
              <p className="text-sm text-[#55615F]">
                Opening your {college.name} student dashboard...
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
