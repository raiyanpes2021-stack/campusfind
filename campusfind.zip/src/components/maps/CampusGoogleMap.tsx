import { useEffect, useRef, useState } from 'react';
import {
  APIProvider,
  Map as GoogleMap,
  AdvancedMarker,
  Pin,
  InfoWindow,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import { Search, MapPin, Layers, Crosshair, Loader2 } from 'lucide-react';
import type { CampusItem, CollegeSummary } from '../../types/campusfind';

interface CampusGoogleMapProps {
  apiKey: string;
  college: CollegeSummary;
  items?: CampusItem[];
  pickerMode?: boolean;
  selectedCoords?: { lat: number; lng: number } | null;
  onSelectLocation?: (coords: { lat: number; lng: number; label?: string }) => void;
  heightClass?: string;
}

interface PlaceLike {
  fetchFields: (opts: { fields: string[] }) => Promise<void>;
  displayName?: string;
  formattedAddress?: string;
  location?: { lat: () => number; lng: () => number };
}

interface PlacePredictionLike {
  placeId: string;
  mainText?: { text?: string };
  secondaryText?: { text?: string };
  text?: { text?: string };
  toPlace: () => PlaceLike;
}

interface PlaceSuggestionItem {
  placeId: string;
  mainText: string;
  secondaryText: string;
  rawPrediction: PlacePredictionLike;
}

function PlacesSearchBar({
  college,
  onPlacePicked,
}: {
  college: CollegeSummary;
  onPlacePicked: (coords: { lat: number; lng: number; label: string }) => void;
}) {
  const map = useMap();
  const placesLib = useMapsLibrary('places') as unknown as {
    AutocompleteSessionToken: new () => unknown;
    AutocompleteSuggestion: {
      fetchAutocompleteSuggestions: (req: Record<string, unknown>) => Promise<{
        suggestions?: Array<{ placePrediction?: PlacePredictionLike }>;
      }>;
    };
  } | null;
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState<PlaceSuggestionItem[]>([]);
  const [searching, setSearching] = useState(false);
  const sessionTokenRef = useRef<unknown>(null);

  useEffect(() => {
    if (!placesLib || query.trim().length < 2) {
      setSuggestions([]);
      return;
    }

    let cancelled = false;
    const timer = window.setTimeout(async () => {
      setSearching(true);
      try {
        if (!sessionTokenRef.current) {
          sessionTokenRef.current = new placesLib.AutocompleteSessionToken();
        }
        const response = await placesLib.AutocompleteSuggestion.fetchAutocompleteSuggestions({
          input: query.trim(),
          sessionToken: sessionTokenRef.current,
          locationBias: {
            center: { lat: college.latitude, lng: college.longitude },
            radius: 2500,
          },
        });
        if (cancelled) return;
        const mapped: PlaceSuggestionItem[] = (response.suggestions || [])
          .filter((s): s is { placePrediction: PlacePredictionLike } => Boolean(s.placePrediction))
          .slice(0, 5)
          .map((s) => {
            const p = s.placePrediction;
            return {
              placeId: p.placeId,
              mainText: p.mainText?.text || p.text?.text || 'Location',
              secondaryText: p.secondaryText?.text || '',
              rawPrediction: p,
            };
          });
        setSuggestions(mapped);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        if (msg.includes('RESOURCE_EXHAUSTED') || msg.includes('429') || msg.includes('OVER_QUERY_LIMIT')) {
          window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        }
        if (!cancelled) setSuggestions([]);
      } finally {
        if (!cancelled) setSearching(false);
      }
    }, 280);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [placesLib, query, college.latitude, college.longitude]);

  const handleSelectSuggestion = async (item: PlaceSuggestionItem) => {
    try {
      const place = item.rawPrediction.toPlace();
      await place.fetchFields({ fields: ['displayName', 'formattedAddress', 'location'] });
      sessionTokenRef.current = null;
      setSuggestions([]);
      setQuery(item.mainText);

      if (place.location) {
        const lat = place.location.lat();
        const lng = place.location.lng();
        const label = place.displayName || item.mainText;
        map?.panTo({ lat, lng });
        map?.setZoom(18);
        onPlacePicked({ lat, lng, label });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('RESOURCE_EXHAUSTED') || msg.includes('429') || msg.includes('OVER_QUERY_LIMIT')) {
        window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
      }
    }
  };

  return (
    <div className="relative w-full max-w-sm">
      <Search className="w-4 h-4 text-[#55615F] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search building or exact location..."
        className="w-full h-9 pl-9 pr-8 rounded-lg bg-[#FAF8F3]/95 border border-[#D8D0BE] text-xs text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A] shadow-md"
      />
      {searching && (
        <Loader2 className="w-3.5 h-3.5 text-[#174C4A] animate-spin absolute right-2.5 top-1/2 -translate-y-1/2" />
      )}
      {suggestions.length > 0 && (
        <div className="absolute left-0 right-0 top-10 z-30 rounded-lg bg-[#FAF8F3] border border-[#D8D0BE] shadow-xl overflow-hidden divide-y divide-[#E6E0D0]">
          {suggestions.map((s) => (
            <button
              key={s.placeId}
              type="button"
              onClick={() => handleSelectSuggestion(s)}
              className="w-full px-3 py-2 text-left hover:bg-[#EDE8DC] transition-colors cursor-pointer"
            >
              <div className="text-xs font-semibold text-[#174C4A] truncate">{s.mainText}</div>
              {s.secondaryText && (
                <div className="text-[11px] text-[#55615F] truncate">{s.secondaryText}</div>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function RecenterButton({ college }: { college: CollegeSummary }) {
  const map = useMap();
  return (
    <button
      type="button"
      onClick={() => {
        map?.panTo({ lat: college.latitude, lng: college.longitude });
        map?.setZoom(17);
      }}
      title="Recenter Map"
      className="h-9 px-3 rounded-lg bg-[#FAF8F3]/95 border border-[#D8D0BE] text-xs font-medium text-[#174C4A] hover:border-[#D98252] flex items-center gap-1.5 shadow-md transition-colors cursor-pointer"
    >
      <Crosshair className="w-3.5 h-3.5 text-[#D98252]" />
      <span className="hidden sm:inline">Recenter</span>
    </button>
  );
}

export function CampusGoogleMap({
  apiKey,
  college,
  items = [],
  pickerMode = false,
  selectedCoords = null,
  onSelectLocation,
  heightClass = 'h-[440px]',
}: CampusGoogleMapProps) {
  const [mapTypeId, setMapTypeId] = useState<'roadmap' | 'hybrid'>('hybrid');
  const [activeItemId, setActiveItemId] = useState<number | null>(null);

  // Strictly display ONLY genuine user-submitted reports that have explicit, valid numeric coordinates
  const validReportMarkers = items.filter(
    (item) =>
      typeof item.latitude === 'number' &&
      Number.isFinite(item.latitude) &&
      typeof item.longitude === 'number' &&
      Number.isFinite(item.longitude)
  );

  const activeItem = validReportMarkers.find((i) => i.id === activeItemId) || null;
  const center =
    !pickerMode && validReportMarkers.length > 0
      ? { lat: validReportMarkers[0].latitude!, lng: validReportMarkers[0].longitude! }
      : { lat: college.latitude, lng: college.longitude };

  if (!apiKey) {
    return (
      <div
        className={`w-full ${heightClass} rounded-xl bg-[#FAF8F3] border border-[#E2DCCB] flex flex-col items-center justify-center p-6 text-center space-y-2`}
      >
        <MapPin className="w-6 h-6 text-[#D98252]" />
        <div className="text-sm font-semibold text-[#174C4A]">{college.name}</div>
        <p className="text-xs text-[#55615F] max-w-md pt-1">
          Configure <code className="text-[#174C4A] font-semibold">GOOGLE_MAPS_API_KEY</code> to load interactive map tiles.
        </p>
      </div>
    );
  }

  return (
    <div className={`relative w-full ${heightClass} rounded-xl overflow-hidden border border-[#DFD8C8] bg-[#F4F1E8]`}>
      <APIProvider apiKey={apiKey} language="en" region="IN">
        {/* Top Floating Controls Bar */}
        <div className="absolute top-3 left-3 right-3 z-20 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
          <div className="pointer-events-auto flex-1 min-w-[200px] max-w-sm">
            <PlacesSearchBar
              college={college}
              onPlacePicked={(picked) => {
                onSelectLocation?.(picked);
              }}
            />
          </div>

          <div className="pointer-events-auto flex items-center gap-2">
            <RecenterButton college={college} />
            <button
              type="button"
              onClick={() => setMapTypeId((prev) => (prev === 'hybrid' ? 'roadmap' : 'hybrid'))}
              className="h-9 px-3 rounded-lg bg-[#FAF8F3]/95 border border-[#D8D0BE] text-xs font-medium text-[#174C4A] hover:border-[#D98252] flex items-center gap-1.5 shadow-md transition-colors cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5 text-[#D98252]" />
              <span>{mapTypeId === 'hybrid' ? 'Satellite' : 'Map'}</span>
            </button>
          </div>
        </div>

        <GoogleMap
          mapId="DEMO_MAP_ID"
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
          defaultCenter={center}
          defaultZoom={17}
          mapTypeId={mapTypeId}
          gestureHandling="greedy"
          disableDefaultUI={false}
          streetViewControl={false}
          mapTypeControl={false}
          className="w-full h-full"
          onClick={(e) => {
            if (!pickerMode || !onSelectLocation || !e.detail.latLng) return;
            onSelectLocation({
              lat: Number(e.detail.latLng.lat.toFixed(6)),
              lng: Number(e.detail.latLng.lng.toFixed(6)),
            });
          }}
        >
          {/* Selected Pin in Picker Mode — ONLY shown after user actually selects a location */}
          {pickerMode && selectedCoords && (
            <AdvancedMarker position={selectedCoords} title="Pinned Lost Device Location">
              <Pin background="#D98252" borderColor="#FFFFFF" glyphColor="#FFFFFF" scale={1.15} />
            </AdvancedMarker>
          )}

          {/* Genuine User-Submitted Report Markers ONLY (valid coordinates required) */}
          {!pickerMode &&
            validReportMarkers.map((item) => (
              <AdvancedMarker
                key={item.id}
                position={{ lat: item.latitude!, lng: item.longitude! }}
                title={`${item.title}${item.location ? ` — ${item.location}` : ''}`}
                onClick={() => setActiveItemId(item.id)}
              >
                <Pin
                  background={item.type === 'missing' ? '#D98252' : '#174C4A'}
                  borderColor="#FFFFFF"
                  glyphColor="#F4F1E8"
                  scale={1.05}
                />
              </AdvancedMarker>
            ))}

          {activeItem && activeItem.latitude !== null && activeItem.longitude !== null && (
            <InfoWindow
              position={{ lat: activeItem.latitude, lng: activeItem.longitude }}
              onCloseClick={() => setActiveItemId(null)}
            >
              <div className="text-[#1C2524] p-1 max-w-[240px] space-y-1.5">
                {activeItem.image_data && (
                  <img
                    src={activeItem.image_data}
                    alt={activeItem.title}
                    className="w-full h-24 object-cover rounded border border-[#E2DCCB]"
                  />
                )}
                <div className="flex items-center justify-between gap-2 text-[10px] font-bold uppercase tracking-wide">
                  <span className={activeItem.type === 'missing' ? 'text-[#D98252]' : 'text-[#174C4A]'}>
                    {activeItem.type === 'missing' ? 'Lost' : 'Found'} · {activeItem.device_type}
                  </span>
                  <span className="font-mono-tabular text-[#174C4A]">
                    {activeItem.report_code || `CF-${activeItem.id}`}
                  </span>
                </div>
                <div className="text-xs font-bold text-[#174C4A] leading-snug">{activeItem.title}</div>
                {activeItem.location && (
                  <div className="text-[11px] font-medium text-[#1C2524]">{activeItem.location}</div>
                )}
                {activeItem.description && (
                  <div className="text-[11px] text-[#55615F] line-clamp-2">{activeItem.description}</div>
                )}
                <div className="text-[10px] font-mono text-[#55615F] pt-0.5 border-t border-[#E6E0D0]">
                  {activeItem.reported_date}
                  {activeItem.reported_time ? ` · ${activeItem.reported_time}` : ''}
                </div>
              </div>
            </InfoWindow>
          )}
        </GoogleMap>

        {/* Bottom Legend / Empty State Overlay */}
        <div className="absolute bottom-3 left-3 z-20 px-3 py-1.5 rounded-lg bg-[#FAF8F3]/95 border border-[#D8D0BE] text-[11px] font-medium text-[#174C4A] flex flex-wrap items-center gap-3 shadow-md pointer-events-none">
          {pickerMode ? (
            <span>
              {selectedCoords
                ? 'Location pinned — click anywhere to move pin'
                : 'Click on the map or search above to pin the exact device location (optional)'}
            </span>
          ) : validReportMarkers.length > 0 ? (
            <>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#D98252]" />
                <span>
                  {validReportMarkers.filter((i) => i.type === 'missing').length} Lost
                </span>
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#174C4A]" />
                <span>
                  {validReportMarkers.filter((i) => i.type === 'found').length} Found
                </span>
              </span>
            </>
          ) : (
            <span className="text-[#55615F]">
              No reports with verified map coordinates have been submitted yet.
            </span>
          )}
        </div>
      </APIProvider>
    </div>
  );
}
