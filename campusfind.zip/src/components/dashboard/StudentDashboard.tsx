import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react';
import {
  Bell,
  CheckCircle2,
  ClipboardList,
  ExternalLink,
  FilePlus2,
  FileSearch,
  LayoutDashboard,
  LogOut,
  Map as MapIcon,
  MapPin,
  Menu,
  PackageCheck,
  Search,
  Settings,
  User as UserIcon,
  X,
} from 'lucide-react';
import { campusApi, subscribeRealtime } from '../../lib/api';
import type {
  AuthUser,
  CampusItem,
  CampusMatch,
  CampusNotification,
  CollegeSummary,
  DashboardStats,
  ItemLifecycleStatus,
} from '../../types/campusfind';
import { CampusGoogleMap } from '../maps/CampusGoogleMap';
import { DeviceReportForm } from './DeviceReportForm';
import { MatchNotificationPopup } from '../cinematic/MatchNotificationPopup';
import { FoundDeviceDetailModal } from './FoundDeviceDetailModal';

type StudentSection =
  | 'overview'
  | 'lost-and-found'
  | 'report-lost'
  | 'report-found'
  | 'my-reports'
  | 'notifications'
  | 'campus-map'
  | 'profile'
  | 'settings';

interface StudentDashboardProps {
  user: AuthUser;
  college: CollegeSummary;
  mapsApiKey: string;
  onUserUpdated: (user: AuthUser) => void;
  onLogout: () => void;
}

const LIFECYCLE_LABELS: Record<ItemLifecycleStatus, { label: string; color: string }> = {
  submitted: { label: 'Submitted', color: 'text-[#174C4A]' },
  under_review: { label: 'Under Review', color: 'text-[#D98252]' },
  possible_match: { label: 'In Progress', color: 'text-[#D98252]' },
  verified: { label: 'Confirmed', color: 'text-[#174C4A]' },
  recovered: { label: 'Recovered', color: 'text-[#174C4A]' },
  closed: { label: 'Closed', color: 'text-[#55615F]' },
};

export function StudentDashboard({
  user,
  college,
  mapsApiKey,
  onUserUpdated,
  onLogout,
}: StudentDashboardProps) {
  const [section, setSection] = useState<StudentSection>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [commonItems, setCommonItems] = useState<CampusItem[]>([]);
  const [myItems, setMyItems] = useState<CampusItem[]>([]);
  const [myMatches, setMyMatches] = useState<CampusMatch[]>([]);
  const [notifications, setNotifications] = useState<CampusNotification[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [myReportsTab, setMyReportsTab] = useState<'all' | 'missing' | 'found'>('all');

  // Common Lost & Found filter state
  const [commonTab, setCommonTab] = useState<'missing' | 'found'>('missing');
  const [commonSearch, setCommonSearch] = useState('');
  const [commonCategory, setCommonCategory] = useState('all');
  const [commonLocation, setCommonLocation] = useState('');
  const [commonDate, setCommonDate] = useState('');
  const [commonStatus, setCommonStatus] = useState('all');

  const [toast, setToast] = useState<string | null>(null);
  const [detailItemId, setDetailItemId] = useState<number | null>(null);
  const [detailMatchId, setDetailMatchId] = useState<number | null>(null);
  const [dismissedMatchIds, setDismissedMatchIds] = useState<number[]>([]);

  // Profile form state
  const [profileName, setProfileName] = useState(user.fullName);
  const [profileDept, setProfileDept] = useState(user.department);
  const [profileYear, setProfileYear] = useState(user.academicYear || '');
  const [profileSaved, setProfileSaved] = useState<string | null>(null);

  // Settings preferences
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [soundAlerts, setSoundAlerts] = useState(false);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => {
      setToast((curr) => (curr === msg ? null : curr));
    }, 4500);
  }, []);

  const refreshData = useCallback(async () => {
    try {
      const [sumRes, allRes, mineRes, matchRes, notifRes] = await Promise.all([
        campusApi.getSummary(),
        campusApi.getItems(),
        campusApi.getItems({ mine: true }),
        campusApi.getMatches({ mine: true }),
        campusApi.getNotifications(),
      ]);
      setStats(sumRes.stats);
      setCommonItems(allRes.items);
      setMyItems(mineRes.items);
      setMyMatches(matchRes.matches);
      setNotifications(notifRes.notifications);
    } catch {
      // Retain last valid state on transient error
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  // Real-time Server-Sent Events (SSE) subscription
  useEffect(() => {
    const unsubscribe = subscribeRealtime((msg) => {
      if (msg.event === 'connected') return;
      refreshData();
      if (msg.event === 'notification:created') {
        const n = msg.notification as CampusNotification | undefined;
        if (n?.title) showToast(n.title);
      } else if (msg.event === 'report:updated') {
        showToast('Report status updated in real time.');
      }
    });
    return unsubscribe;
  }, [refreshData, showToast]);

  const unreadCount = useMemo(
    () => notifications.filter((n) => !n.is_read).length,
    [notifications]
  );

  const unreadMatchNotifications = useMemo(
    () =>
      notifications.filter(
        (n) =>
          !n.is_read &&
          n.notification_type === 'match_found' &&
          typeof n.related_found_item_id === 'number' &&
          n.match_workflow_status !== 'MATCH_REJECTED' &&
          n.match_workflow_status !== 'RECOVERED' &&
          !dismissedMatchIds.includes(n.id)
      ),
    [notifications, dismissedMatchIds]
  );

  const handleDismissMatchPopup = useCallback(
    async (notification: CampusNotification) => {
      setDismissedMatchIds((prev) => (prev.includes(notification.id) ? prev : [...prev, notification.id]));
      try {
        await campusApi.markNotificationRead(notification.id);
        refreshData();
      } catch {
        // Keep dismissed locally
      }
    },
    [refreshData]
  );

  const handleViewMatchedDevice = useCallback(
    async (notification: CampusNotification) => {
      setDismissedMatchIds((prev) => (prev.includes(notification.id) ? prev : [...prev, notification.id]));
      if (typeof notification.related_found_item_id === 'number') {
        setDetailItemId(notification.related_found_item_id);
        setDetailMatchId(notification.related_match_id ?? null);
      }
      if (!notification.is_read) {
        try {
          await campusApi.markNotificationRead(notification.id);
          refreshData();
        } catch {
          // Non-fatal
        }
      }
    },
    [refreshData]
  );

  const commonLostItems = useMemo(
    () => commonItems.filter((it) => it.type === 'missing' && it.status !== 'archived'),
    [commonItems]
  );
  const commonFoundItems = useMemo(
    () => commonItems.filter((it) => it.type === 'found' && it.status !== 'archived'),
    [commonItems]
  );

  const commonCategories = useMemo(() => {
    const set = new Set<string>();
    for (const it of commonItems) {
      if (it.device_type) set.add(it.device_type);
    }
    return Array.from(set).sort();
  }, [commonItems]);

  const filteredCommonItems = useMemo(() => {
    const base = commonTab === 'missing' ? commonLostItems : commonFoundItems;
    const q = commonSearch.trim().toLowerCase();
    const locQ = commonLocation.trim().toLowerCase();
    return base.filter((it) => {
      if (commonCategory !== 'all' && it.device_type !== commonCategory) return false;
      if (commonStatus !== 'all' && (it.lifecycle_status || 'submitted') !== commonStatus) return false;
      if (commonDate && it.reported_date !== commonDate) return false;
      if (locQ && !(it.location || '').toLowerCase().includes(locQ)) return false;
      if (q) {
        const hay = `${it.title} ${it.brand || ''} ${it.model || ''} ${it.device_type} ${it.description} ${it.location || ''} ${it.report_code || ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [
    commonTab,
    commonLostItems,
    commonFoundItems,
    commonSearch,
    commonCategory,
    commonLocation,
    commonDate,
    commonStatus,
  ]);

  const filteredMyItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return myItems.filter((it) => {
      if (myReportsTab !== 'all' && it.type !== myReportsTab) return false;
      if (!q) return true;
      return (
        it.title.toLowerCase().includes(q) ||
        it.device_type.toLowerCase().includes(q) ||
        (it.location || '').toLowerCase().includes(q) ||
        (it.report_code || '').toLowerCase().includes(q)
      );
    });
  }, [myItems, myReportsTab, searchQuery]);

  const handleProfileSave = async (e: FormEvent) => {
    e.preventDefault();
    setProfileSaved(null);
    try {
      const res = await campusApi.updateProfile({
        fullName: profileName.trim(),
        department: profileDept.trim(),
        academicYear: profileYear.trim(),
      });
      onUserUpdated(res.user);
      setProfileSaved('Profile updated successfully.');
    } catch (err) {
      setProfileSaved(err instanceof Error ? err.message : 'Failed to update profile.');
    }
  };

  // Student navigation (10 sections including Logout in footer)
  const navItems: {
    id: StudentSection;
    label: string;
    icon: typeof LayoutDashboard;
    badge?: number;
  }[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    {
      id: 'lost-and-found',
      label: 'Lost & Found Devices',
      icon: FileSearch,
      badge: commonItems.length || undefined,
    },
    { id: 'report-lost', label: 'Report Lost Device', icon: FilePlus2 },
    { id: 'report-found', label: 'Report Found Device', icon: PackageCheck },
    { id: 'my-reports', label: 'My Reports', icon: ClipboardList, badge: myItems.length || undefined },
    { id: 'notifications', label: 'Notifications', icon: Bell, badge: unreadCount || undefined },
    { id: 'campus-map', label: 'Campus Map', icon: MapIcon },
    { id: 'profile', label: 'Profile', icon: UserIcon },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const selectSection = (next: StudentSection) => {
    setSection(next);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen w-full bg-[#F4F1E8] text-[#1C2524] flex">
      {/* Desktop Sidebar — Deep Teal (#174C4A) */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col bg-[#174C4A] text-[#F4F1E8] shrink-0">
        <div className="px-5 py-5 border-b border-white/10 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#F4F1E8] flex items-center justify-center shrink-0">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <circle cx="11" cy="11" r="6.5" stroke="#174C4A" strokeWidth="2.1" />
              <circle cx="11" cy="11" r="2.2" fill="#D98252" />
              <path d="M16.2 16.2L20.5 20.5" stroke="#D98252" strokeWidth="2.2" strokeLinecap="round" />
            </svg>
          </div>
          <div className="min-w-0">
            <p className="font-display text-base font-bold text-[#F4F1E8] leading-tight">CampusFind</p>
            <p className="text-[11px] text-[#F4F1E8]/70 truncate">Student Portal · {college.code}</p>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = section === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => selectSection(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
                  active
                    ? 'bg-[#D98252] text-white shadow-xs'
                    : 'text-[#F4F1E8]/85 hover:bg-white/10 hover:text-white'
                }`}
              >
                <span className="flex items-center gap-2.5 truncate">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </span>
                {item.badge !== undefined && (
                  <span
                    className={`font-mono-tabular text-[11px] font-bold px-1.5 py-0.5 rounded-md ${
                      active ? 'bg-white/20 text-white' : 'bg-[#D98252]/25 text-[#F4F1E8]'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-white/10">
          <div className="px-3 py-2 mb-2">
            <p className="text-xs font-semibold text-[#F4F1E8] truncate">{user.fullName}</p>
            <p className="text-[11px] text-[#F4F1E8]/70 truncate">{user.studentId || user.identifier}</p>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium text-[#F4F1E8]/85 hover:text-white hover:bg-[#D98252]/25 transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="fixed inset-0 bg-[#1C2524]/50" onClick={() => setMobileMenuOpen(false)} />
          <div className="relative w-72 max-w-[85vw] bg-[#174C4A] text-[#F4F1E8] flex flex-col z-10">
            <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between">
              <span className="font-display text-lg font-bold text-[#F4F1E8]">CampusFind</span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-1.5 text-[#F4F1E8]/80 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = section === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => selectSection(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium ${
                      active ? 'bg-[#D98252] text-white' : 'text-[#F4F1E8]/85 hover:bg-white/10'
                    }`}
                  >
                    <span className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </span>
                    {item.badge !== undefined && (
                      <span className="font-mono-tabular text-xs font-bold">{item.badge}</span>
                    )}
                  </button>
                );
              })}
            </nav>
            <div className="p-3 border-t border-white/10">
              <button
                type="button"
                onClick={onLogout}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm text-[#F4F1E8] hover:bg-[#D98252]/25"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="sticky top-0 z-30 h-16 px-4 sm:px-8 border-b border-[#DFD8C8] bg-[#FAF8F3]/95 backdrop-blur flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 rounded-lg text-[#174C4A] hover:bg-[#EDE8DC]"
              aria-label="Open menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-[#174C4A] truncate">{college.name}</p>
              <p className="text-xs text-[#55615F] truncate">
                {user.fullName}
                {user.department ? ` · ${user.department}` : ''}
                {user.academicYear ? ` · ${user.academicYear}` : ''}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => selectSection('report-lost')}
              className="hidden sm:inline-flex h-9 px-3.5 rounded-lg bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold items-center gap-1.5 hover:bg-[#123D3B] transition-all cursor-pointer"
            >
              <FilePlus2 className="w-3.5 h-3.5" />
              <span>Report Lost</span>
            </button>
            <button
              type="button"
              onClick={() => selectSection('notifications')}
              className="relative h-9 w-9 rounded-lg bg-white border border-[#DFD8C8] flex items-center justify-center text-[#174C4A] hover:border-[#D98252] transition-colors cursor-pointer"
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[16px] h-4 px-1 rounded-full bg-[#D98252] text-white text-[10px] font-bold flex items-center justify-center font-mono-tabular">
                  {unreadCount}
                </span>
              )}
            </button>
          </div>
        </header>

        {/* Live Update Toast */}
        {toast && (
          <div className="fixed bottom-5 right-5 z-50 max-w-sm rounded-xl bg-[#174C4A] text-[#F4F1E8] border border-[#D98252]/50 px-4 py-3 shadow-xl flex items-center gap-3">
            <Bell className="w-4 h-4 text-[#D98252] shrink-0" />
            <span className="text-xs">{toast}</span>
          </div>
        )}

        <main className="flex-1 p-4 sm:p-8 max-w-[1400px] w-full mx-auto">
          {/* 1. OVERVIEW */}
          {section === 'overview' && (
            <div className="space-y-8">
              <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[#DFD8C8] pb-5">
                <div>
                  <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#174C4A] tracking-tight">
                    Welcome back, {user.fullName.split(' ')[0]}
                  </h1>
                  <p className="mt-1 text-sm text-[#55615F]">
                    Report missing or found electronic devices and track recovery updates across your campus.
                  </p>
                </div>
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => selectSection('report-lost')}
                    className="h-10 px-4 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold hover:bg-[#123D3B] transition-all cursor-pointer"
                  >
                    Report Lost Device
                  </button>
                  <button
                    type="button"
                    onClick={() => selectSection('report-found')}
                    className="h-10 px-4 rounded-xl bg-white border border-[#D8D0BE] text-[#174C4A] text-xs font-semibold hover:border-[#D98252] transition-all cursor-pointer"
                  >
                    Report Found Device
                  </button>
                </div>
              </div>

              {/* 3 Institution-Wide Student KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <button
                  type="button"
                  onClick={() => {
                    setCommonTab('missing');
                    selectSection('lost-and-found');
                  }}
                  className="text-left rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] hover:border-[#174C4A]/40 p-5 shadow-xs transition-colors cursor-pointer"
                >
                  <p className="text-xs font-medium text-[#55615F]">Total Lost Reports</p>
                  <p className="mt-2 font-mono-tabular text-3xl font-bold text-[#174C4A]">
                    {stats?.missingTotal ?? commonLostItems.length}
                  </p>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCommonTab('found');
                    selectSection('lost-and-found');
                  }}
                  className="text-left rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] hover:border-[#174C4A]/40 p-5 shadow-xs transition-colors cursor-pointer"
                >
                  <p className="text-xs font-medium text-[#55615F]">Total Found Reports</p>
                  <p className="mt-2 font-mono-tabular text-3xl font-bold text-[#D98252]">
                    {stats?.foundTotal ?? commonFoundItems.length}
                  </p>
                </button>
                <div className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 shadow-xs">
                  <p className="text-xs font-medium text-[#55615F]">Recovered Devices</p>
                  <p className="mt-2 font-mono-tabular text-3xl font-bold text-[#174C4A]">
                    {stats?.resolvedItems ?? 0}
                  </p>
                </div>
              </div>

              {/* Recent Common Reports & Notifications Split */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-7 rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 sm:p-6 shadow-xs">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="font-display text-lg font-bold text-[#174C4A]">
                      Recent Campus Reports
                    </h2>
                    <button
                      type="button"
                      onClick={() => selectSection('lost-and-found')}
                      className="text-xs font-semibold text-[#D98252] hover:underline cursor-pointer"
                    >
                      View all
                    </button>
                  </div>
                  {commonItems.length === 0 ? (
                    <div className="py-10 text-center text-sm text-[#55615F]">
                      No lost or found device reports have been submitted at {college.code} yet.
                    </div>
                  ) : (
                    <div className="divide-y divide-[#E6E0D0]">
                      {commonItems.slice(0, 5).map((item) => {
                        const lc = LIFECYCLE_LABELS[item.lifecycle_status] || LIFECYCLE_LABELS.submitted;
                        return (
                          <div key={item.id} className="py-3.5 flex items-center justify-between gap-4">
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 text-xs text-[#55615F] font-mono-tabular">
                                <span>{item.report_code || `CF-${item.id}`}</span>
                                <span>·</span>
                                <span
                                  className={
                                    item.type === 'missing'
                                      ? 'text-[#D98252] font-semibold'
                                      : 'text-[#174C4A] font-semibold'
                                  }
                                >
                                  {item.type === 'missing' ? 'Lost' : 'Found'}
                                </span>
                              </div>
                              <p className="text-sm font-semibold text-[#1C2524] truncate mt-0.5">
                                {item.title}
                              </p>
                              <p className="text-xs text-[#55615F] truncate">
                                {item.location || 'Location not specified'} · {item.reported_date}
                              </p>
                            </div>
                            <span className={`text-xs font-semibold shrink-0 ${lc.color}`}>{lc.label}</span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                <div className="lg:col-span-5 rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 sm:p-6 shadow-xs">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="font-display text-lg font-bold text-[#174C4A]">Latest Notifications</h2>
                    <button
                      type="button"
                      onClick={() => selectSection('notifications')}
                      className="text-xs font-semibold text-[#D98252] hover:underline cursor-pointer"
                    >
                      View all
                    </button>
                  </div>
                  {notifications.length === 0 ? (
                    <div className="py-10 text-center text-sm text-[#55615F]">
                      No notifications yet. Live updates appear here automatically.
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {notifications.slice(0, 4).map((n) => (
                        <div
                          key={n.id}
                          className={`p-3.5 rounded-xl border ${
                            n.is_read
                              ? 'bg-white border-[#E6E0D0]'
                              : 'bg-white border-[#D98252]/55 shadow-xs'
                          }`}
                        >
                          <p className="text-xs font-semibold text-[#174C4A]">{n.title}</p>
                          <p className="text-xs text-[#55615F] mt-1 leading-relaxed">{n.message}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 2. COMMON LOST & FOUND DEVICES (INSTITUTION-WIDE) */}
          {section === 'lost-and-found' && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[#DFD8C8] pb-4">
                <div>
                  <h1 className="font-display text-2xl font-bold text-[#174C4A]">
                    Lost &amp; Found Devices
                  </h1>
                  <p className="text-sm text-[#55615F] mt-0.5">
                    Common {college.name} registry visible to all authorized students.
                  </p>
                </div>
                <div className="inline-flex rounded-xl bg-[#EFEAE0] p-1 border border-[#DFD8C8]">
                  <button
                    type="button"
                    onClick={() => setCommonTab('missing')}
                    className={`h-9 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                      commonTab === 'missing'
                        ? 'bg-[#174C4A] text-[#F4F1E8] shadow-xs'
                        : 'text-[#55615F] hover:text-[#174C4A]'
                    }`}
                  >
                    Lost Devices ({commonLostItems.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setCommonTab('found')}
                    className={`h-9 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                      commonTab === 'found'
                        ? 'bg-[#174C4A] text-[#F4F1E8] shadow-xs'
                        : 'text-[#55615F] hover:text-[#174C4A]'
                    }`}
                  >
                    Found Devices ({commonFoundItems.length})
                  </button>
                </div>
              </div>

              {/* Search & Filter Bar */}
              <div className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 shadow-xs">
                <div className="relative">
                  <Search className="w-4 h-4 text-[#55615F] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={commonSearch}
                    onChange={(e) => setCommonSearch(e.target.value)}
                    placeholder="Search device, brand, ID..."
                    className="w-full h-9 pl-9 pr-3 rounded-lg bg-white border border-[#D8D0BE] text-xs text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A]"
                  />
                </div>
                <select
                  value={commonCategory}
                  onChange={(e) => setCommonCategory(e.target.value)}
                  className="h-9 px-3 rounded-lg bg-white border border-[#D8D0BE] text-xs text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                >
                  <option value="all">All Categories</option>
                  {commonCategories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  value={commonLocation}
                  onChange={(e) => setCommonLocation(e.target.value)}
                  placeholder="Filter by location..."
                  className="h-9 px-3 rounded-lg bg-white border border-[#D8D0BE] text-xs text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A]"
                />
                <input
                  type="date"
                  value={commonDate}
                  onChange={(e) => setCommonDate(e.target.value)}
                  className="h-9 px-3 rounded-lg bg-white border border-[#D8D0BE] text-xs text-[#1C2524] font-mono-tabular focus:outline-none focus:border-[#174C4A]"
                />
                <select
                  value={commonStatus}
                  onChange={(e) => setCommonStatus(e.target.value)}
                  className="h-9 px-3 rounded-lg bg-white border border-[#D8D0BE] text-xs text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                >
                  <option value="all">All Statuses</option>
                  <option value="submitted">Submitted</option>
                  <option value="under_review">Under Review</option>
                  <option value="possible_match">In Progress</option>
                  <option value="verified">Confirmed</option>
                  <option value="recovered">Recovered</option>
                  <option value="closed">Closed</option>
                </select>
              </div>

              {filteredCommonItems.length === 0 ? (
                <div className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-12 text-center space-y-2">
                  <p className="text-sm font-semibold text-[#174C4A]">
                    No {commonTab === 'missing' ? 'lost' : 'found'} devices match your filters
                  </p>
                  <p className="text-xs text-[#55615F]">
                    Genuine reports submitted by any authorized {college.code} student appear here automatically.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredCommonItems.map((item) => {
                    const lc = LIFECYCLE_LABELS[item.lifecycle_status] || LIFECYCLE_LABELS.submitted;
                    const isMine = item.reporter_user_id === user.id;
                    return (
                      <div
                        key={item.id}
                        className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 flex flex-col justify-between gap-4 shadow-xs"
                      >
                        <div className="flex items-start gap-4">
                          {item.image_data ? (
                            <img
                              src={item.image_data}
                              alt={item.title}
                              className="w-20 h-20 rounded-xl object-cover border border-[#DFD8C8] shrink-0"
                            />
                          ) : (
                            <div className="w-20 h-20 rounded-xl bg-white border border-[#E2DCCB] flex items-center justify-center text-xs text-[#8E9694] shrink-0">
                              No Photo
                            </div>
                          )}
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-mono-tabular text-xs text-[#55615F]">
                                {item.report_code || `CF-${item.id}`}
                              </span>
                              <span className={`text-xs font-semibold ${lc.color}`}>{lc.label}</span>
                            </div>
                            <h3 className="text-base font-bold text-[#174C4A] mt-1 truncate">
                              {item.title}
                            </h3>
                            <p className="text-xs text-[#55615F] mt-0.5">
                              {item.device_type}
                              {item.brand ? ` · ${item.brand}` : ''}
                              {item.model ? ` ${item.model}` : ''}
                            </p>
                            <p className="text-xs text-[#55615F] mt-1 flex items-center gap-1">
                              <MapPin className="w-3.5 h-3.5 text-[#D98252] shrink-0" />
                              <span className="truncate">
                                {item.location || 'Location not specified'} · {item.reported_date}
                                {item.reported_time ? ` at ${item.reported_time}` : ''}
                              </span>
                            </p>
                          </div>
                        </div>

                        <p className="text-xs text-[#1C2524] leading-relaxed">{item.description}</p>

                        <div className="pt-3 border-t border-[#E6E0D0] flex items-center justify-between gap-2 text-[11px] text-[#55615F]">
                          <span className="truncate">
                            Reported by{' '}
                            <span className="font-medium text-[#174C4A]">
                              {isMine ? 'You' : item.reporter_name || `${college.code} Student`}
                            </span>
                            {item.reporter_department ? ` · ${item.reporter_department}` : ''}
                          </span>
                          <div className="flex items-center gap-3 shrink-0">
                            <button
                              type="button"
                              onClick={() => {
                                setDetailItemId(item.id);
                                setDetailMatchId(null);
                              }}
                              className="text-xs font-semibold text-[#174C4A] hover:text-[#D98252] cursor-pointer"
                            >
                              View Details
                            </button>
                            <span className="font-mono-tabular">
                              {new Date(item.created_at).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* 2. REPORT LOST DEVICE */}
          {section === 'report-lost' && (
            <DeviceReportForm
              type="missing"
              college={college}
              mapsApiKey={mapsApiKey}
              onSuccess={() => {
                refreshData();
                showToast('Lost device report submitted and synced live.');
              }}
            />
          )}

          {/* 3. REPORT FOUND DEVICE */}
          {section === 'report-found' && (
            <DeviceReportForm
              type="found"
              college={college}
              mapsApiKey={mapsApiKey}
              onSuccess={() => {
                refreshData();
                showToast('Found device report submitted and synced live.');
              }}
            />
          )}

          {/* 5. MY REPORTS (PERSONAL ONLY) */}
          {section === 'my-reports' && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#DFD8C8] pb-4">
                <div>
                  <h1 className="font-display text-2xl font-bold text-[#174C4A]">My Reports</h1>
                  <p className="text-sm text-[#55615F] mt-0.5">
                    Personal submissions linked to your account at {college.name}.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
                  <div className="inline-flex rounded-xl bg-[#EFEAE0] p-1 border border-[#DFD8C8]">
                    {(['all', 'missing', 'found'] as const).map((tab) => (
                      <button
                        key={tab}
                        type="button"
                        onClick={() => setMyReportsTab(tab)}
                        className={`h-8 px-3 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                          myReportsTab === tab
                            ? 'bg-[#174C4A] text-[#F4F1E8]'
                            : 'text-[#55615F] hover:text-[#174C4A]'
                        }`}
                      >
                        {tab === 'all' ? 'All' : tab === 'missing' ? 'My Lost' : 'My Found'}
                      </button>
                    ))}
                  </div>
                  <div className="relative flex-1 sm:w-64">
                    <Search className="w-4 h-4 text-[#55615F] absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search report ID, device, location..."
                      className="w-full h-10 pl-9 pr-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A]"
                    />
                  </div>
                </div>
              </div>

              {/* Personal Matches & Physical Handover Status */}
              {myMatches.length > 0 && (
                <div className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 space-y-4 shadow-xs">
                  <div>
                    <h2 className="font-display text-base font-bold text-[#174C4A]">
                      Match &amp; Physical Handover Status
                    </h2>
                    <p className="text-xs text-[#55615F] mt-0.5">
                      Review possible matches, track accepted matches, and confirm physical handover.
                    </p>
                  </div>
                  <div className="space-y-3">
                    {myMatches.map((m) => {
                      const isLost = m.missing_reporter_user_id === user.id;
                      const needsMyAction =
                        (m.workflow_status === 'POSSIBLE_MATCH' && isLost) ||
                        ((m.workflow_status === 'MATCH_ACCEPTED' ||
                          m.workflow_status === 'HANDOVER_PENDING') &&
                          ((isLost && !m.lost_owner_handover_confirmed) ||
                            (!isLost && !m.found_owner_handover_confirmed)));
                      return (
                        <div
                          key={m.id}
                          className="rounded-xl bg-white border border-[#E2DCCB] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                        >
                          <div className="min-w-0 space-y-1">
                            <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono-tabular">
                              <span className="font-semibold text-[#174C4A]">Match #{m.id}</span>
                              <span>·</span>
                              <span className="text-[#55615F]">
                                {m.found_report_code || `Found #${m.found_item_id}`}
                              </span>
                              <span className="px-2 py-0.5 rounded-md bg-[#174C4A]/10 text-[#174C4A] font-bold">
                                {m.workflow_status}
                              </span>
                            </div>
                            <p className="text-sm font-semibold text-[#1C2524] truncate">
                              {isLost ? m.found_title : m.missing_title}
                            </p>
                            <p className="text-xs text-[#55615F]">
                              {m.workflow_status === 'MATCH_ACCEPTED' &&
                                'Accepted — waiting for both students to confirm physical handover.'}
                              {m.workflow_status === 'HANDOVER_PENDING' &&
                                'One student confirmed handover — waiting for the other student to confirm.'}
                              {m.workflow_status === 'POSSIBLE_MATCH' &&
                                (isLost
                                  ? 'Possible match found — open to confirm whether this is your device.'
                                  : 'Awaiting review by the lost-device owner.')}
                              {m.workflow_status === 'RECOVERED' &&
                                'Physical handover confirmed by both students — RECOVERED.'}
                              {m.workflow_status === 'MATCH_REJECTED' &&
                                'Rejected — both original reports remain active.'}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setDetailItemId(m.found_item_id);
                              setDetailMatchId(m.id);
                            }}
                            className={`h-9 px-4 rounded-xl text-xs font-semibold shrink-0 cursor-pointer transition-colors ${
                              needsMyAction
                                ? 'bg-[#174C4A] text-[#F4F1E8] hover:bg-[#123D3B]'
                                : 'bg-[#F4F1E8] border border-[#D8D0BE] text-[#174C4A] hover:border-[#174C4A]'
                            }`}
                          >
                            {m.workflow_status === 'POSSIBLE_MATCH' && isLost
                              ? 'Review Match'
                              : m.workflow_status === 'MATCH_ACCEPTED' ||
                                  m.workflow_status === 'HANDOVER_PENDING'
                                ? 'Confirm Handover'
                                : 'View Details'}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {filteredMyItems.length === 0 ? (
                <div className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-12 text-center">
                  <p className="text-sm text-[#55615F]">No matching reports found.</p>
                  <button
                    type="button"
                    onClick={() => selectSection('report-lost')}
                    className="mt-4 h-9 px-4 rounded-lg bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold cursor-pointer"
                  >
                    Create Your First Report
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredMyItems.map((item) => {
                    const lc = LIFECYCLE_LABELS[item.lifecycle_status] || LIFECYCLE_LABELS.submitted;
                    return (
                      <div
                        key={item.id}
                        className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 flex flex-col justify-between gap-4 shadow-xs"
                      >
                        <div className="flex items-start gap-4">
                          {item.image_data ? (
                            <img
                              src={item.image_data}
                              alt={item.title}
                              className="w-20 h-20 rounded-xl object-cover border border-[#DFD8C8] shrink-0"
                            />
                          ) : (
                            <div className="w-20 h-20 rounded-xl bg-white border border-[#E2DCCB] flex items-center justify-center text-xs text-[#8E9694] shrink-0">
                              No Photo
                            </div>
                          )}
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-mono-tabular text-xs text-[#55615F]">
                                {item.report_code || `CF-${item.id}`}
                              </span>
                              <span className={`text-xs font-semibold ${lc.color}`}>{lc.label}</span>
                            </div>
                            <h3 className="text-base font-bold text-[#174C4A] mt-1 truncate">
                              {item.title}
                            </h3>
                            <p className="text-xs text-[#55615F] mt-0.5">
                              {item.type === 'missing' ? 'Lost' : 'Found'} · {item.device_type}
                              {item.brand ? ` · ${item.brand}` : ''}
                              {item.model ? ` ${item.model}` : ''}
                            </p>
                            <p className="text-xs text-[#55615F] mt-1">
                              {item.location} · {item.reported_date}
                              {item.reported_time ? ` at ${item.reported_time}` : ''}
                            </p>
                          </div>
                        </div>

                        <p className="text-xs text-[#1C2524] leading-relaxed">{item.description}</p>

                        <div className="pt-3 border-t border-[#E6E0D0] flex items-center justify-between gap-2">
                          <span className="text-[11px] text-[#55615F]">
                            Updated {new Date(item.created_at).toLocaleDateString()}
                          </span>
                          {item.lifecycle_status !== 'recovered' && item.lifecycle_status !== 'closed' && (
                            <button
                              type="button"
                              onClick={async () => {
                                await campusApi.updateItemLifecycle(item.id, 'recovered');
                                refreshData();
                                showToast('Marked as Recovered.');
                              }}
                              className="text-xs font-semibold text-[#D98252] hover:underline cursor-pointer"
                            >
                              Mark Recovered
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* 5. NOTIFICATIONS */}
          {section === 'notifications' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-[#DFD8C8] pb-4">
                <div>
                  <h1 className="font-display text-2xl font-bold text-[#174C4A]">Notifications</h1>
                  <p className="text-sm text-[#55615F] mt-0.5">
                    Real-time alerts for report status updates and device recoveries.
                  </p>
                </div>
                {unreadCount > 0 && (
                  <button
                    type="button"
                    onClick={async () => {
                      await campusApi.markAllNotificationsRead();
                      refreshData();
                    }}
                    className="h-9 px-3.5 rounded-lg bg-white border border-[#D8D0BE] text-xs font-semibold text-[#174C4A] hover:border-[#D98252] cursor-pointer"
                  >
                    Mark all read
                  </button>
                )}
              </div>

              {notifications.length === 0 ? (
                <div className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-12 text-center text-sm text-[#55615F]">
                  You have no notifications yet.
                </div>
              ) : (
                <div className="space-y-3">
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      className={`rounded-2xl p-4 sm:p-5 border flex items-start justify-between gap-4 ${
                        n.is_read
                          ? 'bg-[#FAF8F3] border-[#E2DCCB]'
                          : 'bg-white border-[#D98252]/55 shadow-xs'
                      }`}
                    >
                      <div className="min-w-0 flex-1 space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="text-sm font-bold text-[#174C4A]">{n.title}</p>
                          {n.match_workflow_status && n.related_match_id && (
                            <span className="font-mono-tabular text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#174C4A]/10 text-[#174C4A]">
                              {n.match_workflow_status}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-[#1C2524] leading-relaxed">{n.message}</p>
                        {(n.notification_type === 'match_accepted' ||
                          n.notification_type === 'handover_pending' ||
                          n.notification_type === 'recovery_completed') && (
                          <div className="pt-1 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-[#55615F] font-mono-tabular">
                            {n.found_report_code && <span>Found Report: {n.found_report_code}</span>}
                            {n.related_match_id && <span>Match ID: #{n.related_match_id}</span>}
                            {n.match_accepted_at && (
                              <span>Accepted: {new Date(n.match_accepted_at).toLocaleString()}</span>
                            )}
                          </div>
                        )}
                        <p className="text-[11px] text-[#55615F] pt-0.5 font-mono-tabular">
                          {new Date(n.created_at).toLocaleString()}
                        </p>
                      </div>
                      <div className="flex flex-col sm:flex-row items-end sm:items-center gap-2 shrink-0">
                        {(n.notification_type === 'match_found' ||
                          n.notification_type === 'match_accepted' ||
                          n.notification_type === 'handover_pending' ||
                          n.notification_type === 'recovery_completed') &&
                          typeof n.related_found_item_id === 'number' && (
                            <button
                              type="button"
                              onClick={() => handleViewMatchedDevice(n)}
                              className="h-8 px-3 rounded-lg bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold hover:bg-[#123D3B] cursor-pointer"
                            >
                              {n.notification_type === 'match_found'
                                ? 'VIEW FOUND DEVICE'
                                : n.match_workflow_status === 'MATCH_ACCEPTED' ||
                                    n.match_workflow_status === 'HANDOVER_PENDING'
                                  ? 'Confirm Handover'
                                  : 'View Match'}
                            </button>
                          )}
                        {!n.is_read && (
                          <button
                            type="button"
                            onClick={async () => {
                              await campusApi.markNotificationRead(n.id);
                              refreshData();
                            }}
                            className="text-xs font-semibold text-[#D98252] hover:underline shrink-0 cursor-pointer"
                          >
                            Mark read
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 6. CAMPUS MAP */}
          {section === 'campus-map' && (
            <div className="space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#DFD8C8] pb-4">
                <div>
                  <h1 className="font-display text-2xl font-bold text-[#174C4A]">Live Campus Map</h1>
                  <p className="text-sm text-[#55615F] mt-0.5">{college.address || college.name}</p>
                </div>
                {college.mapsUrl && (
                  <a
                    href={college.mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#D98252] hover:underline"
                  >
                    <span>Open Official Google Maps Reference</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>

              <div className="rounded-2xl overflow-hidden border border-[#E2DCCB] bg-[#FAF8F3] p-2 shadow-xs">
                <CampusGoogleMap
                  apiKey={mapsApiKey}
                  college={college}
                  items={commonItems.filter(
                    (i) =>
                      i.status !== 'archived' &&
                      typeof i.latitude === 'number' &&
                      Number.isFinite(i.latitude) &&
                      typeof i.longitude === 'number' &&
                      Number.isFinite(i.longitude)
                  )}
                  heightClass="h-[520px]"
                />
              </div>
            </div>
          )}

          {/* 7. PROFILE */}
          {section === 'profile' && (
            <div className="max-w-2xl space-y-6">
              <div className="border-b border-[#DFD8C8] pb-4">
                <h1 className="font-display text-2xl font-bold text-[#174C4A]">Student Profile</h1>
                <p className="text-sm text-[#55615F] mt-0.5">
                  Manage your academic profile details linked to {college.name}.
                </p>
              </div>

              <form
                onSubmit={handleProfileSave}
                className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-6 space-y-4 shadow-xs"
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5 sm:col-span-2">
                    <label className="text-xs font-semibold text-[#174C4A]">Full Name</label>
                    <input
                      type="text"
                      required
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-[#174C4A]">Department</label>
                    {college.departments && college.departments.length > 0 ? (
                      <select
                        value={profileDept}
                        onChange={(e) => setProfileDept(e.target.value)}
                        className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                      >
                        <option value="">Select Department</option>
                        {college.departments.map((dept) => (
                          <option key={dept} value={dept}>
                            {dept}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input
                        type="text"
                        value={profileDept}
                        onChange={(e) => setProfileDept(e.target.value)}
                        className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                      />
                    )}
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-[#174C4A]">Academic Year</label>
                    {college.academicYears && college.academicYears.length > 0 ? (
                      <select
                        value={profileYear}
                        onChange={(e) => setProfileYear(e.target.value)}
                        className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                      >
                        <option value="">Select Academic Year</option>
                        {college.academicYears.map((yr) => (
                          <option key={yr} value={yr}>
                            {yr}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input
                        type="text"
                        value={profileYear}
                        onChange={(e) => setProfileYear(e.target.value)}
                        placeholder="1st Year, 2nd Year..."
                        className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                      />
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-[#E6E0D0] text-xs">
                  <div>
                    <p className="text-[#55615F]">College Email</p>
                    <p className="text-[#174C4A] font-semibold mt-0.5 font-mono-tabular">
                      {user.identifier}
                    </p>
                  </div>
                  <div>
                    <p className="text-[#55615F]">Student ID</p>
                    <p className="text-[#174C4A] font-semibold mt-0.5 font-mono-tabular">
                      {user.studentId || 'Not assigned'}
                    </p>
                  </div>
                </div>

                {profileSaved && (
                  <div className="flex items-center gap-2 text-xs font-medium text-[#174C4A]">
                    <CheckCircle2 className="w-4 h-4 text-[#D98252]" />
                    <span>{profileSaved}</span>
                  </div>
                )}

                <button
                  type="submit"
                  className="h-10 px-5 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold hover:bg-[#123D3B] cursor-pointer"
                >
                  Save Profile Changes
                </button>
              </form>
            </div>
          )}

          {/* 8. SETTINGS */}
          {section === 'settings' && (
            <div className="max-w-2xl space-y-6">
              <div className="border-b border-[#DFD8C8] pb-4">
                <h1 className="font-display text-2xl font-bold text-[#174C4A]">Settings</h1>
                <p className="text-sm text-[#55615F] mt-0.5">
                  Configure real-time notification preferences for your campus account.
                </p>
              </div>

              <div className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-6 space-y-5 shadow-xs">
                <label className="flex items-center justify-between gap-4 cursor-pointer">
                  <div>
                    <p className="text-sm font-semibold text-[#174C4A]">Live Status Alerts</p>
                    <p className="text-xs text-[#55615F]">
                      Show instant in-app notifications when your reported device status changes.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={emailAlerts}
                    onChange={(e) => setEmailAlerts(e.target.checked)}
                    className="w-4 h-4 accent-[#174C4A]"
                  />
                </label>

                <label className="flex items-center justify-between gap-4 pt-4 border-t border-[#E6E0D0] cursor-pointer">
                  <div>
                    <p className="text-sm font-semibold text-[#174C4A]">Recovery Alert Chime</p>
                    <p className="text-xs text-[#55615F]">
                      Play a subtle alert tone when a report is marked as Recovered.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={soundAlerts}
                    onChange={(e) => setSoundAlerts(e.target.checked)}
                    className="w-4 h-4 accent-[#174C4A]"
                  />
                </label>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Character-Based Match Notification Popup (only when unread match_found notifications exist) */}
      <MatchNotificationPopup
        notifications={unreadMatchNotifications}
        onViewFoundDevice={handleViewMatchedDevice}
        onDismiss={handleDismissMatchPopup}
      />

      {/* Complete Found / Lost Device Details & Match Handover Modal */}
      <FoundDeviceDetailModal
        itemId={detailItemId}
        matchId={detailMatchId}
        currentUserId={user.id}
        onClose={() => {
          setDetailItemId(null);
          setDetailMatchId(null);
        }}
        onViewOnMap={() => selectSection('campus-map')}
        onMatchUpdated={(msg) => {
          refreshData();
          if (msg) showToast(msg);
        }}
      />
    </div>
  );
}
