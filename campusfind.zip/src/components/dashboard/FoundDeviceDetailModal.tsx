import { useEffect, useState } from 'react';
import {
  Building2,
  Calendar,
  CheckCircle2,
  Clock,
  GraduationCap,
  Handshake,
  Loader2,
  MapPin,
  Palette,
  Smartphone,
  Tag,
  User as UserIcon,
  X,
  XCircle,
} from 'lucide-react';
import { campusApi } from '../../lib/api';
import type {
  CampusMatch,
  FoundDeviceDetails,
  MatchWorkflowStatus,
} from '../../types/campusfind';
import { CharacterConfirmModal } from '../cinematic/CharacterConfirmModal';

interface FoundDeviceDetailModalProps {
  itemId: number | null;
  matchId?: number | null;
  currentUserId?: number;
  onClose: () => void;
  onViewOnMap?: () => void;
  onMatchUpdated?: (message?: string) => void;
}

const STATUS_LABELS: Record<string, string> = {
  submitted: 'Submitted',
  under_review: 'Under Review',
  possible_match: 'Possible Match',
  verified: 'Verified',
  recovered: 'Recovered',
  closed: 'Closed',
};

const WORKFLOW_BADGE: Record<MatchWorkflowStatus, { label: string; style: string }> = {
  POSSIBLE_MATCH: {
    label: 'POSSIBLE_MATCH',
    style: 'bg-[#D98252]/15 text-[#8C3B16] border border-[#D98252]/40',
  },
  MATCH_ACCEPTED: {
    label: 'MATCH_ACCEPTED',
    style: 'bg-[#174C4A]/12 text-[#174C4A] border border-[#174C4A]/30',
  },
  MATCH_REJECTED: {
    label: 'MATCH_REJECTED',
    style: 'bg-[#55615F]/15 text-[#55615F] border border-[#55615F]/30',
  },
  HANDOVER_PENDING: {
    label: 'HANDOVER_PENDING',
    style: 'bg-[#D98252]/20 text-[#8C3B16] border border-[#D98252]/45',
  },
  RECOVERED: {
    label: 'RECOVERED',
    style: 'bg-[#174C4A] text-[#F4F1E8] border border-[#174C4A]',
  },
};

export function FoundDeviceDetailModal({
  itemId,
  matchId = null,
  currentUserId,
  onClose,
  onViewOnMap,
  onMatchUpdated,
}: FoundDeviceDetailModalProps) {
  const [details, setDetails] = useState<FoundDeviceDetails | null>(null);
  const [match, setMatch] = useState<CampusMatch | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [actionBusy, setActionBusy] = useState(false);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [confirmAction, setConfirmAction] = useState<'accept' | 'reject' | 'handover' | null>(null);

  useEffect(() => {
    if (!itemId) {
      setDetails(null);
      setMatch(null);
      setError(null);
      setActionFeedback(null);
      setActionError(null);
      setConfirmAction(null);
      return;
    }
    let active = true;
    setLoading(true);
    setError(null);
    setActionFeedback(null);
    setActionError(null);

    Promise.all([
      campusApi.getItemDetails(itemId),
      matchId ? campusApi.getMatch(matchId).catch(() => null) : Promise.resolve(null),
    ])
      .then(([itemRes, matchRes]) => {
        if (!active) return;
        setDetails(itemRes.details);
        setMatch(matchRes?.match ?? null);
      })
      .catch((err) => {
        if (active) {
          setError(err instanceof Error ? err.message : 'Unable to load device details.');
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [itemId, matchId]);

  if (!itemId) return null;

  const hasValidCoords =
    details !== null &&
    typeof details.latitude === 'number' &&
    Number.isFinite(details.latitude) &&
    typeof details.longitude === 'number' &&
    Number.isFinite(details.longitude);

  const isLostOwner =
    match !== null && currentUserId !== undefined && match.missing_reporter_user_id === currentUserId;
  const isFoundOwner =
    match !== null && currentUserId !== undefined && match.found_reporter_user_id === currentUserId;

  const handleConfirmMatchAction = async () => {
    if (!match || !confirmAction) return;
    setActionBusy(true);
    setActionError(null);
    setActionFeedback(null);
    try {
      if (confirmAction === 'accept') {
        const res = await campusApi.acceptMatch(match.id);
        setMatch(res.match);
        setActionFeedback(res.message);
        onMatchUpdated?.(res.message);
      } else if (confirmAction === 'reject') {
        const res = await campusApi.rejectMatch(match.id);
        setMatch(res.match);
        setActionFeedback(res.message);
        onMatchUpdated?.(res.message);
      } else if (confirmAction === 'handover') {
        const res = await campusApi.confirmMatchHandover(match.id);
        setMatch(res.match);
        setActionFeedback(res.message);
        if (res.recovered && itemId) {
          const refreshed = await campusApi.getItemDetails(itemId).catch(() => null);
          if (refreshed) setDetails(refreshed.details);
        }
        onMatchUpdated?.(res.message);
      }
      setConfirmAction(null);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Unable to complete action.');
      setConfirmAction(null);
    } finally {
      setActionBusy(false);
    }
  };

  const confirmCopy = (() => {
    if (confirmAction === 'accept') {
      return {
        question: 'Are you sure this is your device?',
        details:
          'Accepting notifies the student who found the device. The device will only be marked as RECOVERED after both of you confirm physical handover.',
        confirmLabel: "YES, IT'S MINE",
        cancelLabel: 'Cancel',
      };
    }
    if (confirmAction === 'reject') {
      return {
        question: 'Are you sure this device is not yours?',
        details:
          'Rejecting this match will keep both your lost report and this found report active in the campus registry without deleting either report.',
        confirmLabel: "NO, IT'S NOT MINE",
        cancelLabel: 'Cancel',
      };
    }
    return {
      question: isLostOwner
        ? 'Confirm that you have physically received your device?'
        : 'Confirm that you have physically handed over this device?',
      details:
        'Recovery is completed only after both the lost-device owner and the finder confirm physical handover.',
      confirmLabel: isLostOwner ? 'I have received my device' : 'I have handed over the device',
      cancelLabel: 'Cancel',
    };
  })();

  const wfStatus: MatchWorkflowStatus | null = match?.workflow_status ?? null;

  return (
    <>
      <div
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1C2524]/55 backdrop-blur-xs"
        role="dialog"
        aria-modal="true"
        aria-labelledby="found-device-detail-title"
      >
        <div className="w-full max-w-2xl max-h-[90vh] rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] shadow-2xl overflow-hidden flex flex-col">
          {/* Header */}
          <div className="px-6 py-4 border-b border-[#E2DCCB] bg-[#F4F1E8] flex items-center justify-between gap-4">
            <div className="min-w-0">
              <p className="text-[11px] font-mono-tabular font-semibold uppercase tracking-wider text-[#D98252]">
                {details
                  ? `${details.reportCode} · ${details.type === 'found' ? 'Found Device Report' : 'Lost Device Report'}`
                  : 'Device Report Details'}
              </p>
              <h2
                id="found-device-detail-title"
                className="font-display text-lg sm:text-xl font-bold text-[#174C4A] truncate"
              >
                {details?.title || 'Loading device details...'}
              </h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close device details"
              className="p-2 rounded-lg text-[#55615F] hover:text-[#174C4A] hover:bg-white transition-colors cursor-pointer shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {loading && (
              <div className="py-12 flex flex-col items-center justify-center gap-3 text-sm text-[#55615F]">
                <Loader2 className="w-6 h-6 animate-spin text-[#174C4A]" />
                <span>Fetching genuine report record...</span>
              </div>
            )}

            {error && !loading && (
              <div className="rounded-xl bg-[#D98252]/15 border border-[#D98252]/40 p-4 text-sm text-[#7A3A1B]">
                {error}
              </div>
            )}

            {actionFeedback && (
              <div
                role="status"
                className="rounded-xl bg-[#174C4A]/10 border border-[#174C4A]/30 p-4 flex items-start gap-2.5 text-xs text-[#174C4A]"
              >
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-[#174C4A]" />
                <span className="font-semibold">{actionFeedback}</span>
              </div>
            )}

            {actionError && (
              <div
                role="alert"
                className="rounded-xl bg-[#D98252]/15 border border-[#D98252]/40 p-4 text-xs text-[#7A3A1B]"
              >
                {actionError}
              </div>
            )}

            {details && !loading && (
              <>
                {/* Match Acceptance & Physical Handover Workflow Panel (only when opened from a match) */}
                {match && wfStatus && (isLostOwner || isFoundOwner) && (
                  <div className="rounded-xl bg-[#F4F1E8] border border-[#D8D0BE] p-4 space-y-3.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <Handshake className="w-4 h-4 text-[#D98252]" />
                        <span className="text-xs font-bold text-[#174C4A] uppercase tracking-wider">
                          Match #{match.id} Workflow
                        </span>
                      </div>
                      <span
                        className={`font-mono-tabular text-[11px] font-bold px-2.5 py-0.5 rounded-lg ${WORKFLOW_BADGE[wfStatus].style}`}
                      >
                        {WORKFLOW_BADGE[wfStatus].label}
                      </span>
                    </div>

                    {/* Stage 1: User 1 Acceptance or Rejection */}
                    {wfStatus === 'POSSIBLE_MATCH' && isLostOwner && (
                      <div className="space-y-3">
                        <p className="text-xs text-[#42504E] leading-relaxed">
                          Review the genuine found report below. Is this your lost device (
                          <span className="font-semibold text-[#174C4A]">{match.missing_title}</span>
                          )?
                        </p>
                        <div className="flex flex-col sm:flex-row gap-2.5">
                          <button
                            type="button"
                            disabled={actionBusy}
                            onClick={() => setConfirmAction('accept')}
                            className="flex-1 h-10 px-4 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold hover:bg-[#123D3B] disabled:opacity-60 flex items-center justify-center gap-2 cursor-pointer"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>YES, IT&apos;S MINE.</span>
                          </button>
                          <button
                            type="button"
                            disabled={actionBusy}
                            onClick={() => setConfirmAction('reject')}
                            className="flex-1 h-10 px-4 rounded-xl bg-white border border-[#D98252] text-[#8C3B16] text-xs font-semibold hover:bg-[#D98252]/10 disabled:opacity-60 flex items-center justify-center gap-2 cursor-pointer"
                          >
                            <XCircle className="w-4 h-4" />
                            <span>NO, IT&apos;S NOT MINE.</span>
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Stage 2: Accepted / Handover Pending — Dual Physical Handover Confirmation */}
                    {(wfStatus === 'MATCH_ACCEPTED' || wfStatus === 'HANDOVER_PENDING') && (
                      <div className="space-y-3">
                        <p className="text-xs text-[#42504E] leading-relaxed">
                          Match accepted{match.accepted_at ? ` on ${new Date(match.accepted_at).toLocaleString()}` : ''}.{' '}
                          <span className="font-semibold text-[#174C4A]">
                            Device is not yet marked as RECOVERED.
                          </span>{' '}
                          Both students must confirm after the physical handover takes place.
                        </p>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                          <div className="rounded-lg bg-white border border-[#E2DCCB] p-3">
                            <p className="text-[11px] text-[#55615F]">Lost Device Owner</p>
                            <p className="font-semibold text-[#174C4A] mt-0.5">
                              {match.lost_owner_handover_confirmed
                                ? 'Confirmed receipt'
                                : 'Pending receipt confirmation'}
                            </p>
                            {match.lost_owner_handover_at && (
                              <p className="text-[10px] font-mono-tabular text-[#55615F] mt-0.5">
                                {new Date(match.lost_owner_handover_at).toLocaleString()}
                              </p>
                            )}
                          </div>
                          <div className="rounded-lg bg-white border border-[#E2DCCB] p-3">
                            <p className="text-[11px] text-[#55615F]">Found Device Student</p>
                            <p className="font-semibold text-[#174C4A] mt-0.5">
                              {match.found_owner_handover_confirmed
                                ? 'Confirmed handover'
                                : 'Pending handover confirmation'}
                            </p>
                            {match.found_owner_handover_at && (
                              <p className="text-[10px] font-mono-tabular text-[#55615F] mt-0.5">
                                {new Date(match.found_owner_handover_at).toLocaleString()}
                              </p>
                            )}
                          </div>
                        </div>

                        {isLostOwner && !match.lost_owner_handover_confirmed && (
                          <button
                            type="button"
                            disabled={actionBusy}
                            onClick={() => setConfirmAction('handover')}
                            className="w-full h-10 px-4 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold hover:bg-[#123D3B] disabled:opacity-60 flex items-center justify-center gap-2 cursor-pointer"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>I have received my device.</span>
                          </button>
                        )}

                        {isFoundOwner && !match.found_owner_handover_confirmed && (
                          <button
                            type="button"
                            disabled={actionBusy}
                            onClick={() => setConfirmAction('handover')}
                            className="w-full h-10 px-4 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold hover:bg-[#123D3B] disabled:opacity-60 flex items-center justify-center gap-2 cursor-pointer"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>I have handed over the device.</span>
                          </button>
                        )}
                      </div>
                    )}

                    {/* Stage 3: Rejected */}
                    {wfStatus === 'MATCH_REJECTED' && (
                      <p className="text-xs text-[#55615F]">
                        This match was rejected
                        {match.rejected_at ? ` on ${new Date(match.rejected_at).toLocaleString()}` : ''}.
                        Both original reports remain preserved in the campus registry.
                      </p>
                    )}

                    {/* Stage 4: Recovered */}
                    {wfStatus === 'RECOVERED' && (
                      <p className="text-xs font-semibold text-[#174C4A]">
                        Physical handover confirmed by both students
                        {match.recovered_at ? ` on ${new Date(match.recovered_at).toLocaleString()}` : ''}.
                        Both reports are now marked as RECOVERED.
                      </p>
                    )}
                  </div>
                )}

                {/* Device Photo + Primary Metadata */}
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-5 items-start">
                  <div className="sm:col-span-5">
                    {details.imageData ? (
                      <img
                        src={details.imageData}
                        alt={details.title}
                        className="w-full h-52 object-cover rounded-xl border border-[#DFD8C8] bg-white"
                      />
                    ) : (
                      <div className="w-full h-44 rounded-xl bg-white border border-[#E2DCCB] flex flex-col items-center justify-center text-xs text-[#8E9694] gap-1.5">
                        <Smartphone className="w-6 h-6 text-[#CBBFA8]" />
                        <span>No photo uploaded</span>
                      </div>
                    )}
                  </div>

                  <div className="sm:col-span-7 space-y-3">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2.5 py-1 rounded-lg bg-[#174C4A]/10 text-[#174C4A] text-xs font-semibold">
                        {details.deviceType || details.category}
                      </span>
                      <span className="px-2.5 py-1 rounded-lg bg-white border border-[#DFD8C8] text-[#174C4A] text-xs font-semibold">
                        {STATUS_LABELS[details.lifecycleStatus] || details.lifecycleStatus}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs pt-1">
                      <div className="rounded-xl bg-white border border-[#E6E0D0] p-3">
                        <p className="text-[#55615F] flex items-center gap-1">
                          <Tag className="w-3.5 h-3.5 text-[#D98252]" />
                          <span>Brand</span>
                        </p>
                        <p className="font-semibold text-[#1C2524] mt-1">
                          {details.brand || 'Not provided'}
                        </p>
                      </div>
                      <div className="rounded-xl bg-white border border-[#E6E0D0] p-3">
                        <p className="text-[#55615F]">Model</p>
                        <p className="font-semibold text-[#1C2524] mt-1">
                          {details.model || 'Not provided'}
                        </p>
                      </div>
                      <div className="rounded-xl bg-white border border-[#E6E0D0] p-3 col-span-2">
                        <p className="text-[#55615F] flex items-center gap-1">
                          <Palette className="w-3.5 h-3.5 text-[#D98252]" />
                          <span>Colour</span>
                        </p>
                        <p className="font-semibold text-[#1C2524] mt-1">
                          {details.color || 'Not provided'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Description & Additional Info */}
                <div className="rounded-xl bg-white border border-[#E6E0D0] p-4 space-y-3 text-xs">
                  <div>
                    <p className="font-semibold text-[#174C4A] uppercase tracking-wider text-[11px]">
                      Description
                    </p>
                    <p className="text-[#1C2524] mt-1 leading-relaxed">
                      {details.description || 'Not provided'}
                    </p>
                  </div>
                  {details.additionalInfo ? (
                    <div className="pt-2.5 border-t border-[#EFEAE0]">
                      <p className="font-semibold text-[#174C4A] uppercase tracking-wider text-[11px]">
                        Additional Information
                      </p>
                      <p className="text-[#1C2524] mt-1 leading-relaxed">{details.additionalInfo}</p>
                    </div>
                  ) : null}
                </div>

                {/* Report Location, Date & Time */}
                <div className="rounded-xl bg-white border border-[#E6E0D0] p-4 space-y-3 text-xs">
                  <p className="font-semibold text-[#174C4A] uppercase tracking-wider text-[11px]">
                    {details.type === 'found' ? 'Found Report Information' : 'Lost Report Information'}
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="flex items-start gap-2">
                      <MapPin className="w-4 h-4 text-[#D98252] shrink-0 mt-0.5" />
                      <div>
                        <p className="text-[#55615F]">Campus Location</p>
                        <p className="font-semibold text-[#1C2524]">
                          {details.location || 'Not provided'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Calendar className="w-4 h-4 text-[#D98252] shrink-0 mt-0.5" />
                      <div>
                        <p className="text-[#55615F]">
                          {details.type === 'found' ? 'Date Found' : 'Date Lost'}
                        </p>
                        <p className="font-semibold text-[#1C2524] font-mono-tabular">
                          {details.reportedDate || 'Not provided'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Clock className="w-4 h-4 text-[#D98252] shrink-0 mt-0.5" />
                      <div>
                        <p className="text-[#55615F]">Approximate Time</p>
                        <p className="font-semibold text-[#1C2524] font-mono-tabular">
                          {details.reportedTime || 'Not provided'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Building2 className="w-4 h-4 text-[#D98252] shrink-0 mt-0.5" />
                      <div>
                        <p className="text-[#55615F]">Institution</p>
                        <p className="font-semibold text-[#1C2524]">
                          {details.institutionName} ({details.institutionCode})
                        </p>
                      </div>
                    </div>
                  </div>
                  <p className="text-[11px] text-[#55615F] pt-2 border-t border-[#EFEAE0] font-mono-tabular">
                    Submitted on {new Date(details.createdAt).toLocaleString()}
                  </p>
                </div>

                {/* Finder / Reporter Public Profile (Zero Private Email/Credentials) */}
                <div className="rounded-xl bg-[#F4F1E8] border border-[#E2DCCB] p-4 space-y-2.5 text-xs">
                  <p className="font-semibold text-[#174C4A] uppercase tracking-wider text-[11px]">
                    {details.type === 'found'
                      ? 'Reported By (Finder Student Profile)'
                      : 'Reported By (Student Profile)'}
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="flex items-start gap-2">
                      <UserIcon className="w-4 h-4 text-[#174C4A] shrink-0 mt-0.5" />
                      <div>
                        <p className="text-[#55615F]">Student Name</p>
                        <p className="font-semibold text-[#1C2524]">
                          {details.reporter.name || 'Not provided'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Building2 className="w-4 h-4 text-[#174C4A] shrink-0 mt-0.5" />
                      <div>
                        <p className="text-[#55615F]">Department</p>
                        <p className="font-semibold text-[#1C2524]">
                          {details.reporter.department || 'Not provided'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <GraduationCap className="w-4 h-4 text-[#174C4A] shrink-0 mt-0.5" />
                      <div>
                        <p className="text-[#55615F]">Academic Year</p>
                        <p className="font-semibold text-[#1C2524]">
                          {details.reporter.academicYear || 'Not provided'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Footer Actions */}
          <div className="px-6 py-4 border-t border-[#E2DCCB] bg-[#F4F1E8] flex flex-wrap items-center justify-between gap-3">
            {hasValidCoords && onViewOnMap ? (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onViewOnMap();
                }}
                className="h-10 px-4 rounded-xl bg-[#D98252] text-white text-xs font-semibold hover:bg-[#c57042] transition-colors inline-flex items-center gap-2 cursor-pointer"
              >
                <MapPin className="w-4 h-4" />
                <span>View on Campus Map</span>
              </button>
            ) : (
              <span className="text-[11px] text-[#55615F]">
                {details ? `Reference ID: ${details.reportCode}` : ''}
              </span>
            )}
            <button
              type="button"
              onClick={onClose}
              className="h-10 px-5 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold hover:bg-[#123D3B] transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>

      {/* Existing 3D Character Confirmation Dialog */}
      <CharacterConfirmModal
        open={confirmAction !== null}
        question={confirmCopy.question}
        details={confirmCopy.details}
        confirmLabel={confirmCopy.confirmLabel}
        cancelLabel={confirmCopy.cancelLabel}
        busy={actionBusy}
        onConfirm={handleConfirmMatchAction}
        onCancel={() => {
          if (!actionBusy) setConfirmAction(null);
        }}
      />
    </>
  );
}
