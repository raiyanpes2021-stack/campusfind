import { useState, type ChangeEvent, type FormEvent } from 'react';
import { X, Loader2, Upload, MapPin } from 'lucide-react';
import { campusApi } from '../../lib/api';
import type { CollegeSummary } from '../../types/campusfind';
import { CampusGoogleMap } from '../maps/CampusGoogleMap';

interface ReportItemModalProps {
  open: boolean;
  defaultType: 'missing' | 'found';
  college: CollegeSummary;
  mapsApiKey: string;
  onClose: () => void;
  onCreated: (autoMatched: boolean) => void;
}

const DEVICE_TYPES = [
  'Smartphone',
  'Laptop',
  'Tablet',
  'Smartwatch',
  'Earbuds',
  'Other Electronic Device',
];

function compressImageFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxDim = 960;
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(String(reader.result));
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
      img.onerror = () => reject(new Error('Could not read image file.'));
      img.src = String(reader.result);
    };
    reader.onerror = () => reject(new Error('Failed to load image file.'));
    reader.readAsDataURL(file);
  });
}

export function ReportItemModal({
  open,
  defaultType,
  college,
  mapsApiKey,
  onClose,
  onCreated,
}: ReportItemModalProps) {
  const campusZones = college.zones || [];
  const [type, setType] = useState<'missing' | 'found'>(defaultType);
  const [title, setTitle] = useState('');
  const [deviceType, setDeviceType] = useState(DEVICE_TYPES[0]);
  const [location, setLocation] = useState(campusZones[0] || college.name);
  const [coords, setCoords] = useState<{ lat: number; lng: number }>({
    lat: college.latitude,
    lng: college.longitude,
  });
  const [reportedDate, setReportedDate] = useState(new Date().toISOString().slice(0, 10));
  const [description, setDescription] = useState('');
  const [imageData, setImageData] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Please upload a valid PNG, JPG, or WebP device photo.');
      return;
    }
    try {
      const compressed = await compressImageFile(file);
      setImageData(compressed);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to process image.');
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await campusApi.createItem({
        type,
        title: title.trim(),
        category: 'Electronics',
        deviceType,
        location: location.trim(),
        latitude: coords.lat,
        longitude: coords.lng,
        description: description.trim(),
        reportedDate,
        imageData,
      });
      setTitle('');
      setDescription('');
      setImageData(null);
      onCreated(res.autoMatchCreated);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save report.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#020612]/85 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="report-modal-title"
    >
      <div className="w-full max-w-2xl rounded-2xl bg-[#0a162b] border border-cyan-400/20 shadow-[0_24px_70px_rgba(0,0,0,0.75)] p-6 my-8">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h2 id="report-modal-title" className="font-display text-lg font-semibold text-white">
              Report Electronic Device
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              {college.name} · Pin exact campus coordinates &amp; attach a photo for AI matching.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="w-9 h-9 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800/70 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-[#050d1c] border border-slate-800">
            <button
              type="button"
              onClick={() => setType('missing')}
              className={`h-9 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                type === 'missing'
                  ? 'bg-[#122645] text-cyan-200 border border-cyan-400/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Lost Device
            </button>
            <button
              type="button"
              onClick={() => setType('found')}
              className={`h-9 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                type === 'found'
                  ? 'bg-[#122645] text-teal-200 border border-teal-400/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Found Device
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="space-y-1.5">
              <label htmlFor="item-title" className="block text-xs font-medium text-slate-300">
                Device Model / Title
              </label>
              <input
                id="item-title"
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={type === 'missing' ? 'e.g., iPhone 15 Pro Titanium' : 'e.g., Silver Laptop in Black Sleeve'}
                className="w-full h-10 px-3.5 rounded-xl bg-[#071224] border border-slate-700/80 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div className="space-y-1.5">
              <label htmlFor="item-device-type" className="block text-xs font-medium text-slate-300">
                Electronic Device Type
              </label>
              <select
                id="item-device-type"
                value={deviceType}
                onChange={(e) => setDeviceType(e.target.value)}
                className="w-full h-10 px-3 rounded-xl bg-[#071224] border border-slate-700/80 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
              >
                {DEVICE_TYPES.map((dt) => (
                  <option key={dt} value={dt} className="bg-[#071224]">
                    {dt}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="space-y-1.5">
              <label htmlFor="item-location" className="block text-xs font-medium text-slate-300">
                Campus Zone / Building
              </label>
              <input
                id="item-location"
                type="text"
                list="campus-zone-options"
                required
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Building, lab, or floor"
                className="w-full h-10 px-3.5 rounded-xl bg-[#071224] border border-slate-700/80 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
              />
              <datalist id="campus-zone-options">
                {campusZones.map((zone) => (
                  <option key={zone} value={zone} />
                ))}
              </datalist>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="item-date" className="block text-xs font-medium text-slate-300">
                Date
              </label>
              <input
                id="item-date"
                type="date"
                required
                value={reportedDate}
                onChange={(e) => setReportedDate(e.target.value)}
                className="w-full h-10 px-3 rounded-xl bg-[#071224] border border-slate-700/80 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          {/* Interactive Google Maps Campus Pin Picker */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-300 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                Select Specific Campus Location
              </span>
              <span className="font-mono-tabular text-cyan-300 text-[11px]">
                {coords.lat.toFixed(5)}, {coords.lng.toFixed(5)}
              </span>
            </div>
            <CampusGoogleMap
              apiKey={mapsApiKey}
              college={college}
              pickerMode
              selectedCoords={coords}
              heightClass="h-[220px]"
              onSelectLocation={(picked) => {
                setCoords({ lat: picked.lat, lng: picked.lng });
                if (picked.label) setLocation(picked.label);
              }}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 items-start">
            <div className="space-y-1.5">
              <label htmlFor="item-desc" className="block text-xs font-medium text-slate-300">
                Identifying Characteristics
              </label>
              <textarea
                id="item-desc"
                rows={3}
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Color, protective case, scratches, stickers, lock-screen wallpaper..."
                className="w-full p-3 rounded-xl bg-[#071224] border border-slate-700/80 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 resize-none"
              />
            </div>

            <div className="space-y-1.5">
              <span className="block text-xs font-medium text-slate-300">
                Device Photo (For AI Visual Matching)
              </span>
              <label className="flex flex-col items-center justify-center h-[88px] rounded-xl border border-dashed border-slate-700 bg-[#071224] hover:border-cyan-400/60 transition-colors cursor-pointer overflow-hidden relative">
                {imageData ? (
                  <img src={imageData} alt="Uploaded device preview" className="w-full h-full object-cover" />
                ) : (
                  <div className="flex flex-col items-center gap-1 text-xs text-slate-400">
                    <Upload className="w-4 h-4 text-cyan-400" />
                    <span>Upload PNG / JPG photo</span>
                  </div>
                )}
                <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
              </label>
            </div>
          </div>

          {error && (
            <div className="px-3.5 py-2 rounded-xl bg-rose-500/10 border border-rose-500/30 text-xs text-rose-200">
              {error}
            </div>
          )}

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="h-10 px-4 rounded-xl border border-slate-700 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="h-10 px-5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-400 text-[#04111f] text-xs font-semibold flex items-center gap-2 hover:brightness-110 disabled:opacity-60 transition-all cursor-pointer"
            >
              {submitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              <span>Save Device Report</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
