import { useState, type ChangeEvent, type FormEvent } from 'react';
import {
  CheckCircle2,
  Loader2,
  MapPin,
  Upload,
  X,
  Calendar,
  Clock,
  Smartphone,
  Tag,
} from 'lucide-react';
import { campusApi } from '../../lib/api';
import type { CampusItem, CollegeSummary } from '../../types/campusfind';
import { CampusGoogleMap } from '../maps/CampusGoogleMap';
import { CharacterConfirmModal } from '../cinematic/CharacterConfirmModal';

interface DeviceReportFormProps {
  type: 'missing' | 'found';
  college: CollegeSummary;
  mapsApiKey: string;
  onSuccess: (item: CampusItem, autoMatchCreated: boolean) => void;
}

const DEVICE_CATEGORIES = [
  'Smartphone',
  'Laptop',
  'Tablet',
  'Smartwatch',
  'Earbuds',
  'Other Electronic Device',
];

async function compressImageToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxDim = 960;
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          const ratio = Math.min(maxDim / width, maxDim / height);
          width = Math.round(width * ratio);
          height = Math.round(height * ratio);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(String(reader.result));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.82));
      };
      img.onerror = () => reject(new Error('Could not decode selected image.'));
      img.src = String(reader.result);
    };
    reader.onerror = () => reject(new Error('Failed to read image file.'));
    reader.readAsDataURL(file);
  });
}

export function DeviceReportForm({ type, college, mapsApiKey, onSuccess }: DeviceReportFormProps) {
  const zones =
    college.zones && college.zones.length > 0 ? college.zones : ['Main Campus Block', 'Central Library'];

  const [deviceType, setDeviceType] = useState('Smartphone');
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [color, setColor] = useState('');
  const [title, setTitle] = useState('');
  const [location, setLocation] = useState('');
  const [latitude, setLatitude] = useState<number | null>(null);
  const [longitude, setLongitude] = useState<number | null>(null);
  const [reportedDate, setReportedDate] = useState(new Date().toISOString().slice(0, 10));
  const [reportedTime, setReportedTime] = useState('');
  const [description, setDescription] = useState('');
  const [additionalInfo, setAdditionalInfo] = useState('');
  const [imageData, setImageData] = useState<string | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submittedResult, setSubmittedResult] = useState<{
    reportCode: string;
    autoMatch: boolean;
  } | null>(null);

  const handleImageChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Please upload a valid image file (PNG, JPG, or WebP).');
      return;
    }
    try {
      const compressed = await compressImageToDataUrl(file);
      setImageData(compressed);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to process image.');
    }
  };

  const handleRequestSubmit = (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmittedResult(null);

    const computedTitle =
      title.trim() || [brand.trim(), model.trim(), deviceType].filter(Boolean).join(' ');

    if (!computedTitle || !description.trim()) {
      setError('Please complete the device title and identifying description.');
      return;
    }

    setConfirmOpen(true);
  };

  const handleConfirmedSubmit = async () => {
    const computedTitle =
      title.trim() || [brand.trim(), model.trim(), deviceType].filter(Boolean).join(' ');

    setSubmitting(true);
    setError(null);
    try {
      const res = await campusApi.createItem({
        type,
        title: computedTitle,
        category: 'Electronics',
        deviceType,
        brand: brand.trim(),
        model: model.trim(),
        color: color.trim(),
        location: location.trim(),
        latitude: latitude ?? undefined,
        longitude: longitude ?? undefined,
        description: description.trim(),
        additionalInfo: additionalInfo.trim(),
        reportedDate,
        reportedTime,
        imageData,
      });

      setSubmittedResult({
        reportCode: res.item.report_code || `CF-${college.code}-${res.item.id}`,
        autoMatch: res.autoMatchCreated,
      });

      setConfirmOpen(false);
      setBrand('');
      setModel('');
      setColor('');
      setTitle('');
      setLocation('');
      setLatitude(null);
      setLongitude(null);
      setReportedTime('');
      setDescription('');
      setAdditionalInfo('');
      setImageData(null);

      onSuccess(res.item, res.autoMatchCreated);
    } catch (err) {
      setConfirmOpen(false);
      setError(err instanceof Error ? err.message : 'Failed to submit device report.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-[#DFD8C8] pb-4">
        <h1 className="font-display text-2xl font-bold text-[#174C4A] tracking-tight">
          {type === 'missing' ? 'Report Lost Electronic Device' : 'Report Found Electronic Device'}
        </h1>
        <p className="mt-1 text-sm text-[#55615F]">
          {type === 'missing'
            ? `Submit device details and pinpoint the last known location at ${college.name}.`
            : `Log a recovered device at ${college.name}. Campus administrators are notified immediately.`}
        </p>
      </div>

      {submittedResult && (
        <div
          role="status"
          className="rounded-xl bg-[#174C4A]/10 border border-[#174C4A]/25 px-4 py-3.5 flex items-start gap-3"
        >
          <CheckCircle2 className="w-5 h-5 text-[#174C4A] shrink-0 mt-0.5" />
          <div className="text-sm text-[#1C2524]">
            <p className="font-semibold text-[#174C4A]">
              Report submitted successfully — Reference ID:{' '}
              <span className="font-mono-tabular text-[#D98252]">{submittedResult.reportCode}</span>
            </p>
            <p className="text-xs text-[#55615F] mt-0.5">
              Your report is now live on the campus registry and visible to college administrators.
            </p>
          </div>
        </div>
      )}

      <form onSubmit={handleRequestSubmit} className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Left Column: Device Metadata & Image Upload */}
        <div className="xl:col-span-7 space-y-5 rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 sm:p-6 shadow-xs">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#174C4A] flex items-center gap-1.5">
                <Smartphone className="w-3.5 h-3.5 text-[#D98252]" />
                <span>Device Category</span>
              </label>
              <select
                value={deviceType}
                onChange={(e) => setDeviceType(e.target.value)}
                className="w-full h-11 px-3 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15"
              >
                {DEVICE_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat} className="bg-white text-[#1C2524]">
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#174C4A] flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-[#55615F]" />
                <span>Brand</span>
              </label>
              <input
                type="text"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                placeholder="Apple, Samsung, Dell..."
                className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#174C4A]">Model</label>
              <input
                type="text"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder="iPhone 15 Pro, Air M3..."
                className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2 space-y-1.5">
              <label className="text-xs font-semibold text-[#174C4A]">Report Title</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={
                  type === 'missing'
                    ? 'e.g., iPhone 15 Pro Natural Titanium in Clear Case'
                    : 'e.g., Silver Laptop in Grey Sleeve Found at Lab 2'
                }
                className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#174C4A]">Colour</label>
              <input
                type="text"
                value={color}
                onChange={(e) => setColor(e.target.value)}
                placeholder="Black, Silver, Blue..."
                className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#174C4A] flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-[#D98252]" />
                <span>{type === 'missing' ? 'Date Lost' : 'Date Found'}</span>
              </label>
              <input
                type="date"
                required
                value={reportedDate}
                onChange={(e) => setReportedDate(e.target.value)}
                className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] font-mono-tabular focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#174C4A] flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-[#D98252]" />
                <span>Approximate Time</span>
              </label>
              <input
                type="time"
                value={reportedTime}
                onChange={(e) => setReportedTime(e.target.value)}
                className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] font-mono-tabular focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#174C4A]">
              Identifying Description (Color, Case, Stickers, Scratches)
            </label>
            <textarea
              required
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe visual characteristics that help campus staff identify the device..."
              className="w-full p-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#174C4A]">Additional Information (Optional)</label>
            <input
              type="text"
              value={additionalInfo}
              onChange={(e) => setAdditionalInfo(e.target.value)}
              placeholder="e.g., Handed over to security desk, lockscreen wallpaper hint, etc."
              className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15"
            />
          </div>

          {/* Image Upload */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-[#174C4A]">Device Photo (Optional)</label>
            {imageData ? (
              <div className="relative rounded-xl overflow-hidden border border-[#D8D0BE] bg-white flex items-center gap-4 p-3">
                <img
                  src={imageData}
                  alt="Device preview"
                  className="w-20 h-20 object-cover rounded-lg border border-[#E2DCCB]"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-[#174C4A]">Photo attached</p>
                  <p className="text-xs text-[#55615F] mt-0.5">
                    Optimized and ready to attach to your campus report.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setImageData(null)}
                  className="p-2 rounded-lg text-[#55615F] hover:text-[#D98252] hover:bg-[#F4F1E8] transition-colors cursor-pointer"
                  aria-label="Remove image"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-[#CBBFA8] hover:border-[#174C4A] bg-white px-4 py-6 cursor-pointer transition-colors">
                <Upload className="w-5 h-5 text-[#D98252]" />
                <span className="text-xs font-semibold text-[#174C4A]">Click to upload device image</span>
                <span className="text-[11px] text-[#55615F]">PNG, JPG or WebP — auto-optimized</span>
                <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
              </label>
            )}
          </div>

          {error && (
            <div
              role="alert"
              className="px-3.5 py-2.5 rounded-xl bg-[#D98252]/15 border border-[#D98252]/40 text-xs text-[#7A3A1B]"
            >
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full h-11 px-5 rounded-xl bg-[#174C4A] text-[#F4F1E8] font-semibold text-sm flex items-center justify-center gap-2 hover:bg-[#123D3B] disabled:opacity-60 transition-all shadow-sm cursor-pointer"
          >
            {submitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Submitting Report...</span>
              </>
            ) : (
              <span>{type === 'missing' ? 'Submit Lost Device Report' : 'Submit Found Device Report'}</span>
            )}
          </button>
        </div>

        {/* Right Column: Interactive Google Maps Campus Location Picker */}
        <div className="xl:col-span-5 space-y-4 rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 sm:p-6 shadow-xs flex flex-col">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#174C4A] flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#D98252]" />
              <span>
                {type === 'missing'
                  ? 'Last Known Campus Location (Optional)'
                  : 'Location Found on Campus (Optional)'}
              </span>
            </label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Select a zone below or click on the campus map"
              className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#D8D0BE] text-sm text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A] focus:ring-2 focus:ring-[#174C4A]/15"
            />
          </div>

          {/* Quick Campus Zone Selectors */}
          <div className="flex flex-wrap gap-1.5">
            {zones.map((z) => (
              <button
                key={z}
                type="button"
                onClick={() => setLocation(z)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  location === z
                    ? 'bg-[#D98252] text-white border border-[#D98252]'
                    : 'bg-white text-[#55615F] border border-[#DFD8C8] hover:border-[#174C4A] hover:text-[#174C4A]'
                }`}
              >
                {z}
              </button>
            ))}
          </div>

          <div className="flex-1 min-h-[300px] rounded-xl overflow-hidden border border-[#DFD8C8]">
            <CampusGoogleMap
              apiKey={mapsApiKey}
              college={college}
              items={[]}
              pickerMode
              selectedCoords={
                latitude !== null && longitude !== null ? { lat: latitude, lng: longitude } : null
              }
              onSelectLocation={({ lat, lng, label }) => {
                setLatitude(lat);
                setLongitude(lng);
                if (label) setLocation(label);
              }}
              heightClass="h-[320px]"
            />
          </div>

          <div className="flex items-center justify-between gap-2 text-xs text-[#55615F] pt-1">
            {latitude !== null && longitude !== null ? (
              <>
                <span className="font-mono-tabular text-[#174C4A] font-semibold">
                  Pinned: {latitude.toFixed(5)}, {longitude.toFixed(5)}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setLatitude(null);
                    setLongitude(null);
                  }}
                  className="text-xs font-semibold text-[#D98252] hover:underline cursor-pointer"
                >
                  Clear pin
                </button>
              </>
            ) : (
              <span>No map pin selected — click on the map to save the exact lost location.</span>
            )}
          </div>
        </div>
      </form>

      <CharacterConfirmModal
        open={confirmOpen}
        question="Are you sure you want to submit this report?"
        details={`This will publish your ${type === 'missing' ? 'lost' : 'found'} device report ("${
          title.trim() || [brand.trim(), model.trim(), deviceType].filter(Boolean).join(' ')
        }") to the ${college.code} Common Lost & Found registry.`}
        confirmLabel="YES"
        cancelLabel="NO"
        busy={submitting}
        onConfirm={handleConfirmedSubmit}
        onCancel={() => {
          if (!submitting) setConfirmOpen(false);
        }}
      />
    </div>
  );
}
