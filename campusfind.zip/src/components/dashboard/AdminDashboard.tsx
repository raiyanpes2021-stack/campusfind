import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react';
import {
  Activity,
  Building2,
  ChevronDown,
  ChevronUp,
  Clock,
  Download,
  FileSearch,
  LayoutDashboard,
  Lock,
  LogOut,
  MapPin,
  Menu,
  PackageCheck,
  Search,
  Trash2,
  User as UserIcon,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { campusApi, subscribeRealtime } from '../../lib/api';
import type {
  AuthUser,
  CampusItem,
  CollegeMember,
  CollegeSummary,
  DashboardStats,
  ItemLifecycleStatus,
  StudentActivityRecord,
} from '../../types/campusfind';

type AdminSection =
  | 'overview'
  | 'lost-reports'
  | 'found-reports'
  | 'student-details'
  | 'student-activity'
  | 'institution'
  | 'profile';

interface AdminDashboardProps {
  user: AuthUser;
  college: CollegeSummary;
  mapsApiKey?: string;
  onUserUpdated: (user: AuthUser) => void;
  onCollegeUpdated: (college: CollegeSummary) => void;
  onLogout: () => void;
}

const LIFECYCLE_OPTIONS: { value: ItemLifecycleStatus; label: string }[] = [
  { value: 'submitted', label: 'Submitted' },
  { value: 'under_review', label: 'Under Review' },
  { value: 'possible_match', label: 'Possible Match' },
  { value: 'verified', label: 'Verified' },
  { value: 'recovered', label: 'Recovered' },
  { value: 'closed', label: 'Closed' },
];

const ACTION_LABELS: Record<StudentActivityRecord['action_type'], string> = {
  login: 'Student Login',
  lost_report_submitted: 'Lost Report Submitted',
  found_report_submitted: 'Found Report Submitted',
  password_changed: 'Password Updated',
};

function formatTimestamp(iso: string | null | undefined): string {
  if (!iso) return 'Not recorded';
  const parsed = new Date(iso);
  if (Number.isNaN(parsed.getTime())) return iso;
  return parsed.toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function AdminDashboard({
  user,
  college,
  onUserUpdated,
  onCollegeUpdated,
  onLogout,
}: AdminDashboardProps) {
  const [section, setSection] = useState<AdminSection>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [items, setItems] = useState<CampusItem[]>([]);
  const [members, setMembers] = useState<CollegeMember[]>([]);
  const [activities, setActivities] = useState<StudentActivityRecord[]>([]);
  const [institutions, setInstitutions] = useState<CollegeSummary[]>([]);

  const [searchQuery, setSearchQuery] = useState('');
  const [studentSearch, setStudentSearch] = useState('');
  const [activitySearch, setActivitySearch] = useState('');
  const [expandedStudentId, setExpandedStudentId] = useState<number | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  // Authorize Student form state
  const [newStuName, setNewStuName] = useState('');
  const [newStuEmail, setNewStuEmail] = useState('');
  const [newStuId, setNewStuId] = useState('');
  const [newStuDept, setNewStuDept] = useState('');
  const [stuMsg, setStuMsg] = useState<string | null>(null);
  const [stuErr, setStuErr] = useState<string | null>(null);

  // MSAJCE-only Institution settings form state
  const [instName, setInstName] = useState(college.name);
  const [instAdminEmail, setInstAdminEmail] = useState(college.adminEmail || `admin@${college.domain}`);
  const [instInitialPassword, setInstInitialPassword] = useState('');
  const [instAddress, setInstAddress] = useState(college.address || '');
  const [instMapsUrl, setInstMapsUrl] = useState(college.mapsUrl || '');
  const [instZonesText, setInstZonesText] = useState((college.zones || []).join('\n'));
  const [instSaved, setInstSaved] = useState<string | null>(null);
  const [instError, setInstError] = useState<string | null>(null);

  // Profile state
  const [profileName, setProfileName] = useState(user.fullName);
  const [profileDept, setProfileDept] = useState(user.department);
  const [profileSaved, setProfileSaved] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => {
      setToast((curr) => (curr === msg ? null : curr));
    }, 4000);
  }, []);

  const refreshData = useCallback(async () => {
    try {
      const [sumRes, itemRes, memberRes, activityRes, instRes] = await Promise.all([
        campusApi.getSummary(),
        campusApi.getItems(),
        campusApi.getAdminMembers(),
        campusApi.getAdminActivity(),
        campusApi.getAdminInstitutions(),
      ]);
      setStats(sumRes.stats);
      setItems(itemRes.items);
      setMembers(memberRes.members);
      setActivities(activityRes.activities);
      setInstitutions(instRes.institutions);
    } catch {
      // Retain last valid database snapshot on transient error
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  useEffect(() => {
    const unsubscribe = subscribeRealtime((msg) => {
      if (msg.event === 'connected') return;
      refreshData();
    });
    return unsubscribe;
  }, [refreshData]);

  const lostItems = useMemo(() => items.filter((i) => i.type === 'missing'), [items]);
  const foundItems = useMemo(() => items.filter((i) => i.type === 'found'), [items]);

  const itemsByStudent = useMemo(() => {
    const map = new Map<number, CampusItem[]>();
    for (const item of items) {
      const existing = map.get(item.reporter_user_id) || [];
      existing.push(item);
      map.set(item.reporter_user_id, existing);
    }
    return map;
  }, [items]);

  const filterReports = useCallback(
    (list: CampusItem[]) => {
      const q = searchQuery.trim().toLowerCase();
      if (!q) return list;
      return list.filter(
        (i) =>
          i.title.toLowerCase().includes(q) ||
          (i.location || '').toLowerCase().includes(q) ||
          (i.device_type || '').toLowerCase().includes(q) ||
          (i.reporter_identifier || '').toLowerCase().includes(q) ||
          (i.reporter_name || '').toLowerCase().includes(q) ||
          (i.report_code || '').toLowerCase().includes(q)
      );
    },
    [searchQuery]
  );

  const filteredMembers = useMemo(() => {
    const q = studentSearch.trim().toLowerCase();
    if (!q) return members;
    return members.filter(
      (m) =>
        m.identifier.toLowerCase().includes(q) ||
        m.full_name.toLowerCase().includes(q) ||
        (m.student_id || '').toLowerCase().includes(q) ||
        (m.department || '').toLowerCase().includes(q)
    );
  }, [members, studentSearch]);

  const filteredActivities = useMemo(() => {
    const q = activitySearch.trim().toLowerCase();
    if (!q) return activities;
    return activities.filter(
      (a) =>
        a.student_email.toLowerCase().includes(q) ||
        (a.student_name || '').toLowerCase().includes(q) ||
        a.summary.toLowerCase().includes(q) ||
        ACTION_LABELS[a.action_type].toLowerCase().includes(q)
    );
  }, [activities, activitySearch]);

  const handleLifecycleChange = async (id: number, lifecycle: ItemLifecycleStatus) => {
    try {
      await campusApi.updateItemLifecycle(id, lifecycle);
      refreshData();
      showToast(`Report status updated to ${lifecycle.replace('_', ' ')}.`);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Status update failed.');
    }
  };

  const handleAuthorizeStudent = async (e: FormEvent) => {
    e.preventDefault();
    setStuMsg(null);
    setStuErr(null);
    try {
      const res = await campusApi.createAuthorizedStudent({
        fullName: newStuName.trim(),
        email: newStuEmail.trim(),
        studentId: newStuId.trim() || undefined,
        department: newStuDept.trim() || undefined,
      });
      setStuMsg(`Authorized ${res.member.full_name} (${res.member.identifier}).`);
      setNewStuName('');
      setNewStuEmail('');
      setNewStuId('');
      setNewStuDept('');
      refreshData();
    } catch (err) {
      setStuErr(err instanceof Error ? err.message : 'Unable to authorize student.');
    }
  };

  const handleInstitutionSave = async (e: FormEvent) => {
    e.preventDefault();
    setInstSaved(null);
    setInstError(null);
    try {
      const zones = instZonesText
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean);
      const res = await campusApi.updateInstitutionById(college.id, {
        name: instName.trim(),
        domain: college.domain,
        adminEmail: instAdminEmail.trim(),
        initialStudentPassword: instInitialPassword.trim() || undefined,
        studentAccessEnabled: true,
        address: instAddress.trim(),
        mapsUrl: instMapsUrl.trim(),
        zones,
      });
      onCollegeUpdated(res.institution);
      setInstInitialPassword('');
      setInstSaved('MSAJCE institutional configuration updated.');
      refreshData();
    } catch (err) {
      setInstError(err instanceof Error ? err.message : 'Failed to update institution.');
    }
  };

  const handleProfileSave = async (e: FormEvent) => {
    e.preventDefault();
    setProfileSaved(null);
    try {
      const res = await campusApi.updateProfile({
        fullName: profileName.trim(),
        department: profileDept.trim(),
      });
      onUserUpdated(res.user);
      setProfileSaved('Administrator profile updated.');
    } catch (err) {
      setProfileSaved(err instanceof Error ? err.message : 'Update failed.');
    }
  };

  const primaryNavItems: {
    id: AdminSection;
    label: string;
    icon: typeof LayoutDashboard;
    count?: number;
  }[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'lost-reports', label: 'Lost Reports', icon: FileSearch, count: lostItems.length },
    { id: 'found-reports', label: 'Found Reports', icon: PackageCheck, count: foundItems.length },
    { id: 'student-details', label: 'Student Details', icon: Users, count: members.length },
  ];

  const utilityNavItems: {
    id: AdminSection;
    label: string;
    icon: typeof LayoutDashboard;
  }[] = [];

  const selectSection = (next: AdminSection) => {
    setSection(next);
    setMobileMenuOpen(false);
  };

  const renderReportsSection = (list: CampusItem[], heading: string, kind: 'lost' | 'found') => {
    const filtered = filterReports(list);
    return (
      <div className="space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#DFD8C8] pb-4">
          <div>
            <h1 className="font-display text-2xl font-bold text-[#174C4A]">{heading}</h1>
            <p className="text-sm text-[#55615F] mt-0.5">
              Genuine student-submitted {kind} device reports recorded for {college.name}.
            </p>
          </div>
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-[#55615F] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search ID, email, device, location..."
              className="w-full h-10 pl-9 pr-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A]"
            />
          </div>
        </div>

        <div className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] overflow-x-auto shadow-xs">
          {filtered.length === 0 ? (
            <div className="p-12 text-center space-y-1.5">
              <p className="text-sm font-semibold text-[#174C4A]">
                No {kind} device reports recorded
              </p>
              <p className="text-xs text-[#55615F]">
                Reports will appear here automatically once an authorized student submits one.
              </p>
            </div>
          ) : (
            <table className="w-full text-left border-collapse min-w-[860px]">
              <thead>
                <tr className="border-b border-[#E2DCCB] text-[11px] uppercase tracking-wider text-[#55615F] bg-[#F4F1E8]/70">
                  <th className="py-3.5 px-4">Report ID</th>
                  <th className="py-3.5 px-4">Device &amp; Description</th>
                  <th className="py-3.5 px-4">Student Email</th>
                  <th className="py-3.5 px-4">Location &amp; Submitted Date</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E6E0D0] text-xs">
                {filtered.map((item) => (
                  <tr key={item.id} className="hover:bg-white/70 transition-colors align-top">
                    <td className="py-3.5 px-4 font-mono-tabular text-[#174C4A] font-semibold whitespace-nowrap">
                      {item.report_code || `CF-${item.id}`}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="flex items-start gap-3">
                        {item.image_data ? (
                          <img
                            src={item.image_data}
                            alt={item.title}
                            className="w-12 h-12 rounded-lg object-cover border border-[#DFD8C8] shrink-0"
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-lg bg-white border border-[#E2DCCB] flex items-center justify-center text-[10px] font-medium text-[#55615F] shrink-0">
                            No photo
                          </div>
                        )}
                        <div className="min-w-0 max-w-[280px] space-y-0.5">
                          <p className="font-semibold text-[#1C2524]">{item.title}</p>
                          <p className="text-[11px] text-[#174C4A] font-medium">
                            {item.device_type || item.category}
                            {item.brand ? ` · ${item.brand}` : ''}
                            {item.model ? ` ${item.model}` : ''}
                          </p>
                          {item.description ? (
                            <p className="text-[11px] text-[#55615F] line-clamp-2">
                              {item.description}
                            </p>
                          ) : null}
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <p className="text-[#1C2524] font-medium">{item.reporter_identifier}</p>
                      {item.reporter_name && (
                        <p className="text-[11px] text-[#55615F]">{item.reporter_name}</p>
                      )}
                    </td>
                    <td className="py-3.5 px-4 space-y-0.5">
                      {item.location ? (
                        <p className="text-[#1C2524] flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-[#D98252] shrink-0" />
                          <span>{item.location}</span>
                        </p>
                      ) : (
                        <p className="text-[11px] text-[#7A8583] italic">Location not provided</p>
                      )}
                      <p className="text-[11px] text-[#55615F] font-mono-tabular">
                        {item.reported_date || formatTimestamp(item.created_at)}
                        {item.reported_time ? ` · ${item.reported_time}` : ''}
                      </p>
                    </td>
                    <td className="py-3.5 px-4">
                      <select
                        value={item.lifecycle_status || 'submitted'}
                        onChange={(e) =>
                          handleLifecycleChange(item.id, e.target.value as ItemLifecycleStatus)
                        }
                        className="h-8 px-2.5 rounded-lg bg-white border border-[#D8D0BE] text-xs font-medium text-[#174C4A] focus:outline-none focus:border-[#174C4A]"
                      >
                        {LIFECYCLE_OPTIONS.map((opt) => (
                          <option key={opt.value} value={opt.value} className="bg-white">
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        type="button"
                        onClick={async () => {
                          await campusApi.deleteItem(item.id);
                          refreshData();
                          showToast('Report removed.');
                        }}
                        className="p-1.5 rounded-lg text-[#55615F] hover:text-[#D98252] hover:bg-[#D98252]/10 cursor-pointer"
                        aria-label="Delete report"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen w-full bg-[#F4F1E8] text-[#1C2524] flex">
      {/* Desktop Sidebar — Deep Teal (#174C4A) */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col bg-[#174C4A] text-[#F4F1E8] shrink-0">
        <div className="px-5 py-5 border-b border-white/10 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#F4F1E8] flex items-center justify-center shrink-0">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <circle cx="11" cy="11" r="6.5" stroke="#174C4A" strokeWidth="2.1" />
              <circle cx="11" cy="11" r="2.2" fill="#D98252" />
              <path
                d="M16.2 16.2L20.5 20.5"
                stroke="#D98252"
                strokeWidth="2.2"
                strokeLinecap="round"
              />
            </svg>
          </div>
          <div className="min-w-0">
            <p className="font-display text-base font-bold text-[#F4F1E8] leading-tight">
              CampusFind
            </p>
            <p className="text-[11px] text-[#D98252] font-semibold truncate">
              Admin Console · {college.code}
            </p>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          <p className="px-3 pb-1 text-[10px] font-semibold uppercase tracking-wider text-[#F4F1E8]/50">
            Management
          </p>
          {primaryNavItems.map((item) => {
            const Icon = item.icon;
            const active = section === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => selectSection(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
                  active
                    ? 'bg-[#D98252] text-white shadow-xs'
                    : 'text-[#F4F1E8]/85 hover:bg-white/10 hover:text-white'
                }`}
              >
                <span className="flex items-center gap-2.5 truncate">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </span>
                {item.count !== undefined && (
                  <span
                    className={`font-mono-tabular text-[11px] font-bold px-1.5 py-0.5 rounded-md ${
                      active ? 'bg-white/20 text-white' : 'bg-white/10 text-[#F4F1E8]'
                    }`}
                  >
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}

          {utilityNavItems.length > 0 && (
            <div className="pt-4 mt-4 border-t border-white/10 space-y-1">
              <p className="px-3 pb-1 text-[10px] font-semibold uppercase tracking-wider text-[#F4F1E8]/50">
                Settings
              </p>
              {utilityNavItems.map((item) => {
                const Icon = item.icon;
                const active = section === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => selectSection(item.id)}
                    className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#D98252] text-white shadow-xs'
                        : 'text-[#F4F1E8]/85 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          )}
        </nav>

        <div className="p-3 border-t border-white/10">
          <div className="px-3 py-2 mb-2">
            <p className="text-xs font-semibold text-[#F4F1E8] truncate">{user.fullName}</p>
            <p className="text-[11px] text-[#F4F1E8]/70 truncate">{user.identifier}</p>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium text-[#F4F1E8]/85 hover:text-white hover:bg-[#D98252]/25 transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-[#1C2524]/50"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative w-72 max-w-[85vw] bg-[#174C4A] text-[#F4F1E8] flex flex-col z-10">
            <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between">
              <span className="font-display text-lg font-bold text-[#F4F1E8]">Admin Console</span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-1.5 text-[#F4F1E8]/80"
                aria-label="Close admin menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
              {[...primaryNavItems, ...utilityNavItems].map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => selectSection(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium ${
                      section === item.id ? 'bg-[#D98252] text-white' : 'text-[#F4F1E8]/85'
                    }`}
                  >
                    <span className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </span>
                    {'count' in item && typeof item.count === 'number' && (
                      <span className="font-mono-tabular text-xs font-bold">{item.count}</span>
                    )}
                  </button>
                );
              })}
            </nav>
            <div className="p-3 border-t border-white/10">
              <button
                type="button"
                onClick={onLogout}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm text-[#F4F1E8]"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-30 h-16 px-4 sm:px-8 border-b border-[#DFD8C8] bg-[#FAF8F3]/95 backdrop-blur flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 rounded-lg text-[#174C4A] hover:bg-[#EDE8DC]"
              aria-label="Open admin menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-[#174C4A] truncate">{college.name}</p>
              <p className="text-xs text-[#55615F] truncate">
                {user.fullName} · {user.department}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => campusApi.exportReportsCsv().catch(() => showToast('Export failed.'))}
              className="h-9 px-3.5 rounded-lg bg-white border border-[#D8D0BE] text-xs font-semibold text-[#174C4A] inline-flex items-center gap-1.5 hover:border-[#D98252] cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-[#D98252]" />
              <span>Export CSV</span>
            </button>
          </div>
        </header>

        {toast && (
          <div className="fixed bottom-5 right-5 z-50 max-w-sm rounded-xl bg-[#174C4A] text-[#F4F1E8] border border-[#D98252]/50 px-4 py-3 shadow-xl text-xs">
            {toast}
          </div>
        )}

        <main className="flex-1 p-4 sm:p-8 max-w-[1400px] w-full mx-auto">
          {/* 1. OVERVIEW */}
          {section === 'overview' && (
            <div className="space-y-8">
              <div className="border-b border-[#DFD8C8] pb-5">
                <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#174C4A] tracking-tight">
                  Administrator Overview
                </h1>
                <p className="mt-1 text-sm text-[#55615F]">
                  Live database summary for {college.name}. All counts reflect genuine stored records only.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <button
                  type="button"
                  onClick={() => selectSection('student-details')}
                  className="text-left rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] hover:border-[#174C4A]/40 p-5 shadow-xs transition-colors cursor-pointer"
                >
                  <p className="text-xs font-medium text-[#55615F]">Total Students</p>
                  <p className="mt-2 font-mono-tabular text-3xl font-bold text-[#D98252]">
                    {stats?.registeredStudents ?? members.length}
                  </p>
                </button>
                <button
                  type="button"
                  onClick={() => selectSection('lost-reports')}
                  className="text-left rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] hover:border-[#174C4A]/40 p-5 shadow-xs transition-colors cursor-pointer"
                >
                  <p className="text-xs font-medium text-[#55615F]">Total Lost Reports</p>
                  <p className="mt-2 font-mono-tabular text-3xl font-bold text-[#174C4A]">
                    {stats?.missingTotal ?? lostItems.length}
                  </p>
                </button>
                <button
                  type="button"
                  onClick={() => selectSection('found-reports')}
                  className="text-left rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] hover:border-[#174C4A]/40 p-5 shadow-xs transition-colors cursor-pointer"
                >
                  <p className="text-xs font-medium text-[#55615F]">Total Found Reports</p>
                  <p className="mt-2 font-mono-tabular text-3xl font-bold text-[#174C4A]">
                    {stats?.foundTotal ?? foundItems.length}
                  </p>
                </button>
                <div className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 shadow-xs">
                  <p className="text-xs font-medium text-[#55615F]">Recovered Devices</p>
                  <p className="mt-2 font-mono-tabular text-3xl font-bold text-[#174C4A]">
                    {stats?.resolvedItems ?? 0}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Recent Lost & Found Reports */}
                <div className="lg:col-span-7 rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 sm:p-6 shadow-xs">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="font-display text-lg font-bold text-[#174C4A]">
                      Recent Lost &amp; Found Reports
                    </h2>
                    <button
                      type="button"
                      onClick={() => selectSection('lost-reports')}
                      className="text-xs font-semibold text-[#D98252] hover:underline cursor-pointer"
                    >
                      View all reports
                    </button>
                  </div>
                  {items.length === 0 ? (
                    <div className="py-10 text-center space-y-1">
                      <p className="text-sm font-medium text-[#174C4A]">
                        No device reports submitted yet
                      </p>
                      <p className="text-xs text-[#55615F]">
                        Student-submitted lost and found reports will appear here in real time.
                      </p>
                    </div>
                  ) : (
                    <div className="divide-y divide-[#E6E0D0]">
                      {items.slice(0, 6).map((item) => (
                        <div key={item.id} className="py-3.5 flex items-center justify-between gap-4">
                          <div className="min-w-0">
                            <p className="text-xs text-[#55615F] font-mono-tabular">
                              {item.report_code || `CF-${item.id}`} ·{' '}
                              <span
                                className={
                                  item.type === 'missing'
                                    ? 'text-[#D98252] font-semibold'
                                    : 'text-[#174C4A] font-semibold'
                                }
                              >
                                {item.type === 'missing' ? 'Lost' : 'Found'}
                              </span>
                            </p>
                            <p className="text-sm font-semibold text-[#1C2524] truncate">
                              {item.title}
                            </p>
                            <p className="text-xs text-[#55615F] truncate">
                              {item.reporter_identifier}
                              {item.location ? ` · ${item.location}` : ''}
                            </p>
                          </div>
                          <span className="text-[11px] font-medium px-2.5 py-1 rounded-lg bg-white border border-[#E2DCCB] text-[#174C4A] capitalize shrink-0">
                            {(item.lifecycle_status || 'submitted').replace('_', ' ')}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Recent Student Login & Activity */}
                <div className="lg:col-span-5 rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 sm:p-6 shadow-xs">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="font-display text-lg font-bold text-[#174C4A]">
                      Recent Student Activity
                    </h2>
                    <button
                      type="button"
                      onClick={() => selectSection('student-activity')}
                      className="text-xs font-semibold text-[#D98252] hover:underline cursor-pointer"
                    >
                      View activity log
                    </button>
                  </div>
                  {activities.length === 0 ? (
                    <div className="py-10 text-center space-y-1">
                      <p className="text-sm font-medium text-[#174C4A]">
                        No student activity recorded yet
                      </p>
                      <p className="text-xs text-[#55615F]">
                        Student logins and report submissions will appear here when they occur.
                      </p>
                    </div>
                  ) : (
                    <div className="divide-y divide-[#E6E0D0]">
                      {activities.slice(0, 6).map((act) => (
                        <div key={act.id} className="py-3 space-y-0.5">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-semibold text-[#174C4A]">
                              {ACTION_LABELS[act.action_type]}
                            </span>
                            <span className="text-[11px] text-[#55615F] font-mono-tabular shrink-0">
                              {formatTimestamp(act.created_at)}
                            </span>
                          </div>
                          <p className="text-xs text-[#1C2524] truncate">{act.student_email}</p>
                          <p className="text-[11px] text-[#55615F] truncate">{act.summary}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 2. LOST REPORTS */}
          {section === 'lost-reports' && renderReportsSection(lostItems, 'Lost Reports', 'lost')}

          {/* 3. FOUND REPORTS */}
          {section === 'found-reports' && renderReportsSection(foundItems, 'Found Reports', 'found')}

          {/* 4. STUDENT DETAILS */}
          {section === 'student-details' && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#DFD8C8] pb-4">
                <div>
                  <h1 className="font-display text-2xl font-bold text-[#174C4A]">
                    Student Details
                  </h1>
                  <p className="text-sm text-[#55615F] mt-0.5">
                    Genuine registered student records and report history for {college.name}.
                  </p>
                </div>
                <div className="relative w-full sm:w-72">
                  <Search className="w-4 h-4 text-[#55615F] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={studentSearch}
                    onChange={(e) => setStudentSearch(e.target.value)}
                    placeholder="Search student email, name, dept..."
                    className="w-full h-10 pl-9 pr-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A]"
                  />
                </div>
              </div>

              {/* Pre-authorize Student Account */}
              <form
                onSubmit={handleAuthorizeStudent}
                className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 space-y-4 shadow-xs"
              >
                <h2 className="font-display text-base font-bold text-[#174C4A] flex items-center gap-2">
                  <UserPlus className="w-4 h-4 text-[#D98252]" />
                  <span>Add Authorized Student Account (@{college.domain})</span>
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <input
                    type="text"
                    required
                    value={newStuName}
                    onChange={(e) => setNewStuName(e.target.value)}
                    placeholder="Full Name"
                    className="h-10 px-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                  />
                  <input
                    type="email"
                    required
                    value={newStuEmail}
                    onChange={(e) => setNewStuEmail(e.target.value)}
                    placeholder={`username@${college.domain}`}
                    className="h-10 px-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                  />
                  <input
                    type="text"
                    value={newStuId}
                    onChange={(e) => setNewStuId(e.target.value)}
                    placeholder="Student ID (optional)"
                    className="h-10 px-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                  />
                  <input
                    type="text"
                    value={newStuDept}
                    onChange={(e) => setNewStuDept(e.target.value)}
                    placeholder="Department (optional)"
                    className="h-10 px-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524] focus:outline-none focus:border-[#174C4A]"
                  />
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    type="submit"
                    className="h-9 px-4 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold hover:bg-[#123D3B] cursor-pointer"
                  >
                    Authorize Student
                  </button>
                  {stuMsg && <span className="text-xs text-[#174C4A] font-medium">{stuMsg}</span>}
                  {stuErr && <span className="text-xs text-[#9E4720] font-medium">{stuErr}</span>}
                </div>
              </form>

              {/* Student Table */}
              <div className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] overflow-x-auto shadow-xs">
                {filteredMembers.length === 0 ? (
                  <div className="p-12 text-center space-y-1">
                    <p className="text-sm font-semibold text-[#174C4A]">
                      No student records found
                    </p>
                    <p className="text-xs text-[#55615F]">
                      Students appear here after they are authorized or sign in with their @{college.domain} email.
                    </p>
                  </div>
                ) : (
                  <table className="w-full text-left border-collapse min-w-[760px]">
                    <thead>
                      <tr className="border-b border-[#E2DCCB] text-[11px] uppercase tracking-wider text-[#55615F] bg-[#F4F1E8]/70">
                        <th className="py-3.5 px-4">Student Email</th>
                        <th className="py-3.5 px-4">Institution</th>
                        <th className="py-3.5 px-4">Account Status</th>
                        <th className="py-3.5 px-4">Registered On</th>
                        <th className="py-3.5 px-4">Reports</th>
                        <th className="py-3.5 px-4 text-right">Access</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#E6E0D0] text-xs">
                      {filteredMembers.map((m) => {
                        const studentReports = itemsByStudent.get(m.id) || [];
                        const isExpanded = expandedStudentId === m.id;
                        return (
                          <>
                            <tr key={m.id} className="hover:bg-white/70 transition-colors">
                              <td className="py-3.5 px-4">
                                <p className="font-semibold text-[#1C2524]">{m.identifier}</p>
                                <p className="text-[11px] text-[#55615F]">
                                  {m.full_name}
                                  {m.department ? ` · ${m.department}` : ''}
                                  {m.academic_year ? ` · ${m.academic_year}` : ''}
                                </p>
                              </td>
                              <td className="py-3.5 px-4 text-[#1C2524] font-medium">
                                {college.code}
                              </td>
                              <td className="py-3.5 px-4">
                                <span
                                  className={`inline-flex px-2.5 py-0.5 rounded-lg text-[11px] font-semibold ${
                                    m.is_authorized
                                      ? 'bg-[#174C4A]/12 text-[#174C4A]'
                                      : 'bg-[#D98252]/18 text-[#8C3B16]'
                                  }`}
                                >
                                  {m.is_authorized ? 'Active' : 'Paused'}
                                </span>
                              </td>
                              <td className="py-3.5 px-4 font-mono-tabular text-[#55615F]">
                                {formatTimestamp(m.created_at)}
                              </td>
                              <td className="py-3.5 px-4">
                                <button
                                  type="button"
                                  onClick={() =>
                                    setExpandedStudentId(isExpanded ? null : m.id)
                                  }
                                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#174C4A] hover:text-[#D98252] cursor-pointer"
                                >
                                  <span className="font-mono-tabular">{studentReports.length}</span>
                                  <span>{studentReports.length === 1 ? 'report' : 'reports'}</span>
                                  {isExpanded ? (
                                    <ChevronUp className="w-3.5 h-3.5" />
                                  ) : (
                                    <ChevronDown className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              </td>
                              <td className="py-3.5 px-4 text-right">
                                <button
                                  type="button"
                                  onClick={async () => {
                                    await campusApi.updateStudentAccess(m.id, {
                                      isAuthorized: !m.is_authorized,
                                    });
                                    refreshData();
                                    showToast(
                                      m.is_authorized
                                        ? `Paused access for ${m.identifier}.`
                                        : `Restored access for ${m.identifier}.`
                                    );
                                  }}
                                  className="h-8 px-3 rounded-lg bg-white border border-[#D8D0BE] text-xs font-semibold text-[#174C4A] hover:border-[#D98252] cursor-pointer"
                                >
                                  {m.is_authorized ? 'Pause' : 'Enable'}
                                </button>
                              </td>
                            </tr>
                            {isExpanded && (
                              <tr key={`${m.id}-history`} className="bg-white/80">
                                <td colSpan={6} className="px-6 py-4">
                                  <p className="text-[11px] font-semibold uppercase tracking-wider text-[#174C4A] mb-2">
                                    Report History — {m.identifier}
                                  </p>
                                  {studentReports.length === 0 ? (
                                    <p className="text-xs text-[#55615F]">
                                      No lost or found reports submitted by this student.
                                    </p>
                                  ) : (
                                    <div className="space-y-2">
                                      {studentReports.map((rep) => (
                                        <div
                                          key={rep.id}
                                          className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-[#FAF8F3] border border-[#E2DCCB] px-3.5 py-2.5 text-xs"
                                        >
                                          <div>
                                            <span className="font-mono-tabular font-semibold text-[#174C4A] mr-2">
                                              {rep.report_code || `CF-${rep.id}`}
                                            </span>
                                            <span className="font-semibold text-[#1C2524]">
                                              {rep.title}
                                            </span>
                                            <span className="text-[#55615F] ml-2">
                                              ({rep.type === 'missing' ? 'Lost' : 'Found'} ·{' '}
                                              {rep.device_type})
                                            </span>
                                          </div>
                                          <div className="text-[11px] text-[#55615F] font-mono-tabular">
                                            {rep.location ? `${rep.location} · ` : ''}
                                            {rep.reported_date || formatTimestamp(rep.created_at)}
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </td>
                              </tr>
                            )}
                          </>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          )}

          {/* 5. STUDENT LOGIN & ACTIVITY */}
          {section === 'student-activity' && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#DFD8C8] pb-4">
                <div>
                  <h1 className="font-display text-2xl font-bold text-[#174C4A]">
                    Student Login &amp; Activity
                  </h1>
                  <p className="text-sm text-[#55615F] mt-0.5">
                    Genuine backend-recorded student logins, report submissions, and password updates for {college.name}.
                  </p>
                </div>
                <div className="relative w-full sm:w-72">
                  <Search className="w-4 h-4 text-[#55615F] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={activitySearch}
                    onChange={(e) => setActivitySearch(e.target.value)}
                    placeholder="Filter by email or action..."
                    className="w-full h-10 pl-9 pr-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524] placeholder:text-[#8E9694] focus:outline-none focus:border-[#174C4A]"
                  />
                </div>
              </div>

              <div className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] overflow-x-auto shadow-xs">
                {filteredActivities.length === 0 ? (
                  <div className="p-12 text-center space-y-1.5">
                    <Clock className="w-6 h-6 text-[#D98252] mx-auto" />
                    <p className="text-sm font-semibold text-[#174C4A]">
                      No student activity recorded yet
                    </p>
                    <p className="text-xs text-[#55615F]">
                      Activity entries are written automatically only when a student logs in, submits a report, or updates their password.
                    </p>
                  </div>
                ) : (
                  <table className="w-full text-left border-collapse min-w-[740px]">
                    <thead>
                      <tr className="border-b border-[#E2DCCB] text-[11px] uppercase tracking-wider text-[#55615F] bg-[#F4F1E8]/70">
                        <th className="py-3.5 px-4">Timestamp</th>
                        <th className="py-3.5 px-4">Student Email</th>
                        <th className="py-3.5 px-4">Action</th>
                        <th className="py-3.5 px-4">Details</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#E6E0D0] text-xs">
                      {filteredActivities.map((act) => (
                        <tr key={act.id} className="hover:bg-white/70 transition-colors">
                          <td className="py-3.5 px-4 font-mono-tabular text-[#55615F] whitespace-nowrap">
                            {formatTimestamp(act.created_at)}
                          </td>
                          <td className="py-3.5 px-4">
                            <p className="font-semibold text-[#1C2524]">{act.student_email}</p>
                            {act.student_name && (
                              <p className="text-[11px] text-[#55615F]">{act.student_name}</p>
                            )}
                          </td>
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <span
                              className={`inline-flex px-2.5 py-0.5 rounded-lg text-[11px] font-semibold ${
                                act.action_type === 'lost_report_submitted'
                                  ? 'bg-[#D98252]/18 text-[#8C3B16]'
                                  : 'bg-[#174C4A]/12 text-[#174C4A]'
                              }`}
                            >
                              {ACTION_LABELS[act.action_type]}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-[#1C2524]">{act.summary}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          )}

          {/* INSTITUTION STATUS — MSAJCE ONLY ACTIVE */}
          {section === 'institution' && (
            <div className="space-y-6">
              <div className="border-b border-[#DFD8C8] pb-4">
                <h1 className="font-display text-2xl font-bold text-[#174C4A]">
                  Institution Status
                </h1>
                <p className="text-sm text-[#55615F] mt-0.5">
                  CampusFind is locked to MSAJCE as the sole active institution. Other institution records are preserved in a disabled state.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-5 rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 space-y-3 shadow-xs">
                  <h2 className="font-display text-base font-bold text-[#174C4A]">
                    Institutions Directory
                  </h2>
                  <div className="space-y-2.5">
                    {institutions.map((inst) => {
                      const isActive = inst.code === 'MSAJCE' && inst.studentAccessEnabled !== false;
                      return (
                        <div
                          key={inst.id}
                          className={`rounded-xl p-3.5 border ${
                            isActive
                              ? 'bg-white border-[#174C4A]/35'
                              : 'bg-[#F4F1E8]/60 border-[#E2DCCB] opacity-75'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <p className="text-xs font-bold text-[#174C4A]">{inst.code}</p>
                            {isActive ? (
                              <span className="px-2 py-0.5 rounded-md bg-[#174C4A] text-[#F4F1E8] text-[10px] font-semibold">
                                Active
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#D98252]/18 text-[#8C3B16] text-[10px] font-semibold">
                                <Lock className="w-3 h-3" />
                                <span>Disabled</span>
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-[#1C2524] font-medium mt-1">{inst.name}</p>
                          <p className="text-[11px] text-[#55615F] mt-0.5">@{inst.domain}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <form
                  onSubmit={handleInstitutionSave}
                  className="lg:col-span-7 rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-5 sm:p-6 space-y-4 shadow-xs"
                >
                  <h2 className="font-display text-base font-bold text-[#174C4A]">
                    MSAJCE Configuration
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-[#174C4A]">
                        Institution Name
                      </label>
                      <input
                        type="text"
                        required
                        value={instName}
                        onChange={(e) => setInstName(e.target.value)}
                        className="w-full h-10 px-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524]"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-[#174C4A]">
                        Authorized Email Domain
                      </label>
                      <input
                        type="text"
                        disabled
                        value={`@${college.domain}`}
                        className="w-full h-10 px-3 rounded-xl bg-[#EFECE3] border border-[#D8D0BE] text-xs text-[#55615F]"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-[#174C4A]">
                        Administrator Email
                      </label>
                      <input
                        type="email"
                        required
                        value={instAdminEmail}
                        onChange={(e) => setInstAdminEmail(e.target.value)}
                        className="w-full h-10 px-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524]"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-[#174C4A]">
                        Update Initial Common Student Password
                      </label>
                      <input
                        type="password"
                        value={instInitialPassword}
                        onChange={(e) => setInstInitialPassword(e.target.value)}
                        placeholder="Leave blank to keep existing"
                        className="w-full h-10 px-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524]"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-[#174C4A]">Campus Address</label>
                    <input
                      type="text"
                      value={instAddress}
                      onChange={(e) => setInstAddress(e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-[#174C4A]">
                      Campus Zones (one per line)
                    </label>
                    <textarea
                      rows={4}
                      value={instZonesText}
                      onChange={(e) => setInstZonesText(e.target.value)}
                      className="w-full p-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524]"
                    />
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      type="submit"
                      className="h-10 px-5 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold hover:bg-[#123D3B] cursor-pointer"
                    >
                      Save MSAJCE Settings
                    </button>
                    {instSaved && (
                      <span className="text-xs font-medium text-[#174C4A]">{instSaved}</span>
                    )}
                    {instError && (
                      <span className="text-xs font-medium text-[#9E4720]">{instError}</span>
                    )}
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* PROFILE */}
          {section === 'profile' && (
            <div className="max-w-xl space-y-6">
              <div className="border-b border-[#DFD8C8] pb-4">
                <h1 className="font-display text-2xl font-bold text-[#174C4A]">
                  Administrator Profile
                </h1>
                <p className="text-sm text-[#55615F] mt-0.5">
                  Manage your display name and department details.
                </p>
              </div>

              <form
                onSubmit={handleProfileSave}
                className="rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] p-6 space-y-4 shadow-xs"
              >
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-[#174C4A]">Email ID</label>
                  <input
                    type="text"
                    disabled
                    value={user.identifier}
                    className="w-full h-10 px-3 rounded-xl bg-[#EFECE3] border border-[#D8D0BE] text-xs text-[#55615F]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-[#174C4A]">Full Name</label>
                  <input
                    type="text"
                    required
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-[#174C4A]">Department</label>
                  <input
                    type="text"
                    required
                    value={profileDept}
                    onChange={(e) => setProfileDept(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl bg-white border border-[#D8D0BE] text-xs text-[#1C2524]"
                  />
                </div>
                <div className="flex items-center gap-3 pt-1">
                  <button
                    type="submit"
                    className="h-10 px-5 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold hover:bg-[#123D3B] cursor-pointer"
                  >
                    Save Profile
                  </button>
                  {profileSaved && (
                    <span className="text-xs font-medium text-[#174C4A]">{profileSaved}</span>
                  )}
                </div>
              </form>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
