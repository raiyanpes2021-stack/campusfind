import * as THREE from 'three';

export interface WhiteEnvironmentRig {
  group: THREE.Group;
  updateCorridorReveal: (corridorReveal: number, focusWarmth: number) => void;
  dispose: () => void;
}

const PURE_WHITE = new THREE.Color('#ffffff');
const WARM_IVORY_BG = new THREE.Color('#f4f1e8');
const CORRIDOR_WALL = new THREE.Color('#efeae0');
const CORRIDOR_FLOOR = new THREE.Color('#f7f4ec');
const DEEP_TEAL = new THREE.Color('#174c4a');
const TERRACOTTA = new THREE.Color('#d98252');
const _tmpColor = new THREE.Color();

function createCorridorFloorTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#f9f7f1';
  ctx.fillRect(0, 0, size, size);

  // Subtle terrazzo / architectural stone grain
  for (let i = 0; i < 4800; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const alpha = 0.015 + Math.random() * 0.02;
    ctx.fillStyle = Math.random() > 0.5 ? `rgba(23, 76, 74, ${alpha})` : `rgba(217, 130, 82, ${alpha * 0.8})`;
    ctx.fillRect(x, y, 2, 2);
  }

  // Clean corridor tile joints
  ctx.strokeStyle = 'rgba(23, 76, 74, 0.08)';
  ctx.lineWidth = 1.2;
  ctx.strokeRect(0.5, 0.5, size - 1, size - 1);
  ctx.beginPath();
  ctx.moveTo(size / 2, 0);
  ctx.lineTo(size / 2, size);
  ctx.moveTo(0, size / 2);
  ctx.lineTo(size, size / 2);
  ctx.stroke();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(14, 14);
  texture.anisotropy = Math.min(8, maxAnisotropy);
  return texture;
}

export function createWhiteEnvironment(
  scene: THREE.Scene,
  renderer: THREE.WebGLRenderer,
  isSoftwareGl: boolean
): WhiteEnvironmentRig {
  const group = new THREE.Group();
  const backgroundColor = PURE_WHITE.clone();
  const fog = new THREE.FogExp2(backgroundColor.getHex(), 0.028);
  scene.background = backgroundColor;
  scene.fog = fog;

  const floorTexture = createCorridorFloorTexture(renderer.capabilities.getMaxAnisotropy());
  const floorGeo = new THREE.PlaneGeometry(64, 64);
  const floorMaterial = new THREE.MeshStandardMaterial({
    color: PURE_WHITE.clone(),
    map: floorTexture,
    roughness: 0.34,
    metalness: 0.04,
    envMapIntensity: 0.55,
  });

  const floor = new THREE.Mesh(floorGeo, floorMaterial);
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = 0;
  floor.receiveShadow = !isSoftwareGl;
  group.add(floor);

  // Modern college corridor architectural elements (start pure white & transparent, reveal smoothly in Scene 1)
  const wallMat = new THREE.MeshStandardMaterial({
    color: PURE_WHITE.clone(),
    roughness: 0.82,
    metalness: 0.02,
    transparent: true,
    opacity: 0,
  });

  const tealTrimMat = new THREE.MeshStandardMaterial({
    color: DEEP_TEAL.clone(),
    roughness: 0.55,
    metalness: 0.08,
    transparent: true,
    opacity: 0,
  });

  const terracottaAccentMat = new THREE.MeshStandardMaterial({
    color: TERRACOTTA.clone(),
    roughness: 0.6,
    metalness: 0.05,
    transparent: true,
    opacity: 0,
  });

  const geometries: THREE.BufferGeometry[] = [floorGeo];
  const trackGeo = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };

  // Back corridor wall
  const backWall = new THREE.Mesh(trackGeo(new THREE.PlaneGeometry(42, 12)), wallMat);
  backWall.position.set(0, 6, -5.8);
  backWall.receiveShadow = !isSoftwareGl;
  group.add(backWall);

  // Corridor baseboard & upper architectural dado rail in Deep Teal
  const baseboard = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(42, 0.16, 0.08)), tealTrimMat);
  baseboard.position.set(0, 0.08, -5.72);
  group.add(baseboard);

  const dadoRail = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(42, 0.05, 0.06)), terracottaAccentMat);
  dadoRail.position.set(0, 1.35, -5.72);
  group.add(dadoRail);

  // Modern university corridor pillars & recessed classroom bay frames
  const pillarGeo = trackGeo(new THREE.BoxGeometry(0.46, 7.5, 0.48));
  const doorFrameGeo = trackGeo(new THREE.BoxGeometry(1.55, 2.6, 0.06));
  const noticeBoardGeo = trackGeo(new THREE.BoxGeometry(1.4, 0.9, 0.05));

  const pillarXs = [-9.0, -4.5, 0.0, 4.5, 9.0];
  for (let i = 0; i < pillarXs.length; i++) {
    const px = pillarXs[i];
    const pillar = new THREE.Mesh(pillarGeo, wallMat);
    pillar.position.set(px, 3.75, -5.45);
    pillar.castShadow = !isSoftwareGl;
    pillar.receiveShadow = !isSoftwareGl;
    group.add(pillar);

    // Recessed classroom doorway frame between pillars
    if (i < pillarXs.length - 1) {
      const midX = px + 2.25;
      if (i % 2 === 0) {
        const doorFrame = new THREE.Mesh(doorFrameGeo, tealTrimMat);
        doorFrame.position.set(midX, 1.3, -5.75);
        group.add(doorFrame);
      } else {
        const board = new THREE.Mesh(noticeBoardGeo, terracottaAccentMat);
        board.position.set(midX, 2.05, -5.74);
        group.add(board);
      }
    }
  }

  // Overhead corridor architectural ceiling beams for realistic perspective depth
  const beamGeo = trackGeo(new THREE.BoxGeometry(0.28, 0.24, 11.5));
  for (const px of pillarXs) {
    const beam = new THREE.Mesh(beamGeo, wallMat);
    beam.position.set(px, 5.2, -0.5);
    group.add(beam);
  }

  // Soft natural university daylight lighting rig
  const fillHemi = new THREE.HemisphereLight(0xffffff, 0xe8e2d5, 1.38);
  fillHemi.position.set(0, 12, 0);
  scene.add(fillHemi);

  const keyLight = new THREE.DirectionalLight(0xfffaf0, 1.48);
  keyLight.position.set(4.5, 9.5, 6.5);
  if (!isSoftwareGl) {
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 26;
    const d = 8.5;
    keyLight.shadow.camera.left = -d;
    keyLight.shadow.camera.right = d;
    keyLight.shadow.camera.top = d;
    keyLight.shadow.camera.bottom = -d;
    keyLight.shadow.bias = -0.0004;
    keyLight.shadow.normalBias = 0.025;
  }
  scene.add(keyLight);

  const rimLight = new THREE.DirectionalLight(0xf4f1e8, 0.65);
  rimLight.position.set(-5.5, 5.0, -3.5);
  scene.add(rimLight);

  scene.add(group);

  const updateCorridorReveal = (corridorReveal: number, focusWarmth: number) => {
    const r = THREE.MathUtils.clamp(corridorReveal, 0, 1);
    const w = THREE.MathUtils.clamp(focusWarmth, 0, 1);

    _tmpColor.copy(PURE_WHITE).lerp(WARM_IVORY_BG, r * 0.85 + w * 0.15);
    backgroundColor.copy(_tmpColor);
    scene.background = backgroundColor;
    fog.color.copy(_tmpColor);
    fog.density = THREE.MathUtils.lerp(0.022, 0.044, r * 0.7 + w * 0.3);

    floorMaterial.color.copy(PURE_WHITE).lerp(CORRIDOR_FLOOR, r);
    wallMat.color.copy(PURE_WHITE).lerp(CORRIDOR_WALL, r);
    wallMat.opacity = r;
    tealTrimMat.opacity = r * 0.92;
    terracottaAccentMat.opacity = r * 0.85;

    // Slightly soften ambient light during flashlight focus so the beam reads cinematically on warm ivory
    keyLight.intensity = THREE.MathUtils.lerp(1.48, 0.82, w);
    fillHemi.intensity = THREE.MathUtils.lerp(1.38, 0.9, w);
  };

  const dispose = () => {
    geometries.forEach((g) => g.dispose());
    floorTexture.dispose();
    floorMaterial.dispose();
    wallMat.dispose();
    tealTrimMat.dispose();
    terracottaAccentMat.dispose();
    scene.remove(group);
    scene.remove(keyLight);
    scene.remove(fillHemi);
    scene.remove(rimLight);
  };

  return {
    group,
    updateCorridorReveal,
    dispose,
  };
}
