import type { ReactNode } from 'react';
import type { BeamScreenState } from '../../types/campusfind';

interface FlashlightRevealProps {
  beam: BeamScreenState;
  introComplete: boolean;
  children: ReactNode;
}

export function FlashlightReveal({ beam, introComplete, children }: FlashlightRevealProps) {
  const isRevealing = beam.phase === 'sweeping' || beam.phase === 'complete' || introComplete;
  const isFullyOpen = introComplete || beam.fullReveal >= 0.98;

  const backdropOpacity = isFullyOpen
    ? 1
    : Math.min(1, Math.max(0, (beam.panelReveal - 0.15) * 1.25 + beam.fullReveal * 0.4));

  return (
    <div
      className={`relative z-10 min-h-screen w-full transition-opacity duration-500 ${
        isRevealing ? 'opacity-100' : 'opacity-0 pointer-events-none'
      } ${isFullyOpen ? 'pointer-events-auto' : 'pointer-events-none'}`}
    >
      {/* Clean Warm Ivory (#F4F1E8) architectural backdrop */}
      <div
        className="fixed inset-0 -z-10 transition-opacity duration-700"
        style={{
          opacity: backdropOpacity,
          backgroundColor: '#F4F1E8',
          backgroundImage:
            'radial-gradient(ellipse 70% 55% at 50% 42%, rgba(255, 252, 245, 0.85), rgba(244, 241, 232, 0.98) 72%)',
        }}
        aria-hidden="true"
      />

      {/* Subtle warm terracotta rim glow during phone handoff */}
      {!isFullyOpen && isRevealing && (
        <div
          className="fixed inset-0 z-20 pointer-events-none"
          style={{
            opacity: Math.max(0, 1 - beam.fullReveal) * 0.45,
            background:
              'radial-gradient(circle at 50% 48%, rgba(217, 130, 82, 0.18) 0%, rgba(255, 249, 238, 0.12) 28%, transparent 58%)',
          }}
          aria-hidden="true"
        />
      )}

      {/* Centered smartphone login canvas */}
      <div className="relative z-10 min-h-screen w-full">{children}</div>
    </div>
  );
}
