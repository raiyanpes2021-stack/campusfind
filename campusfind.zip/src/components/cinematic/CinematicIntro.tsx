import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import gsap from 'gsap';
import type { BeamScreenState } from '../../types/campusfind';
import { createWhiteEnvironment } from './WhiteEnvironment';
import { createWalkingCharacter } from './WalkingCharacter';
import { createFlashlightController } from './FlashlightController';
import { createLostSmartphone } from './LostSmartphone';

interface CinematicIntroProps {
  skipRequested: boolean;
  replayKey: number;
  onBeamUpdate: (state: BeamScreenState) => void;
  onIntroComplete: () => void;
}

const _phoneCenter = new THREE.Vector3();
const _beamOrigin = new THREE.Vector3();
const _beamDir = new THREE.Vector3();
const _aimDir = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _camPosTarget = new THREE.Vector3();
const _phoneScreenProj = new THREE.Vector3();

function detectSoftwareWebGL(): boolean {
  try {
    const gl = document.createElement('canvas').getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export function CinematicIntro({
  skipRequested,
  replayKey,
  onBeamUpdate,
  onIntroComplete,
}: CinematicIntroProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [webglUnavailable, setWebglUnavailable] = useState(false);

  const onBeamUpdateRef = useRef(onBeamUpdate);
  const onIntroCompleteRef = useRef(onIntroComplete);
  onBeamUpdateRef.current = onBeamUpdate;
  onIntroCompleteRef.current = onIntroComplete;

  const timelineRef = useRef<gsap.core.Timeline | null>(null);

  useEffect(() => {
    if (skipRequested && timelineRef.current) {
      timelineRef.current.progress(1);
    }
  }, [skipRequested]);

  useEffect(() => {
    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (prefersReducedMotion || skipRequested) {
      onBeamUpdateRef.current({
        x: 0.5,
        y: 0.5,
        intensity: 1,
        radius: 148,
        logoReveal: 1,
        headingReveal: 1,
        panelReveal: 1,
        fullReveal: 1,
        worldDarkness: 1,
        phase: 'complete',
      });
      onIntroCompleteRef.current();
      return;
    }

    const container = containerRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer;
    const isSoftwareGl = detectSoftwareWebGL();
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
        alpha: false,
      });
    } catch {
      setWebglUnavailable(true);
      onBeamUpdateRef.current({
        x: 0.5,
        y: 0.5,
        intensity: 1,
        radius: 148,
        logoReveal: 1,
        headingReveal: 1,
        panelReveal: 1,
        fullReveal: 1,
        worldDarkness: 1,
        phase: 'complete',
      });
      onIntroCompleteRef.current();
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.06;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setWebglUnavailable(true);
      onIntroCompleteRef.current();
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);

    const scene = new THREE.Scene();

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTarget = pmremGenerator.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envTarget.texture;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(
      38,
      (container.clientWidth || window.innerWidth) / Math.max(1, container.clientHeight || window.innerHeight),
      0.1,
      100
    );
    camera.position.set(-1.5, 1.65, 5.4);
    const currentLookAt = new THREE.Vector3(-0.5, 0.85, 0.25);
    camera.lookAt(currentLookAt);

    const env = createWhiteEnvironment(scene, renderer, isSoftwareGl);
    const flashlight = createFlashlightController(scene, isSoftwareGl);

    // Scene 3: Dark smartphone lying on the college corridor floor
    const smartphone = createLostSmartphone(renderer, isSoftwareGl);
    smartphone.root.position.set(1.15, 0, 0.35);
    scene.add(smartphone.root);

    // Scene 2: Young college student with hoodie & backpack enters walking
    const character = createWalkingCharacter(isSoftwareGl, true);
    character.root.position.set(-5.0, 0, 0.35);
    character.root.rotation.y = Math.PI * 0.5;
    scene.add(character.root);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const anim = {
      corridorReveal: 0,
      focusWarmth: 0,
      charX: -5.0,
      charZ: 0.35,
      charYaw: Math.PI * 0.5,
      walkStrength: 0,
      searchLook: 0,
      raiseFlashlight: 0,
      flashlightPower: 0,
      beamHit: 0,
      loginReveal: 0,
      scanIntensity: 0,
      riseProgress: 0,
      camX: -1.5,
      camY: 1.65,
      camZ: 5.4,
      lookX: -0.5,
      lookY: 0.85,
      lookZ: 0.25,
      panelReveal: 0,
      fullReveal: 0,
      phaseIndex: 0,
    };

    const phases: BeamScreenState['phase'][] = [
      'white-studio',
      'entering',
      'activating',
      'sweeping',
      'complete',
    ];

    const tl = gsap.timeline({
      onComplete: () => {
        anim.phaseIndex = 4;
        onBeamUpdateRef.current({
          x: 0.5,
          y: 0.5,
          intensity: 1,
          radius: 148,
          logoReveal: 1,
          headingReveal: 1,
          panelReveal: 1,
          fullReveal: 1,
          worldDarkness: 1,
          phase: 'complete',
        });
        onIntroCompleteRef.current();
      },
    });
    timelineRef.current = tl;

    // SCENE 1 (0.0s - 1.2s): Pure White screen -> gradually reveals modern college corridor
    tl.to(anim, { corridorReveal: 1, camX: -1.0, lookX: -0.1, duration: 1.2, ease: 'power1.inOut' });

    // SCENE 2 (1.2s - 3.9s): College student (casual hoodie + backpack) enters walking naturally
    tl.call(() => {
      anim.phaseIndex = 1;
    });
    tl.to(anim, { walkStrength: 1, duration: 0.28, ease: 'power2.out' }, 'enter');
    tl.to(
      anim,
      {
        charX: -0.25,
        charZ: 0.36,
        camX: 0.55,
        camY: 1.5,
        camZ: 4.1,
        lookX: 0.55,
        lookY: 0.6,
        lookZ: 0.35,
        duration: 2.6,
        ease: 'power1.inOut',
      },
      'enter'
    );
    tl.to(anim, { searchLook: 0.5, duration: 0.65, ease: 'sine.inOut' }, 'enter+=0.35');
    tl.to(anim, { searchLook: -0.35, duration: 0.65, ease: 'sine.inOut' }, 'enter+=1.1');
    // SCENE 3: Notices smartphone on corridor floor & stops
    tl.to(anim, { searchLook: 0, walkStrength: 0, duration: 0.5, ease: 'power2.out' }, 'enter+=2.1');

    // SCENE 4 (3.9s - 6.6s): Points flashlight at phone -> phone reacts, screen activates, rises smoothly toward camera
    tl.call(() => {
      anim.phaseIndex = 2;
    }, undefined, 'illuminate');
    tl.to(
      anim,
      {
        raiseFlashlight: 1,
        camX: 1.48,
        camY: 1.28,
        camZ: 2.4,
        lookX: 1.08,
        lookY: 0.24,
        lookZ: 0.35,
        duration: 0.85,
        ease: 'power2.inOut',
      },
      'illuminate'
    );
    tl.to(anim, { flashlightPower: 1, focusWarmth: 0.85, duration: 0.35, ease: 'power2.out' }, 'illuminate+=0.6');
    tl.to(
      anim,
      {
        beamHit: 1,
        scanIntensity: 1,
        loginReveal: 1,
        duration: 0.95,
        ease: 'power2.out',
      },
      'illuminate+=0.78'
    );

    // Phone rises upright off the floor while camera focuses straight onto the phone screen
    tl.call(() => {
      anim.phaseIndex = 3;
    }, undefined, 'rise');
    tl.to(
      anim,
      {
        riseProgress: 1,
        flashlightPower: 0.15,
        camX: 1.15,
        camY: 1.02,
        camZ: 1.24,
        lookX: 1.15,
        lookY: 1.02,
        lookZ: 0.35,
        duration: 1.65,
        ease: 'power2.inOut',
      },
      'rise'
    );

    // SCENE 5: Seamless morph into the real working interactive smartphone login frame
    tl.to(anim, { panelReveal: 1, fullReveal: 1, duration: 0.8, ease: 'power2.out' }, 'rise+=1.15');

    let disposed = false;
    let frameId = 0;
    let walkPhase = 0;
    let lastTime = performance.now();
    const startTime = lastTime;
    let lastReportTime = 0;

    const afterDraw = (cb: () => void) => {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 75);
        }
      };
      frameId = window.setTimeout(poll, 5);
    };

    const tick = () => {
      if (disposed) return;

      const now = performance.now();
      const dt = Math.min(0.05, (now - lastTime) / 1000);
      lastTime = now;
      const elapsed = (now - startTime) / 1000;

      env.updateCorridorReveal(anim.corridorReveal, anim.focusWarmth);

      smartphone.update({
        elapsed,
        beamHit: anim.beamHit,
        loginReveal: anim.loginReveal,
        scanIntensity: anim.scanIntensity,
        riseProgress: anim.riseProgress,
      });

      smartphone.screenCenterWorld(_phoneCenter);

      character.root.position.set(anim.charX, 0, anim.charZ);
      character.root.rotation.y = anim.charYaw;

      walkPhase += dt * 6.0 * anim.walkStrength;
      character.updateWalk(walkPhase, anim.walkStrength, elapsed, anim.searchLook);
      character.updateFlashlightAim(anim.raiseFlashlight, anim.flashlightPower, _phoneCenter);

      character.getFlashlightWorldPose(_beamOrigin, _beamDir);
      _aimDir.copy(_phoneCenter).sub(_beamOrigin).normalize();
      _beamDir.lerp(_aimDir, anim.raiseFlashlight).normalize();
      flashlight.update(_beamOrigin, _beamDir, anim.flashlightPower, elapsed);

      _camPosTarget.set(anim.camX, anim.camY, anim.camZ);
      camera.position.lerp(_camPosTarget, 1 - Math.exp(-5.6 * dt));
      _camTarget.set(anim.lookX, anim.lookY, anim.lookZ);
      currentLookAt.lerp(_camTarget, 1 - Math.exp(-6.0 * dt));
      camera.lookAt(currentLookAt);

      renderer.render(scene, camera);

      if (now - lastReportTime > 24) {
        lastReportTime = now;
        _phoneScreenProj.copy(_phoneCenter).project(camera);
        const sx = THREE.MathUtils.clamp((_phoneScreenProj.x + 1) * 0.5, 0.2, 0.8);
        const sy = THREE.MathUtils.clamp((1 - _phoneScreenProj.y) * 0.5, 0.2, 0.8);

        onBeamUpdateRef.current({
          x: THREE.MathUtils.lerp(sx, 0.5, anim.fullReveal),
          y: THREE.MathUtils.lerp(sy, 0.5, anim.fullReveal),
          intensity: anim.beamHit,
          radius: anim.fullReveal * 148,
          logoReveal: anim.panelReveal,
          headingReveal: anim.panelReveal,
          panelReveal: anim.panelReveal,
          fullReveal: anim.fullReveal,
          worldDarkness: anim.corridorReveal,
          phase: phases[anim.phaseIndex] || 'complete',
        });
      }

      if (anim.phaseIndex < 4) {
        if (isSoftwareGl) {
          afterDraw(tick);
        } else {
          frameId = requestAnimationFrame(tick);
        }
      }
    };

    const onResize = () => {
      if (!container || disposed) return;
      const w = container.clientWidth || window.innerWidth;
      const h = Math.max(1, container.clientHeight || window.innerHeight);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    frameId = requestAnimationFrame(tick);

    return () => {
      disposed = true;
      tl.kill();
      timelineRef.current = null;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', onResize);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      flashlight.dispose();
      smartphone.dispose();
      character.dispose();
      env.dispose();
      envTarget.dispose();
      renderer.dispose();
    };
  }, [replayKey, skipRequested]);

  if (webglUnavailable) {
    return <div className="fixed inset-0 z-0 bg-[#F4F1E8]" aria-hidden="true" />;
  }

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-0 w-full h-full overflow-hidden"
      aria-hidden="true"
    />
  );
}
