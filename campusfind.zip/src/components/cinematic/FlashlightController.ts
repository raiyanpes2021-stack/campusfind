import * as THREE from 'three';

export interface FlashlightRig {
  spotLight: THREE.SpotLight;
  beamGroup: THREE.Group;
  dustPoints: THREE.Points;
  update: (
    origin: THREE.Vector3,
    direction: THREE.Vector3,
    intensity: number,
    elapsed: number
  ) => void;
  dispose: () => void;
}

const _targetPos = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);
const _lookMat = new THREE.Matrix4();
const _quat = new THREE.Quaternion();

const VOLUMETRIC_VERTEX_SHADER = /* glsl */ `
  varying vec3 vNormal;
  varying vec3 vViewDir;
  varying vec2 vUv;

  void main() {
    vUv = uv;
    vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
    vNormal = normalize(normalMatrix * normal);
    vViewDir = normalize(-mvPosition.xyz);
    gl_Position = projectionMatrix * mvPosition;
  }
`;

const VOLUMETRIC_FRAGMENT_SHADER = /* glsl */ `
  uniform float uIntensity;
  uniform float uTime;
  uniform vec3 uColorCore;
  uniform vec3 uColorEdge;

  varying vec3 vNormal;
  varying vec3 vViewDir;
  varying vec2 vUv;

  void main() {
    // vUv.y = 1 near flashlight lens, 0 at far cone end
    float axial = pow(clamp(vUv.y, 0.0, 1.0), 1.45);
    float nearFade = smoothstep(1.0, 0.92, vUv.y);

    // Soft Fresnel edge falloff so cone edges never look like hard geometry
    float fresnel = pow(abs(dot(normalize(vNormal), normalize(vViewDir))), 1.75);

    // Subtle atmospheric shimmer
    float shimmer = 0.92 + 0.08 * sin(vUv.y * 14.0 - uTime * 2.2 + vUv.x * 6.2831);

    vec3 col = mix(uColorEdge, uColorCore, axial * fresnel);
    float alpha = axial * nearFade * fresnel * shimmer * uIntensity * 0.44;
    gl_FragColor = vec4(col, alpha);
  }
`;

const DUST_VERTEX_SHADER = /* glsl */ `
  attribute float aScale;
  attribute float aPhase;

  uniform float uTime;
  uniform vec3 uBeamOrigin;
  uniform vec3 uBeamDir;
  uniform float uBeamIntensity;

  varying float vBrightness;

  void main() {
    vec3 pos = position;
    pos.x += sin(uTime * 0.35 + aPhase) * 0.16;
    pos.y += cos(uTime * 0.28 + aPhase * 1.3) * 0.14;
    pos.z += sin(uTime * 0.22 + aPhase * 0.7) * 0.12;

    // Compute how strongly this dust mote sits inside the flashlight cone
    vec3 toPoint = pos - uBeamOrigin;
    float distAlong = dot(toPoint, uBeamDir);
    float coneLit = 0.0;
    if (distAlong > 0.1 && distAlong < 11.5) {
      vec3 perp = toPoint - uBeamDir * distAlong;
      float coneRadius = 0.14 + distAlong * 0.34;
      float radialFactor = smoothstep(coneRadius, coneRadius * 0.2, length(perp));
      float distFactor = smoothstep(11.5, 0.6, distAlong);
      coneLit = radialFactor * distFactor * uBeamIntensity;
    }

    vBrightness = 0.06 + coneLit * 1.15;

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    gl_PointSize = aScale * (220.0 / max(1.5, -mvPosition.z)) * (0.65 + coneLit * 0.85);
    gl_Position = projectionMatrix * mvPosition;
  }
`;

const DUST_FRAGMENT_SHADER = /* glsl */ `
  varying float vBrightness;

  void main() {
    vec2 center = gl_PointCoord - vec2(0.5);
    float d = length(center);
    if (d > 0.5) discard;
    float soft = pow(1.0 - d * 2.0, 2.0);
    vec3 col = mix(vec3(0.55, 0.88, 1.0), vec3(0.95, 0.99, 1.0), clamp(vBrightness, 0.0, 1.0));
    gl_FragColor = vec4(col, soft * vBrightness * 0.72);
  }
`;

export function createFlashlightController(scene: THREE.Scene, isSoftwareGl: boolean): FlashlightRig {
  // Primary realistic SpotLight in warm ivory daylight
  const spotLight = new THREE.SpotLight(0xfff6e5, 0, 22, Math.PI * 0.22, 0.78, 1.35);
  if (!isSoftwareGl) {
    spotLight.castShadow = true;
    spotLight.shadow.mapSize.width = 1024;
    spotLight.shadow.mapSize.height = 1024;
    spotLight.shadow.camera.near = 0.3;
    spotLight.shadow.camera.far = 20;
    spotLight.shadow.bias = -0.0004;
  }
  scene.add(spotLight);
  scene.add(spotLight.target);

  // Volumetric cone group oriented along +Z
  const beamGroup = new THREE.Group();
  scene.add(beamGroup);

  const beamLength = 7.5;
  const outerConeGeo = new THREE.CylinderGeometry(0.05, 1.65, beamLength, 32, 1, true);
  outerConeGeo.translate(0, -beamLength / 2, 0);
  outerConeGeo.rotateX(-Math.PI / 2);

  const outerConeMat = new THREE.ShaderMaterial({
    vertexShader: VOLUMETRIC_VERTEX_SHADER,
    fragmentShader: VOLUMETRIC_FRAGMENT_SHADER,
    uniforms: {
      uIntensity: { value: 0 },
      uTime: { value: 0 },
      uColorCore: { value: new THREE.Color('#fff9ee') },
      uColorEdge: { value: new THREE.Color('#d98252') },
    },
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
  });

  const outerConeMesh = new THREE.Mesh(outerConeGeo, outerConeMat);
  beamGroup.add(outerConeMesh);

  // Inner tighter core beam for realistic flashlight hotspot
  const innerConeGeo = new THREE.CylinderGeometry(0.03, 0.72, beamLength * 0.85, 24, 1, true);
  innerConeGeo.translate(0, -(beamLength * 0.85) / 2, 0);
  innerConeGeo.rotateX(-Math.PI / 2);

  const innerConeMat = new THREE.ShaderMaterial({
    vertexShader: VOLUMETRIC_VERTEX_SHADER,
    fragmentShader: VOLUMETRIC_FRAGMENT_SHADER,
    uniforms: {
      uIntensity: { value: 0 },
      uTime: { value: 0 },
      uColorCore: { value: new THREE.Color('#ffffff') },
      uColorEdge: { value: new THREE.Color('#f4d2b8') },
    },
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
  });

  const innerConeMesh = new THREE.Mesh(innerConeGeo, innerConeMat);
  beamGroup.add(innerConeMesh);

  // Atmospheric dust motes illuminated by the flashlight cone
  const dustCount = 220;
  const positions = new Float32Array(dustCount * 3);
  const scales = new Float32Array(dustCount);
  const phases = new Float32Array(dustCount);

  for (let i = 0; i < dustCount; i++) {
    positions[i * 3 + 0] = (Math.random() - 0.5) * 11.0;
    positions[i * 3 + 1] = 0.25 + Math.random() * 3.8;
    positions[i * 3 + 2] = -4.5 + Math.random() * 8.5;
    scales[i] = 0.55 + Math.random() * 1.45;
    phases[i] = Math.random() * Math.PI * 2;
  }

  const dustGeo = new THREE.BufferGeometry();
  dustGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  dustGeo.setAttribute('aScale', new THREE.BufferAttribute(scales, 1));
  dustGeo.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));

  const dustMat = new THREE.ShaderMaterial({
    vertexShader: DUST_VERTEX_SHADER,
    fragmentShader: DUST_FRAGMENT_SHADER,
    uniforms: {
      uTime: { value: 0 },
      uBeamOrigin: { value: new THREE.Vector3() },
      uBeamDir: { value: new THREE.Vector3(0, 0, 1) },
      uBeamIntensity: { value: 0 },
    },
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });

  const dustPoints = new THREE.Points(dustGeo, dustMat);
  dustPoints.frustumCulled = false;
  scene.add(dustPoints);

  const update = (origin: THREE.Vector3, direction: THREE.Vector3, intensity: number, elapsed: number) => {
    const clamped = THREE.MathUtils.clamp(intensity, 0, 1);

    spotLight.position.copy(origin);
    _targetPos.copy(origin).addScaledVector(direction, 8.0);
    spotLight.target.position.copy(_targetPos);
    spotLight.intensity = clamped * 44;

    beamGroup.visible = clamped > 0.005;
    beamGroup.position.copy(origin);
    _lookMat.lookAt(_targetPos, origin, _up);
    _quat.setFromRotationMatrix(_lookMat);
    beamGroup.quaternion.copy(_quat);

    outerConeMat.uniforms.uIntensity.value = clamped;
    outerConeMat.uniforms.uTime.value = elapsed;
    innerConeMat.uniforms.uIntensity.value = clamped * 0.85;
    innerConeMat.uniforms.uTime.value = elapsed;

    dustPoints.visible = clamped > 0.02;
    dustMat.uniforms.uTime.value = elapsed;
    dustMat.uniforms.uBeamOrigin.value.copy(origin);
    dustMat.uniforms.uBeamDir.value.copy(direction);
    dustMat.uniforms.uBeamIntensity.value = clamped;
  };

  const dispose = () => {
    outerConeGeo.dispose();
    outerConeMat.dispose();
    innerConeGeo.dispose();
    innerConeMat.dispose();
    dustGeo.dispose();
    dustMat.dispose();
    scene.remove(spotLight);
    scene.remove(spotLight.target);
    scene.remove(beamGroup);
    scene.remove(dustPoints);
  };

  return {
    spotLight,
    beamGroup,
    dustPoints,
    update,
    dispose,
  };
}
