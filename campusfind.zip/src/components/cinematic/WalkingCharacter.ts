import * as THREE from 'three';

export interface WalkingCharacterRig {
  root: THREE.Group;
  flashlightLensNode: THREE.Object3D;
  contactShadow: THREE.Mesh;
  updateWalk: (walkPhase: number, walkStrength: number, idleTime: number, searchLook: number) => void;
  updateFlashlightAim: (raiseAmount: number, flashlightOn: number, targetWorld: THREE.Vector3) => void;
  updateGreeting: (elapsed: number, waving: boolean) => void;
  getFlashlightWorldPose: (originOut: THREE.Vector3, dirOut: THREE.Vector3) => void;
  dispose: () => void;
}

const _handPos = new THREE.Vector3();
const _targetLocal = new THREE.Vector3();
const _invQuat = new THREE.Quaternion();
const _lensQuat = new THREE.Quaternion();

function createContactShadowTexture(): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(size / 2, size / 2, 4, size / 2, size / 2, size / 2);
  grad.addColorStop(0, 'rgba(23, 76, 74, 0.34)');
  grad.addColorStop(0.55, 'rgba(23, 76, 74, 0.14)');
  grad.addColorStop(1, 'rgba(23, 76, 74, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createWalkingCharacter(isSoftwareGl: boolean, showFlashlight = true): WalkingCharacterRig {
  const root = new THREE.Group();
  const geometries: THREE.BufferGeometry[] = [];
  const materials: THREE.Material[] = [];
  const textures: THREE.Texture[] = [];

  const trackGeo = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const trackMat = <T extends THREE.Material>(m: T): T => {
    materials.push(m);
    return m;
  };

  // Casual college student wardrobe (Warm Ivory tee hem, Deep Teal college hoodie, denim jeans, canvas backpack with Terracotta trim)
  const skinMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0xdca480,
      roughness: 0.56,
      metalness: 0.02,
    })
  );
  const hairMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x1c1b1a,
      roughness: 0.86,
      metalness: 0.04,
    })
  );
  const hoodieMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x174c4a, // Deep Teal college hoodie
      roughness: 0.88,
      metalness: 0.02,
    })
  );
  const teeHemMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0xf4f1e8, // Warm Ivory undershirt hem & hoodie drawstrings
      roughness: 0.78,
      metalness: 0.01,
    })
  );
  const jeansMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x354658, // Casual college denim
      roughness: 0.9,
      metalness: 0.02,
    })
  );
  const backpackMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x2c3635, // Charcoal canvas backpack
      roughness: 0.85,
      metalness: 0.03,
    })
  );
  const terracottaMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0xd98252, // Terracotta backpack zip & accent
      roughness: 0.62,
      metalness: 0.06,
    })
  );
  const shoeUpperMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x1f2b2a,
      roughness: 0.55,
      metalness: 0.05,
    })
  );
  const shoeSoleMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0xf4f1e8,
      roughness: 0.38,
      metalness: 0.03,
    })
  );

  // Flashlight materials
  const flashlightBodyMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x1e2c2b,
      metalness: 0.82,
      roughness: 0.26,
    })
  );
  const flashlightAccentMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0xd98252,
      emissive: 0xd98252,
      emissiveIntensity: 0.2,
      metalness: 0.4,
      roughness: 0.24,
    })
  );
  const flashlightLensMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0xfff8eb,
      emissive: 0xffe4b5,
      emissiveIntensity: 0.0,
      roughness: 0.08,
      metalness: 0.1,
    })
  );

  const setShadows = (obj: THREE.Object3D) => {
    if (isSoftwareGl) return;
    obj.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        child.castShadow = true;
        child.receiveShadow = true;
      }
    });
  };

  // Contact shadow grounding plane
  const shadowTex = createContactShadowTexture();
  textures.push(shadowTex);
  const contactShadow = new THREE.Mesh(
    trackGeo(new THREE.PlaneGeometry(1.1, 0.9)),
    trackMat(
      new THREE.MeshBasicMaterial({
        map: shadowTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.55,
      })
    )
  );
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.y = 0.012;
  root.add(contactShadow);

  // Pelvis / body root
  const bodyGroup = new THREE.Group();
  bodyGroup.position.y = 0.96;
  root.add(bodyGroup);

  const pelvis = new THREE.Mesh(trackGeo(new THREE.CapsuleGeometry(0.145, 0.1, 8, 16)), jeansMat);
  pelvis.rotation.z = Math.PI / 2;
  pelvis.scale.set(0.82, 1.0, 0.78);
  bodyGroup.add(pelvis);

  // Torso (Casual College Hoodie + Backpack)
  const torsoGroup = new THREE.Group();
  torsoGroup.position.y = 0.06;
  bodyGroup.add(torsoGroup);

  const hoodieTorso = new THREE.Mesh(trackGeo(new THREE.CylinderGeometry(0.188, 0.165, 0.51, 18)), hoodieMat);
  hoodieTorso.position.set(0, 0.26, 0);
  hoodieTorso.scale.set(1.14, 1, 0.8);
  torsoGroup.add(hoodieTorso);

  // Subtle Warm Ivory undershirt hem peeking below hoodie
  const teeHem = new THREE.Mesh(trackGeo(new THREE.CylinderGeometry(0.168, 0.165, 0.045, 16)), teeHemMat);
  teeHem.position.set(0, 0.005, 0);
  teeHem.scale.set(1.13, 1, 0.79);
  torsoGroup.add(teeHem);

  // Hoodie kangaroo pocket
  const pocket = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(0.24, 0.13, 0.045)), hoodieMat);
  pocket.position.set(0, 0.12, 0.138);
  torsoGroup.add(pocket);

  // Relaxed hood resting on back of shoulders
  const hoodRest = new THREE.Mesh(trackGeo(new THREE.TorusGeometry(0.12, 0.042, 10, 18, Math.PI * 1.4)), hoodieMat);
  hoodRest.position.set(0, 0.5, -0.045);
  hoodRest.rotation.x = Math.PI / 2 + 0.28;
  hoodRest.rotation.z = -Math.PI * 0.2;
  torsoGroup.add(hoodRest);

  // Hoodie drawstrings
  const stringGeo = trackGeo(new THREE.CylinderGeometry(0.0045, 0.0045, 0.14, 6));
  const leftString = new THREE.Mesh(stringGeo, teeHemMat);
  leftString.position.set(-0.042, 0.42, 0.145);
  const rightString = new THREE.Mesh(stringGeo, teeHemMat);
  rightString.position.set(0.042, 0.42, 0.145);
  torsoGroup.add(leftString, rightString);

  // College Backpack on back (distinctively college student silhouette!)
  const backpackGroup = new THREE.Group();
  backpackGroup.position.set(0, 0.27, -0.195);
  torsoGroup.add(backpackGroup);

  const packMain = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(0.29, 0.38, 0.15)), backpackMat);
  backpackGroup.add(packMain);

  const packTop = new THREE.Mesh(trackGeo(new THREE.CylinderGeometry(0.075, 0.075, 0.29, 12)), backpackMat);
  packTop.rotation.z = Math.PI / 2;
  packTop.position.set(0, 0.19, 0);
  backpackGroup.add(packTop);

  const packFrontPocket = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(0.23, 0.16, 0.055)), backpackMat);
  packFrontPocket.position.set(0, -0.07, -0.09);
  backpackGroup.add(packFrontPocket);

  const packZipAccent = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(0.235, 0.022, 0.058)), terracottaMat);
  packZipAccent.position.set(0, 0.01, -0.092);
  backpackGroup.add(packZipAccent);

  // Backpack shoulder straps wrapping around front of hoodie
  const strapGeo = trackGeo(new THREE.BoxGeometry(0.042, 0.36, 0.025));
  const leftStrap = new THREE.Mesh(strapGeo, backpackMat);
  leftStrap.position.set(-0.145, 0.31, 0.145);
  leftStrap.rotation.z = -0.06;
  const rightStrap = new THREE.Mesh(strapGeo, backpackMat);
  rightStrap.position.set(0.145, 0.31, 0.145);
  rightStrap.rotation.z = 0.06;
  torsoGroup.add(leftStrap, rightStrap);

  // Head & Neck
  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.54, 0.01);
  torsoGroup.add(headGroup);

  const neck = new THREE.Mesh(trackGeo(new THREE.CylinderGeometry(0.056, 0.066, 0.1, 12)), skinMat);
  neck.position.y = 0.03;
  headGroup.add(neck);

  const head = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.125, 20, 20)), skinMat);
  head.position.set(0, 0.165, 0.01);
  head.scale.set(0.89, 1.05, 0.94);
  headGroup.add(head);

  const hairCrown = new THREE.Mesh(
    trackGeo(new THREE.SphereGeometry(0.133, 18, 16, 0, Math.PI * 2, 0, Math.PI * 0.58)),
    hairMat
  );
  hairCrown.position.set(0, 0.178, -0.005);
  hairCrown.scale.set(0.93, 1.06, 0.99);
  headGroup.add(hairCrown);

  const hairFront = new THREE.Mesh(trackGeo(new THREE.CapsuleGeometry(0.048, 0.095, 6, 12)), hairMat);
  hairFront.position.set(0.012, 0.268, 0.068);
  hairFront.rotation.z = Math.PI / 2 - 0.18;
  hairFront.rotation.y = 0.15;
  headGroup.add(hairFront);

  const nose = new THREE.Mesh(trackGeo(new THREE.ConeGeometry(0.015, 0.04, 8)), skinMat);
  nose.position.set(0, 0.155, 0.122);
  nose.rotation.x = Math.PI / 2 - 0.25;
  headGroup.add(nose);

  const eyeGeo = trackGeo(new THREE.SphereGeometry(0.011, 8, 8));
  const leftEye = new THREE.Mesh(eyeGeo, hairMat);
  leftEye.position.set(-0.042, 0.175, 0.105);
  const rightEye = new THREE.Mesh(eyeGeo, hairMat);
  rightEye.position.set(0.042, 0.175, 0.105);
  headGroup.add(leftEye, rightEye);

  // Subtle friendly smile arc
  const smile = new THREE.Mesh(
    trackGeo(new THREE.TorusGeometry(0.022, 0.004, 6, 12, Math.PI)),
    trackMat(new THREE.MeshStandardMaterial({ color: 0x8d5742, roughness: 0.7 }))
  );
  smile.position.set(0, 0.118, 0.112);
  smile.rotation.z = Math.PI;
  headGroup.add(smile);

  // Articulated Arms
  const buildArm = (side: -1 | 1) => {
    const shoulder = new THREE.Group();
    shoulder.position.set(side * 0.245, 0.45, 0);
    torsoGroup.add(shoulder);

    const shoulderCap = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.072, 12, 12)), hoodieMat);
    shoulder.add(shoulderCap);

    const upperArm = new THREE.Mesh(trackGeo(new THREE.CapsuleGeometry(0.055, 0.21, 8, 12)), hoodieMat);
    upperArm.position.y = -0.145;
    shoulder.add(upperArm);

    const elbow = new THREE.Group();
    elbow.position.y = -0.29;
    shoulder.add(elbow);

    const forearm = new THREE.Mesh(trackGeo(new THREE.CapsuleGeometry(0.046, 0.2, 8, 12)), hoodieMat);
    forearm.position.y = -0.125;
    elbow.add(forearm);

    const cuff = new THREE.Mesh(trackGeo(new THREE.CylinderGeometry(0.045, 0.042, 0.036, 12)), hoodieMat);
    cuff.position.y = -0.235;
    elbow.add(cuff);

    const hand = new THREE.Group();
    hand.position.y = -0.285;
    elbow.add(hand);

    const palm = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(0.052, 0.068, 0.062)), skinMat);
    hand.add(palm);

    let flashlightLensNode: THREE.Object3D | null = null;

    if (side === 1) {
      const flashlightGroup = new THREE.Group();
      flashlightGroup.position.set(0, -0.025, 0.045);
      flashlightGroup.visible = showFlashlight;
      hand.add(flashlightGroup);

      const handle = new THREE.Mesh(
        trackGeo(new THREE.CylinderGeometry(0.02, 0.018, 0.17, 16)),
        flashlightBodyMat
      );
      handle.rotation.x = Math.PI / 2;
      flashlightGroup.add(handle);

      const headBezel = new THREE.Mesh(
        trackGeo(new THREE.CylinderGeometry(0.031, 0.022, 0.062, 18)),
        flashlightBodyMat
      );
      headBezel.rotation.x = Math.PI / 2;
      headBezel.position.z = 0.11;
      flashlightGroup.add(headBezel);

      const accentRing = new THREE.Mesh(
        trackGeo(new THREE.TorusGeometry(0.028, 0.004, 10, 20)),
        flashlightAccentMat
      );
      accentRing.position.z = 0.132;
      flashlightGroup.add(accentRing);

      const lens = new THREE.Mesh(trackGeo(new THREE.CircleGeometry(0.026, 18)), flashlightLensMat);
      lens.position.z = 0.145;
      flashlightGroup.add(lens);

      flashlightLensNode = new THREE.Object3D();
      flashlightLensNode.position.set(0, 0, 0.152);
      flashlightGroup.add(flashlightLensNode);
    }

    return { shoulder, elbow, hand, flashlightLensNode };
  };

  const leftArm = buildArm(-1);
  const rightArm = buildArm(1);
  const flashlightLensNode = rightArm.flashlightLensNode!;

  // Articulated Legs & Sneakers
  const buildLeg = (side: -1 | 1) => {
    const hip = new THREE.Group();
    hip.position.set(side * 0.105, -0.02, 0);
    bodyGroup.add(hip);

    const thigh = new THREE.Mesh(trackGeo(new THREE.CapsuleGeometry(0.072, 0.31, 8, 14)), jeansMat);
    thigh.position.y = -0.21;
    hip.add(thigh);

    const knee = new THREE.Group();
    knee.position.y = -0.44;
    hip.add(knee);

    const shin = new THREE.Mesh(trackGeo(new THREE.CapsuleGeometry(0.056, 0.32, 8, 14)), jeansMat);
    shin.position.y = -0.2;
    knee.add(shin);

    const ankle = new THREE.Group();
    ankle.position.y = -0.42;
    knee.add(ankle);

    const shoeUpper = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(0.095, 0.068, 0.225)), shoeUpperMat);
    shoeUpper.position.set(0, -0.032, 0.045);
    ankle.add(shoeUpper);

    const shoeSole = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(0.102, 0.026, 0.24)), shoeSoleMat);
    shoeSole.position.set(0, -0.072, 0.045);
    ankle.add(shoeSole);

    return { hip, knee, ankle };
  };

  const leftLeg = buildLeg(-1);
  const rightLeg = buildLeg(1);

  setShadows(root);

  const updateWalk = (walkPhase: number, walkStrength: number, idleTime: number, searchLook: number) => {
    const w = THREE.MathUtils.clamp(walkStrength, 0, 1);
    const s = Math.sin(walkPhase);
    const c = Math.cos(walkPhase);

    const strideBob = Math.abs(Math.sin(walkPhase)) * 0.032 * w;
    const idleBreath = Math.sin(idleTime * 1.9) * 0.006 * (1 - w);
    bodyGroup.position.y = 0.96 + strideBob + idleBreath;

    torsoGroup.rotation.y = -s * 0.075 * w;
    torsoGroup.rotation.x = 0.04 * w;

    headGroup.rotation.y = searchLook * 0.32 + s * 0.035 * w;
    headGroup.rotation.x = 0.08 + Math.abs(searchLook) * 0.06;

    leftLeg.hip.rotation.x = s * 0.52 * w;
    rightLeg.hip.rotation.x = -s * 0.52 * w;
    leftLeg.knee.rotation.x = Math.max(0, -c) * 0.58 * w;
    rightLeg.knee.rotation.x = Math.max(0, c) * 0.58 * w;
    leftLeg.ankle.rotation.x = -leftLeg.hip.rotation.x * 0.35;
    rightLeg.ankle.rotation.x = -rightLeg.hip.rotation.x * 0.35;

    leftArm.shoulder.rotation.x = -s * 0.38 * w + Math.sin(idleTime * 1.4) * 0.02 * (1 - w);
    leftArm.shoulder.rotation.z = -0.06;
    leftArm.elbow.rotation.x = -(0.2 + Math.max(0, s) * 0.2) * w - 0.14 * (1 - w);

    rightArm.shoulder.userData.walkSwingX = s * 0.24 * w;
    rightArm.elbow.userData.walkBendX = -(0.35 + Math.max(0, -s) * 0.14) * w - 0.22 * (1 - w);
  };

  const updateFlashlightAim = (raiseAmount: number, flashlightOn: number, targetWorld: THREE.Vector3) => {
    const r = THREE.MathUtils.clamp(raiseAmount, 0, 1);
    const on = THREE.MathUtils.clamp(flashlightOn, 0, 1);
    const walkSwingX = (rightArm.shoulder.userData.walkSwingX as number) || 0;
    const walkBendX = (rightArm.elbow.userData.walkBendX as number) || -0.24;

    torsoGroup.rotation.x = THREE.MathUtils.lerp(torsoGroup.rotation.x, 0.14, r);
    headGroup.rotation.x = THREE.MathUtils.lerp(headGroup.rotation.x, 0.42, r);
    headGroup.rotation.y = THREE.MathUtils.lerp(headGroup.rotation.y, 0.04, r);

    rightArm.shoulder.rotation.x = THREE.MathUtils.lerp(walkSwingX, -0.58, r);
    rightArm.shoulder.rotation.y = THREE.MathUtils.lerp(0, -0.08, r);
    rightArm.shoulder.rotation.z = THREE.MathUtils.lerp(0.05, -0.04, r);
    rightArm.elbow.rotation.x = THREE.MathUtils.lerp(walkBendX, -0.45, r);

    root.updateMatrixWorld(true);
    rightArm.hand.getWorldPosition(_handPos);
    rightArm.elbow.getWorldQuaternion(_invQuat).invert();
    _targetLocal.copy(targetWorld).sub(_handPos).applyQuaternion(_invQuat).normalize();

    const aimPitch = Math.atan2(-_targetLocal.y, Math.max(0.05, _targetLocal.z));
    const aimYaw = Math.atan2(_targetLocal.x, Math.max(0.05, _targetLocal.z));

    rightArm.hand.rotation.x = THREE.MathUtils.lerp(0.35, aimPitch, r);
    rightArm.hand.rotation.y = THREE.MathUtils.lerp(0, aimYaw, r);

    flashlightLensMat.emissiveIntensity = on * 3.8;
    flashlightAccentMat.emissiveIntensity = 0.2 + on * 2.2;
  };

  // Friendly greeting animation for First-Login interactive student character
  const updateGreeting = (elapsed: number, waving: boolean) => {
    bodyGroup.position.y = 0.96 + Math.sin(elapsed * 2.2) * 0.009;
    torsoGroup.rotation.y = Math.sin(elapsed * 1.1) * 0.06;
    torsoGroup.rotation.x = 0.02;
    headGroup.rotation.y = Math.sin(elapsed * 1.4) * 0.12;
    headGroup.rotation.x = Math.sin(elapsed * 1.8) * 0.04;

    leftArm.shoulder.rotation.set(0.08, 0, -0.08);
    leftArm.elbow.rotation.set(-0.25, 0, 0);

    if (waving) {
      rightArm.shoulder.rotation.set(-0.25, 0.15, 2.35 + Math.sin(elapsed * 5.2) * 0.12);
      rightArm.elbow.rotation.set(-0.4, 0, -0.5 + Math.sin(elapsed * 5.2) * 0.35);
      rightArm.hand.rotation.set(0, 0, Math.sin(elapsed * 5.2) * 0.22);
    } else {
      rightArm.shoulder.rotation.set(-0.15, 0, 0.14);
      rightArm.elbow.rotation.set(-0.35, 0, 0);
      rightArm.hand.rotation.set(0, 0, 0);
    }
  };

  const getFlashlightWorldPose = (originOut: THREE.Vector3, dirOut: THREE.Vector3) => {
    root.updateMatrixWorld(true);
    flashlightLensNode.getWorldPosition(originOut);
    flashlightLensNode.getWorldQuaternion(_lensQuat);
    dirOut.set(0, 0, 1).applyQuaternion(_lensQuat).normalize();
  };

  const dispose = () => {
    geometries.forEach((g) => g.dispose());
    materials.forEach((m) => m.dispose());
    textures.forEach((t) => t.dispose());
  };

  return {
    root,
    flashlightLensNode,
    contactShadow,
    updateWalk,
    updateFlashlightAim,
    updateGreeting,
    getFlashlightWorldPose,
    dispose,
  };
}
