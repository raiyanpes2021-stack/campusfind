import * as THREE from 'three';

export interface RealisticStudentRig {
  root: THREE.Group;
  update: (
    elapsed: number,
    delta: number,
    pointerX: number,
    pointerY: number,
    isSpeaking: boolean
  ) => void;
  dispose: () => void;
}

function createSkinTextures(): {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
  roughnessMap: THREE.CanvasTexture;
} {
  const size = 512;
  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = size;
  colorCanvas.height = size;
  const cCtx = colorCanvas.getContext('2d')!;

  // Natural warm medium-brown South Asian / Mediterranean college student skin tone
  const grad = cCtx.createLinearGradient(0, 0, 0, size);
  grad.addColorStop(0, '#c69270');
  grad.addColorStop(0.45, '#be8866');
  grad.addColorStop(0.75, '#b67f5e');
  grad.addColorStop(1, '#aa7353');
  cCtx.fillStyle = grad;
  cCtx.fillRect(0, 0, size, size);

  // Subtle natural warmth across cheeks & nose bridge
  const cheekL = cCtx.createRadialGradient(size * 0.34, size * 0.56, 8, size * 0.34, size * 0.56, 78);
  cheekL.addColorStop(0, 'rgba(188, 102, 78, 0.22)');
  cheekL.addColorStop(1, 'rgba(188, 102, 78, 0)');
  cCtx.fillStyle = cheekL;
  cCtx.fillRect(0, 0, size, size);

  const cheekR = cCtx.createRadialGradient(size * 0.66, size * 0.56, 8, size * 0.66, size * 0.56, 78);
  cheekR.addColorStop(0, 'rgba(188, 102, 78, 0.22)');
  cheekR.addColorStop(1, 'rgba(188, 102, 78, 0)');
  cCtx.fillStyle = cheekR;
  cCtx.fillRect(0, 0, size, size);

  // Subtle natural jaw stubble shadow
  const beard = cCtx.createRadialGradient(size * 0.5, size * 0.78, 16, size * 0.5, size * 0.76, 130);
  beard.addColorStop(0, 'rgba(58, 42, 34, 0.16)');
  beard.addColorStop(0.6, 'rgba(58, 42, 34, 0.08)');
  beard.addColorStop(1, 'rgba(58, 42, 34, 0)');
  cCtx.fillStyle = beard;
  cCtx.fillRect(0, 0, size, size);

  // Fine organic skin variation
  for (let i = 0; i < 4200; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const alpha = 0.025 + Math.random() * 0.03;
    cCtx.fillStyle = i % 2 === 0 ? `rgba(255,220,196,${alpha})` : `rgba(110,68,45,${alpha})`;
    cCtx.fillRect(x, y, 1.5, 1.5);
  }

  // Bump & roughness micro-pore maps
  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = size;
  bumpCanvas.height = size;
  const bCtx = bumpCanvas.getContext('2d')!;
  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, size, size);

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;
  rCtx.fillStyle = '#9a9a9a';
  rCtx.fillRect(0, 0, size, size);

  // Slightly oilier forehead/nose T-zone (lower roughness)
  const tZone = rCtx.createRadialGradient(size * 0.5, size * 0.45, 10, size * 0.5, size * 0.45, 120);
  tZone.addColorStop(0, 'rgba(118, 118, 118, 0.7)');
  tZone.addColorStop(1, 'rgba(154, 154, 154, 0)');
  rCtx.fillStyle = tZone;
  rCtx.fillRect(0, 0, size, size);

  for (let i = 0; i < 7000; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const v = 112 + Math.floor(Math.random() * 34);
    bCtx.fillStyle = `rgb(${v},${v},${v})`;
    bCtx.fillRect(x, y, 1.5, 1.5);
  }

  const map = new THREE.CanvasTexture(colorCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.anisotropy = 4;

  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  const roughnessMap = new THREE.CanvasTexture(roughCanvas);

  return { map, bumpMap, roughnessMap };
}

function createIrisTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const cx = size / 2;
  const cy = size / 2;

  // Sclera base
  ctx.fillStyle = '#f2ede6';
  ctx.fillRect(0, 0, size, size);

  // Subtle sclera shading around iris edge
  const scleraShade = ctx.createRadialGradient(cx, cy, size * 0.16, cx, cy, size * 0.48);
  scleraShade.addColorStop(0, 'rgba(205, 190, 178, 0.35)');
  scleraShade.addColorStop(1, 'rgba(205, 190, 178, 0)');
  ctx.fillStyle = scleraShade;
  ctx.fillRect(0, 0, size, size);

  // Dark limbal ring
  ctx.beginPath();
  ctx.arc(cx, cy, size * 0.23, 0, Math.PI * 2);
  ctx.fillStyle = '#1f1510';
  ctx.fill();

  // Warm dark-hazel/brown iris gradient
  const irisGrad = ctx.createRadialGradient(cx, cy, size * 0.08, cx, cy, size * 0.21);
  irisGrad.addColorStop(0, '#5a3a22');
  irisGrad.addColorStop(0.55, '#3f2616');
  irisGrad.addColorStop(1, '#26170e');
  ctx.beginPath();
  ctx.arc(cx, cy, size * 0.21, 0, Math.PI * 2);
  ctx.fillStyle = irisGrad;
  ctx.fill();

  // Fine radial iris fibers
  for (let i = 0; i < 96; i++) {
    const a = (i / 96) * Math.PI * 2;
    ctx.strokeStyle = i % 3 === 0 ? 'rgba(138, 96, 56, 0.35)' : 'rgba(30, 18, 10, 0.28)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * size * 0.09, cy + Math.sin(a) * size * 0.09);
    ctx.lineTo(cx + Math.cos(a) * size * 0.205, cy + Math.sin(a) * size * 0.205);
    ctx.stroke();
  }

  // Deep black pupil
  ctx.beginPath();
  ctx.arc(cx, cy, size * 0.095, 0, Math.PI * 2);
  ctx.fillStyle = '#080707';
  ctx.fill();

  // Crisp studio catchlight
  ctx.beginPath();
  ctx.arc(cx + size * 0.048, cy - size * 0.052, size * 0.026, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255, 252, 245, 0.92)';
  ctx.fill();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createFabricTextures(baseHex: string): {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
} {
  const size = 256;
  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = size;
  colorCanvas.height = size;
  const ctx = colorCanvas.getContext('2d')!;
  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, size, size);

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = size;
  bumpCanvas.height = size;
  const bCtx = bumpCanvas.getContext('2d')!;
  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, size, size);

  // Subtle woven cotton knit grain
  for (let y = 0; y < size; y += 3) {
    ctx.fillStyle = y % 6 === 0 ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.04)';
    ctx.fillRect(0, y, size, 1);
    bCtx.fillStyle = y % 6 === 0 ? '#909090' : '#707070';
    bCtx.fillRect(0, y, size, 1);
  }
  for (let x = 0; x < size; x += 4) {
    ctx.fillStyle = x % 8 === 0 ? 'rgba(255,255,255,0.02)' : 'rgba(0,0,0,0.03)';
    ctx.fillRect(x, 0, 1, size);
    bCtx.fillStyle = x % 8 === 0 ? '#8c8c8c' : '#747474';
    bCtx.fillRect(x, 0, 1, size);
  }

  const map = new THREE.CanvasTexture(colorCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(4, 4);

  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  bumpMap.wrapS = THREE.RepeatWrapping;
  bumpMap.wrapT = THREE.RepeatWrapping;
  bumpMap.repeat.set(4, 4);

  return { map, bumpMap };
}

function createHairBumpTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#7c7c7c';
  ctx.fillRect(0, 0, size, size);

  for (let x = 0; x < size; x += 2) {
    const shade = 95 + Math.floor(Math.sin(x * 0.45) * 28 + Math.random() * 24);
    ctx.fillStyle = `rgb(${shade},${shade},${shade})`;
    ctx.fillRect(x, 0, 1.5, size);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(3, 2);
  return tex;
}

/**
 * Sculpt an anatomically proportioned adult male head using vertex-displaced high-res sphere.
 */
function createSculptedHeadGeometry(): THREE.BufferGeometry {
  const geo = new THREE.SphereGeometry(0.108, 48, 40);
  const pos = geo.attributes.position;
  const v = new THREE.Vector3();

  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i);
    const nx = v.x / 0.108;
    const ny = v.y / 0.108;
    const nz = v.z / 0.108;

    // Elongate head vertically to natural adult cranial proportions
    v.y *= 1.18;
    v.x *= 0.88;
    v.z *= 0.96;

    // Taper lower jaw & chin cleanly
    if (ny < 0) {
      const jawFactor = Math.abs(ny);
      v.x *= 1 - jawFactor * 0.24;
      if (nz > 0) {
        // Subtle chin projection
        const chin = Math.exp(-Math.pow(nx * 2.6, 2)) * Math.exp(-Math.pow((ny + 0.82) * 3.4, 2));
        v.z += chin * 0.014;
      }
      // Jawline angle near sides
      const jawCorner =
        Math.exp(-Math.pow((Math.abs(nx) - 0.65) * 3.4, 2)) *
        Math.exp(-Math.pow((ny + 0.48) * 3.5, 2)) *
        Math.max(0, nz + 0.25);
      v.x += Math.sign(nx) * jawCorner * 0.008;
    }

    // Subtle brow ridge & eye socket recess
    if (nz > 0.3) {
      const brow =
        Math.exp(-Math.pow((ny - 0.22) * 5.2, 2)) *
        Math.exp(-Math.pow(nx * 1.45, 2)) *
        nz;
      v.z += brow * 0.009;

      const eyeSocketL =
        Math.exp(-Math.pow((nx + 0.34) * 5.5, 2)) * Math.exp(-Math.pow((ny - 0.06) * 6.5, 2));
      const eyeSocketR =
        Math.exp(-Math.pow((nx - 0.34) * 5.5, 2)) * Math.exp(-Math.pow((ny - 0.06) * 6.5, 2));
      v.z -= (eyeSocketL + eyeSocketR) * 0.012;

      // Cheekbone contour
      const cheekL =
        Math.exp(-Math.pow((nx + 0.52) * 3.6, 2)) * Math.exp(-Math.pow((ny + 0.14) * 4.2, 2));
      const cheekR =
        Math.exp(-Math.pow((nx - 0.52) * 3.6, 2)) * Math.exp(-Math.pow((ny + 0.14) * 4.2, 2));
      v.z += (cheekL + cheekR) * 0.0085;
      v.x += (cheekR - cheekL) * 0.006;

      // Subtle philtrum & mouth mound
      const mouthMound =
        Math.exp(-Math.pow(nx * 3.4, 2)) * Math.exp(-Math.pow((ny + 0.44) * 4.5, 2));
      v.z += mouthMound * 0.009;
    }

    // Back of skull occiput shape
    if (nz < -0.25 && ny > -0.2) {
      v.z -= Math.exp(-Math.pow((ny - 0.12) * 2.2, 2)) * 0.012;
    }

    pos.setXYZ(i, v.x, v.y, v.z);
  }

  geo.computeVertexNormals();
  return geo;
}

/**
 * Sculpt a realistic 5-finger adult male hand with wrist, palm, thumb, and 4 articulated fingers.
 */
function createArticulatedHand(
  side: -1 | 1,
  skinMat: THREE.Material,
  geometries: THREE.BufferGeometry[]
): THREE.Group {
  const hand = new THREE.Group();

  // Sculpted palm
  const palmGeo = new THREE.BoxGeometry(0.068, 0.078, 0.025, 4, 4, 2);
  geometries.push(palmGeo);
  const palm = new THREE.Mesh(palmGeo, skinMat);
  palm.position.set(0, -0.042, 0);
  palm.castShadow = true;
  hand.add(palm);

  // Rounded knuckles ridge
  const knuckleGeo = new THREE.CapsuleGeometry(0.011, 0.048, 6, 10);
  geometries.push(knuckleGeo);
  const knuckle = new THREE.Mesh(knuckleGeo, skinMat);
  knuckle.rotation.z = Math.PI / 2;
  knuckle.position.set(0, -0.08, 0.002);
  hand.add(knuckle);

  // Four natural fingers (index, middle, ring, pinky)
  const fingerSpecs = [
    { x: side * 0.023, len1: 0.032, len2: 0.026, r: 0.0075, curl: 0.16 },
    { x: side * 0.008, len1: 0.036, len2: 0.028, r: 0.0078, curl: 0.18 },
    { x: -side * 0.008, len1: 0.033, len2: 0.025, r: 0.0074, curl: 0.22 },
    { x: -side * 0.022, len1: 0.026, len2: 0.02, r: 0.0066, curl: 0.26 },
  ];

  for (const f of fingerSpecs) {
    const fBase = new THREE.Group();
    fBase.position.set(f.x, -0.08, 0.002);
    fBase.rotation.x = f.curl;

    const seg1Geo = new THREE.CapsuleGeometry(f.r, f.len1, 6, 10);
    geometries.push(seg1Geo);
    const seg1 = new THREE.Mesh(seg1Geo, skinMat);
    seg1.position.y = -f.len1 * 0.5;
    seg1.castShadow = true;
    fBase.add(seg1);

    const fMid = new THREE.Group();
    fMid.position.y = -f.len1 - 0.004;
    fMid.rotation.x = f.curl * 1.15;

    const seg2Geo = new THREE.CapsuleGeometry(f.r * 0.88, f.len2, 6, 10);
    geometries.push(seg2Geo);
    const seg2 = new THREE.Mesh(seg2Geo, skinMat);
    seg2.position.y = -f.len2 * 0.5;
    seg2.castShadow = true;
    fMid.add(seg2);

    fBase.add(fMid);
    hand.add(fBase);
  }

  // Opposable thumb
  const thumbBase = new THREE.Group();
  thumbBase.position.set(side * 0.034, -0.032, 0.012);
  thumbBase.rotation.set(0.32, side * 0.35, -side * 0.52);

  const thumb1Geo = new THREE.CapsuleGeometry(0.0088, 0.026, 6, 10);
  geometries.push(thumb1Geo);
  const thumb1 = new THREE.Mesh(thumb1Geo, skinMat);
  thumb1.position.y = -0.015;
  thumb1.castShadow = true;
  thumbBase.add(thumb1);

  const thumb2Geo = new THREE.CapsuleGeometry(0.0078, 0.021, 6, 10);
  geometries.push(thumb2Geo);
  const thumb2 = new THREE.Mesh(thumb2Geo, skinMat);
  thumb2.position.set(0, -0.036, 0.005);
  thumb2.rotation.x = 0.25;
  thumb2.castShadow = true;
  thumbBase.add(thumb2);

  hand.add(thumbBase);

  return hand;
}

export function createRealisticStudentCharacter(): RealisticStudentRig {
  const root = new THREE.Group();
  const geometries: THREE.BufferGeometry[] = [];
  const materials: THREE.Material[] = [];
  const textures: THREE.Texture[] = [];

  const trackGeo = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const trackMat = <T extends THREE.Material>(m: T): T => {
    materials.push(m);
    return m;
  };

  // Procedural PBR textures
  const skinTex = createSkinTextures();
  textures.push(skinTex.map, skinTex.bumpMap, skinTex.roughnessMap);

  const irisTex = createIrisTexture();
  textures.push(irisTex);

  const hoodieTex = createFabricTextures('#174C4A');
  textures.push(hoodieTex.map, hoodieTex.bumpMap);

  const pantsTex = createFabricTextures('#283134');
  textures.push(pantsTex.map, pantsTex.bumpMap);

  const hairBump = createHairBumpTexture();
  textures.push(hairBump);

  // Materials
  const skinMat = trackMat(
    new THREE.MeshPhysicalMaterial({
      map: skinTex.map,
      bumpMap: skinTex.bumpMap,
      bumpScale: 0.0014,
      roughnessMap: skinTex.roughnessMap,
      roughness: 0.56,
      metalness: 0.0,
      sheen: 0.25,
      sheenRoughness: 0.65,
      sheenColor: new THREE.Color('#e3b193'),
    })
  );

  const lipMat = trackMat(
    new THREE.MeshPhysicalMaterial({
      color: '#9c5c4c',
      roughness: 0.42,
      metalness: 0.0,
      clearcoat: 0.12,
      clearcoatRoughness: 0.5,
    })
  );

  const eyeMat = trackMat(
    new THREE.MeshPhysicalMaterial({
      map: irisTex,
      roughness: 0.08,
      metalness: 0.0,
      clearcoat: 1.0,
      clearcoatRoughness: 0.04,
    })
  );

  const hairMat = trackMat(
    new THREE.MeshPhysicalMaterial({
      color: '#1b1614',
      bumpMap: hairBump,
      bumpScale: 0.0032,
      roughness: 0.52,
      metalness: 0.04,
      sheen: 0.45,
      sheenRoughness: 0.42,
      sheenColor: new THREE.Color('#473b36'),
    })
  );

  const hoodieMat = trackMat(
    new THREE.MeshPhysicalMaterial({
      map: hoodieTex.map,
      bumpMap: hoodieTex.bumpMap,
      bumpScale: 0.0025,
      roughness: 0.86,
      metalness: 0.0,
      sheen: 0.42,
      sheenRoughness: 0.78,
      sheenColor: new THREE.Color('#2a6d6a'),
    })
  );

  const hoodieRibMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#123e3c',
      roughness: 0.9,
      metalness: 0.0,
    })
  );

  const innerTeeMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#EFEAE0',
      roughness: 0.88,
      metalness: 0.0,
    })
  );

  const drawstringMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#F4F1E8',
      roughness: 0.78,
    })
  );

  const metalAgletMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#b8b2a5',
      roughness: 0.28,
      metalness: 0.82,
    })
  );

  const backpackMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#322d2a',
      roughness: 0.84,
      metalness: 0.02,
    })
  );

  const strapAccentMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: '#D98252',
      roughness: 0.76,
    })
  );

  const pantsMat = trackMat(
    new THREE.MeshStandardMaterial({
      map: pantsTex.map,
      bumpMap: pantsTex.bumpMap,
      bumpScale: 0.002,
      roughness: 0.88,
    })
  );

  // === SKELETAL HIERARCHY ===
  const hips = new THREE.Group();
  hips.position.y = 0.96;
  root.add(hips);

  // Pelvis / upper trousers (visible in waist-up / three-quarter framing)
  const pelvis = new THREE.Mesh(trackGeo(new THREE.CylinderGeometry(0.155, 0.162, 0.16, 24)), pantsMat);
  pelvis.position.y = -0.05;
  pelvis.scale.set(1.06, 1, 0.76);
  pelvis.castShadow = true;
  hips.add(pelvis);

  for (const side of [-1, 1] as const) {
    const thigh = new THREE.Mesh(
      trackGeo(new THREE.CylinderGeometry(0.082, 0.068, 0.44, 18)),
      pantsMat
    );
    thigh.position.set(side * 0.088, -0.32, 0);
    thigh.castShadow = true;
    hips.add(thigh);
  }

  // Spine & Chest
  const spine = new THREE.Group();
  spine.position.y = 0.02;
  hips.add(spine);

  const chest = new THREE.Group();
  chest.position.y = 0.22;
  spine.add(chest);

  // Hoodie torso — sculpted natural drape with tapered athletic waist and broad shoulders
  const torsoGeo = trackGeo(new THREE.CylinderGeometry(0.195, 0.168, 0.46, 32, 12));
  const tPos = torsoGeo.attributes.position;
  for (let i = 0; i < tPos.count; i++) {
    const x = tPos.getX(i);
    const y = tPos.getY(i);
    const z = tPos.getZ(i);
    // Natural chest depth & subtle fabric fold
    const fold = Math.sin(y * 18 + x * 12) * 0.003;
    const chestBoost = y > 0.02 && z > 0 ? 1.12 : 1.0;
    tPos.setXYZ(i, x * 1.14 + fold, y, z * 0.72 * chestBoost + fold);
  }
  torsoGeo.computeVertexNormals();
  const torsoMesh = new THREE.Mesh(torsoGeo, hoodieMat);
  torsoMesh.position.y = 0.02;
  torsoMesh.castShadow = true;
  torsoMesh.receiveShadow = true;
  chest.add(torsoMesh);

  // Bottom ribbed hem of hoodie
  const hem = new THREE.Mesh(trackGeo(new THREE.CylinderGeometry(0.172, 0.166, 0.06, 28)), hoodieRibMat);
  hem.scale.set(1.12, 1, 0.74);
  hem.position.y = -0.21;
  chest.add(hem);

  // Kangaroo front pocket with subtle stitched edge
  const pocket = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(0.24, 0.125, 0.036)), hoodieMat);
  pocket.position.set(0, -0.1, 0.122);
  pocket.castShadow = true;
  chest.add(pocket);

  // Shoulder slope yoke
  const shoulderYoke = new THREE.Mesh(
    trackGeo(new THREE.CapsuleGeometry(0.095, 0.25, 12, 20)),
    hoodieMat
  );
  shoulderYoke.rotation.z = Math.PI / 2;
  shoulderYoke.scale.set(0.84, 1, 0.85);
  shoulderYoke.position.set(0, 0.22, -0.005);
  shoulderYoke.castShadow = true;
  chest.add(shoulderYoke);

  // Inner Warm Ivory crew-neck collar peek
  const teeCollar = new THREE.Mesh(
    trackGeo(new THREE.TorusGeometry(0.072, 0.014, 12, 28)),
    innerTeeMat
  );
  teeCollar.rotation.x = Math.PI / 2 + 0.18;
  teeCollar.position.set(0, 0.275, 0.024);
  chest.add(teeCollar);

  // Draped hoodie collar & resting hood behind neck
  const hoodCollar = new THREE.Mesh(
    trackGeo(new THREE.TorusGeometry(0.098, 0.032, 14, 32)),
    hoodieMat
  );
  hoodCollar.rotation.x = Math.PI / 2 + 0.24;
  hoodCollar.position.set(0, 0.272, 0.0);
  hoodCollar.castShadow = true;
  chest.add(hoodCollar);

  const hoodBack = new THREE.Mesh(
    trackGeo(new THREE.SphereGeometry(0.11, 20, 16)),
    hoodieMat
  );
  hoodBack.scale.set(1.12, 0.65, 0.78);
  hoodBack.position.set(0, 0.24, -0.095);
  chest.add(hoodBack);

  // Hoodie drawstrings with metallic aglets
  for (const side of [-1, 1] as const) {
    const cord = new THREE.Mesh(
      trackGeo(new THREE.CylinderGeometry(0.0038, 0.0038, 0.145, 8)),
      drawstringMat
    );
    cord.position.set(side * 0.036, 0.168, 0.132);
    cord.rotation.z = side * 0.04;
    cord.rotation.x = -0.14;
    chest.add(cord);

    const aglet = new THREE.Mesh(
      trackGeo(new THREE.CylinderGeometry(0.0044, 0.0042, 0.016, 8)),
      metalAgletMat
    );
    aglet.position.set(side * 0.039, 0.092, 0.142);
    chest.add(aglet);
  }

  // Realistic college backpack straps draped cleanly over shoulders
  for (const side of [-1, 1] as const) {
    const strapCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(side * 0.145, 0.265, -0.09),
      new THREE.Vector3(side * 0.155, 0.292, 0.01),
      new THREE.Vector3(side * 0.152, 0.16, 0.128),
      new THREE.Vector3(side * 0.162, -0.02, 0.118),
      new THREE.Vector3(side * 0.178, -0.14, -0.02),
    ]);
    const strapMesh = new THREE.Mesh(
      trackGeo(new THREE.TubeGeometry(strapCurve, 24, 0.021, 10, false)),
      backpackMat
    );
    strapMesh.scale.set(1.15, 1, 0.42);
    strapMesh.castShadow = true;
    chest.add(strapMesh);

    const buckle = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(0.046, 0.022, 0.014)), strapAccentMat);
    buckle.position.set(side * 0.156, 0.04, 0.132);
    chest.add(buckle);
  }

  // Backpack body behind torso
  const backpackBody = new THREE.Mesh(
    trackGeo(new THREE.BoxGeometry(0.28, 0.36, 0.11)),
    backpackMat
  );
  backpackBody.position.set(0, 0.05, -0.175);
  backpackBody.castShadow = true;
  chest.add(backpackBody);

  // === NECK & HEAD ===
  const neck = new THREE.Group();
  neck.position.set(0, 0.295, 0.008);
  chest.add(neck);

  // Anatomically tapered neck
  const neckMesh = new THREE.Mesh(
    trackGeo(new THREE.CylinderGeometry(0.052, 0.062, 0.115, 22)),
    skinMat
  );
  neckMesh.position.y = 0.032;
  neckMesh.castShadow = true;
  neck.add(neckMesh);

  const head = new THREE.Group();
  head.position.set(0, 0.125, 0.008);
  neck.add(head);

  // Sculpted adult male head
  const headMesh = new THREE.Mesh(trackGeo(createSculptedHeadGeometry()), skinMat);
  headMesh.castShadow = true;
  headMesh.receiveShadow = true;
  head.add(headMesh);

  // Sculpted Nose (bridge + tip + subtle alar wings)
  const noseBridge = new THREE.Mesh(trackGeo(new THREE.CapsuleGeometry(0.011, 0.03, 8, 12)), skinMat);
  noseBridge.position.set(0, -0.006, 0.098);
  noseBridge.rotation.x = -0.22;
  head.add(noseBridge);

  const noseTip = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.0135, 16, 14)), skinMat);
  noseTip.scale.set(1.05, 0.82, 1.0);
  noseTip.position.set(0, -0.022, 0.107);
  head.add(noseTip);

  for (const side of [-1, 1] as const) {
    const nostrilWing = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.0085, 12, 10)), skinMat);
    nostrilWing.scale.set(1.0, 0.72, 0.85);
    nostrilWing.position.set(side * 0.011, -0.025, 0.099);
    head.add(nostrilWing);
  }

  // Realistic Ears (helix + inner concha + lobe)
  for (const side of [-1, 1] as const) {
    const earGroup = new THREE.Group();
    earGroup.position.set(side * 0.095, -0.008, -0.008);
    earGroup.rotation.y = side * 0.22;
    earGroup.rotation.z = -side * 0.08;

    const outerEar = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.024, 16, 14)), skinMat);
    outerEar.scale.set(0.38, 1.08, 0.68);
    earGroup.add(outerEar);

    const earLobe = new THREE.Mesh(trackGeo(new THREE.SphereGeometry(0.011, 12, 10)), skinMat);
    earLobe.scale.set(0.45, 0.85, 0.65);
    earLobe.position.set(0, -0.02, 0.002);
    earGroup.add(earLobe);

    head.add(earGroup);
  }

  // Realistic Eyes + Articulated Eyelids + Eyebrows
  const leftEyePivot = new THREE.Group();
  leftEyePivot.position.set(-0.032, 0.012, 0.086);
  head.add(leftEyePivot);

  const rightEyePivot = new THREE.Group();
  rightEyePivot.position.set(0.032, 0.012, 0.086);
  head.add(rightEyePivot);

  const eyeballGeo = trackGeo(new THREE.SphereGeometry(0.0132, 20, 18));
  const leftEye = new THREE.Mesh(eyeballGeo, eyeMat);
  leftEye.rotation.y = -Math.PI / 2;
  leftEyePivot.add(leftEye);

  const rightEye = new THREE.Mesh(eyeballGeo, eyeMat);
  rightEye.rotation.y = -Math.PI / 2;
  rightEyePivot.add(rightEye);

  // Upper eyelids for smooth natural blinking
  const upperLidGeo = trackGeo(
    new THREE.SphereGeometry(0.0148, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.56)
  );
  const leftUpperLid = new THREE.Mesh(upperLidGeo, skinMat);
  leftUpperLid.position.copy(leftEyePivot.position);
  leftUpperLid.rotation.x = -0.58;
  head.add(leftUpperLid);

  const rightUpperLid = new THREE.Mesh(upperLidGeo, skinMat);
  rightUpperLid.position.copy(rightEyePivot.position);
  rightUpperLid.rotation.x = -0.58;
  head.add(rightUpperLid);

  // Subtle lower eyelid crease
  const lowerLidGeo = trackGeo(
    new THREE.SphereGeometry(0.0145, 16, 10, 0, Math.PI * 2, Math.PI * 0.64, Math.PI * 0.36)
  );
  const leftLowerLid = new THREE.Mesh(lowerLidGeo, skinMat);
  leftLowerLid.position.copy(leftEyePivot.position);
  head.add(leftLowerLid);

  const rightLowerLid = new THREE.Mesh(lowerLidGeo, skinMat);
  rightLowerLid.position.copy(rightEyePivot.position);
  head.add(rightLowerLid);

  // Natural contoured eyebrows
  for (const side of [-1, 1] as const) {
    const browCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(side * 0.013, 0.033, 0.095),
      new THREE.Vector3(side * 0.032, 0.038, 0.094),
      new THREE.Vector3(side * 0.053, 0.032, 0.083),
    ]);
    const browMesh = new THREE.Mesh(
      trackGeo(new THREE.TubeGeometry(browCurve, 12, 0.0042, 8, false)),
      hairMat
    );
    browMesh.scale.set(1, 0.72, 0.65);
    head.add(browMesh);
  }

  // Sculpted Upper & Lower Lips with subtle speaking articulation
  const upperLipCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.023, -0.049, 0.089),
    new THREE.Vector3(-0.008, -0.0455, 0.099),
    new THREE.Vector3(0, -0.0475, 0.1),
    new THREE.Vector3(0.008, -0.0455, 0.099),
    new THREE.Vector3(0.023, -0.049, 0.089),
  ]);
  const upperLip = new THREE.Mesh(
    trackGeo(new THREE.TubeGeometry(upperLipCurve, 16, 0.0048, 8, false)),
    lipMat
  );
  upperLip.scale.set(1, 0.85, 0.85);
  head.add(upperLip);

  const lowerLipPivot = new THREE.Group();
  lowerLipPivot.position.set(0, -0.054, 0.093);
  head.add(lowerLipPivot);

  const lowerLipCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.021, 0.004, -0.004),
    new THREE.Vector3(0, -0.002, 0.007),
    new THREE.Vector3(0.021, 0.004, -0.004),
  ]);
  const lowerLip = new THREE.Mesh(
    trackGeo(new THREE.TubeGeometry(lowerLipCurve, 16, 0.0056, 8, false)),
    lipMat
  );
  lowerLip.scale.set(1, 0.88, 0.88);
  lowerLipPivot.add(lowerLip);

  // === LAYERED NATURAL HAIR (Modern short-tapered college haircut) ===
  const hairGroup = new THREE.Group();
  head.add(hairGroup);

  // Main hair cap hugging the crown & back
  const hairCapGeo = trackGeo(
    new THREE.SphereGeometry(0.112, 36, 28, 0, Math.PI * 2, 0, Math.PI * 0.62)
  );
  const hcPos = hairCapGeo.attributes.position;
  for (let i = 0; i < hcPos.count; i++) {
    const x = hcPos.getX(i);
    const y = hcPos.getY(i);
    const z = hcPos.getZ(i);
    // Natural volume at crown and slight lift at front hairline
    const wave = Math.sin(x * 42 + z * 34) * 0.0022;
    hcPos.setXYZ(i, x * 0.91 + wave, y * 1.15 + 0.015, z * 1.0 - 0.008);
  }
  hairCapGeo.computeVertexNormals();
  const hairCap = new THREE.Mesh(hairCapGeo, hairMat);
  hairCap.castShadow = true;
  hairGroup.add(hairCap);

  // Tapered back-of-head hair fade
  const backHair = new THREE.Mesh(
    trackGeo(new THREE.SphereGeometry(0.104, 24, 18)),
    hairMat
  );
  backHair.scale.set(0.88, 0.85, 0.72);
  backHair.position.set(0, 0.005, -0.036);
  hairGroup.add(backHair);

  // Layered textured front-sweep locks (natural side-parted volume, not blocky)
  const strandConfigs = [
    { start: [-0.045, 0.095, 0.055], mid: [-0.005, 0.114, 0.088], end: [0.045, 0.092, 0.084], r: 0.019 },
    { start: [-0.055, 0.082, 0.068], mid: [-0.015, 0.1, 0.095], end: [0.035, 0.082, 0.092], r: 0.016 },
    { start: [-0.025, 0.108, 0.035], mid: [0.02, 0.124, 0.065], end: [0.066, 0.096, 0.062], r: 0.018 },
    { start: [-0.072, 0.078, 0.032], mid: [-0.082, 0.062, 0.052], end: [-0.078, 0.032, 0.048], r: 0.014 },
    { start: [0.052, 0.095, 0.045], mid: [0.076, 0.074, 0.055], end: [0.082, 0.036, 0.045], r: 0.015 },
    { start: [-0.01, 0.118, 0.01], mid: [0.03, 0.128, 0.035], end: [0.074, 0.102, 0.028], r: 0.017 },
  ];

  for (const s of strandConfigs) {
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(...s.start),
      new THREE.Vector3(...s.mid),
      new THREE.Vector3(...s.end),
    ]);
    const lock = new THREE.Mesh(
      trackGeo(new THREE.TubeGeometry(curve, 14, s.r, 10, false)),
      hairMat
    );
    lock.scale.set(1, 0.72, 0.85);
    lock.castShadow = true;
    hairGroup.add(lock);
  }

  // Sideburns
  for (const side of [-1, 1] as const) {
    const sideburn = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(0.012, 0.038, 0.018)), hairMat);
    sideburn.position.set(side * 0.089, 0.014, 0.014);
    hairGroup.add(sideburn);
  }

  // === ARMS & ARTICULATED 5-FINGER HANDS ===
  // Left Arm (relaxed natural posture)
  const leftShoulder = new THREE.Group();
  leftShoulder.position.set(-0.225, 0.215, 0.0);
  chest.add(leftShoulder);

  const upperArmGeo = trackGeo(new THREE.CapsuleGeometry(0.056, 0.21, 10, 18));
  const forearmGeo = trackGeo(new THREE.CapsuleGeometry(0.047, 0.19, 10, 16));
  const cuffGeo = trackGeo(new THREE.CylinderGeometry(0.043, 0.04, 0.048, 16));
  const wristGeo = trackGeo(new THREE.CylinderGeometry(0.032, 0.034, 0.035, 14));

  const leftUpperArm = new THREE.Mesh(upperArmGeo, hoodieMat);
  leftUpperArm.position.y = -0.125;
  leftUpperArm.castShadow = true;
  leftShoulder.add(leftUpperArm);

  const leftElbow = new THREE.Group();
  leftElbow.position.set(0, -0.255, 0);
  leftShoulder.add(leftElbow);

  const leftForearm = new THREE.Mesh(forearmGeo, hoodieMat);
  leftForearm.position.y = -0.11;
  leftForearm.castShadow = true;
  leftElbow.add(leftForearm);

  const leftCuff = new THREE.Mesh(cuffGeo, hoodieRibMat);
  leftCuff.position.y = -0.215;
  leftElbow.add(leftCuff);

  const leftWrist = new THREE.Mesh(wristGeo, skinMat);
  leftWrist.position.y = -0.245;
  leftElbow.add(leftWrist);

  const leftHand = createArticulatedHand(-1, skinMat, geometries);
  leftHand.position.y = -0.262;
  leftElbow.add(leftHand);

  // Right Arm (natural calm conversational open-palm gesture)
  const rightShoulder = new THREE.Group();
  rightShoulder.position.set(0.225, 0.215, 0.0);
  chest.add(rightShoulder);

  const rightUpperArm = new THREE.Mesh(upperArmGeo, hoodieMat);
  rightUpperArm.position.y = -0.125;
  rightUpperArm.castShadow = true;
  rightShoulder.add(rightUpperArm);

  const rightElbow = new THREE.Group();
  rightElbow.position.set(0, -0.255, 0);
  rightShoulder.add(rightElbow);

  const rightForearm = new THREE.Mesh(forearmGeo, hoodieMat);
  rightForearm.position.y = -0.11;
  rightForearm.castShadow = true;
  rightElbow.add(rightForearm);

  const rightCuff = new THREE.Mesh(cuffGeo, hoodieRibMat);
  rightCuff.position.y = -0.215;
  rightElbow.add(rightCuff);

  const rightWrist = new THREE.Mesh(wristGeo, skinMat);
  rightWrist.position.y = -0.245;
  rightElbow.add(rightWrist);

  const rightHand = createArticulatedHand(1, skinMat, geometries);
  rightHand.position.y = -0.262;
  rightElbow.add(rightHand);

  // Natural initial resting pose
  leftShoulder.rotation.set(0.08, 0.05, 0.14);
  leftElbow.rotation.set(-0.34, 0, -0.08);
  rightShoulder.rotation.set(-0.24, -0.08, -0.18);
  rightElbow.rotation.set(-1.12, 0.16, 0.12);
  rightHand.rotation.set(0.18, -0.45, -0.12);

  // === NATURAL ANIMATION STATE (Zero per-frame allocations) ===
  let nextBlinkAt = 2.4;
  let blinkStart = -1;
  let currentHeadYaw = 0;
  let currentHeadPitch = 0;
  let currentEyeYaw = 0;
  let currentEyePitch = 0;

  const update = (
    elapsed: number,
    delta: number,
    pointerX: number,
    pointerY: number,
    isSpeaking: boolean
  ) => {
    const dt = Math.min(delta, 0.05);

    // 1. Calm physiological chest breathing (~0.24 Hz = ~14 breaths/min)
    const breath = Math.sin(elapsed * 1.5);
    chest.position.y = 0.22 + breath * 0.0045;
    chest.scale.set(1 + breath * 0.006, 1, 1 + breath * 0.01);
    spine.rotation.x = 0.02 + breath * 0.012;
    spine.rotation.y = Math.sin(elapsed * 0.42) * 0.032;

    // 2. Smooth eye contact & natural head tracking toward pointer
    const targetHeadYaw = THREE.MathUtils.clamp(pointerX * 0.28, -0.28, 0.28) + Math.sin(elapsed * 0.55) * 0.035;
    const targetHeadPitch = THREE.MathUtils.clamp(-pointerY * 0.16, -0.16, 0.16) + Math.sin(elapsed * 0.38) * 0.02;

    currentHeadYaw = THREE.MathUtils.damp(currentHeadYaw, targetHeadYaw, 4.2, dt);
    currentHeadPitch = THREE.MathUtils.damp(currentHeadPitch, targetHeadPitch, 4.2, dt);

    neck.rotation.y = currentHeadYaw * 0.42;
    neck.rotation.x = currentHeadPitch * 0.38;
    head.rotation.y = currentHeadYaw * 0.58;
    head.rotation.x = currentHeadPitch * 0.62;
    head.rotation.z = Math.sin(elapsed * 0.48) * 0.025;

    // Subtle eye saccade / gaze lead ahead of head turn
    const targetEyeYaw = THREE.MathUtils.clamp(pointerX * 0.22, -0.22, 0.22);
    const targetEyePitch = THREE.MathUtils.clamp(-pointerY * 0.14, -0.14, 0.14);
    currentEyeYaw = THREE.MathUtils.damp(currentEyeYaw, targetEyeYaw, 9, dt);
    currentEyePitch = THREE.MathUtils.damp(currentEyePitch, targetEyePitch, 9, dt);

    leftEyePivot.rotation.set(currentEyePitch, currentEyeYaw, 0);
    rightEyePivot.rotation.set(currentEyePitch, currentEyeYaw, 0);

    // 3. Natural irregular eyelid blink (~170ms duration)
    if (elapsed >= nextBlinkAt) {
      blinkStart = elapsed;
      nextBlinkAt = elapsed + 2.9 + ((Math.sin(elapsed * 13.7) * 0.5 + 0.5) * 2.2);
    }
    let blinkAmount = 0;
    if (blinkStart > 0) {
      const bt = elapsed - blinkStart;
      if (bt < 0.17) {
        blinkAmount = Math.sin((bt / 0.17) * Math.PI);
      } else {
        blinkStart = -1;
      }
    }
    const lidAngle = -0.58 + blinkAmount * 0.86;
    leftUpperLid.rotation.x = lidAngle;
    rightUpperLid.rotation.x = lidAngle;

    // 4. Subtle natural mouth articulation during greeting
    if (isSpeaking) {
      const talk =
        Math.max(0, Math.sin(elapsed * 5.2) * 0.5 + Math.sin(elapsed * 8.7) * 0.35 + 0.15);
      lowerLipPivot.position.y = -0.054 - talk * 0.0055;
      lowerLipPivot.rotation.x = talk * 0.12;
    } else {
      lowerLipPivot.position.y = THREE.MathUtils.damp(lowerLipPivot.position.y, -0.054, 8, dt);
      lowerLipPivot.rotation.x = THREE.MathUtils.damp(lowerLipPivot.rotation.x, 0, 8, dt);
    }

    // 5. Calm, natural conversational hand & shoulder gestures (non-cartoonish)
    const gesturePhase = Math.sin(elapsed * 1.15);
    const microPhase = Math.sin(elapsed * 0.72 + 1.1);

    rightShoulder.rotation.x = -0.24 + gesturePhase * 0.045;
    rightShoulder.rotation.z = -0.18 + microPhase * 0.025;
    rightElbow.rotation.x = -1.12 + gesturePhase * 0.08;
    rightHand.rotation.x = 0.18 + gesturePhase * 0.07;
    rightHand.rotation.z = -0.12 + microPhase * 0.05;

    leftShoulder.rotation.x = 0.08 - breath * 0.015;
    leftShoulder.rotation.z = 0.14 + breath * 0.012;
    leftElbow.rotation.x = -0.34 + microPhase * 0.03;
  };

  const dispose = () => {
    for (const g of geometries) g.dispose();
    for (const m of materials) m.dispose();
    for (const t of textures) t.dispose();
  };

  return { root, update, dispose };
}
