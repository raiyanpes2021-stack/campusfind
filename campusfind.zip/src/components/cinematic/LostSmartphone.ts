import * as THREE from 'three';

export interface LostSmartphoneRig {
  root: THREE.Group;
  screenCenterWorld: (out: THREE.Vector3) => THREE.Vector3;
  update: (params: {
    elapsed: number;
    beamHit: number;
    loginReveal: number;
    scanIntensity: number;
    riseProgress: number;
  }) => void;
  dispose: () => void;
}

const RIPPLE_VERTEX_SHADER = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const GROUND_RIPPLE_FRAGMENT = /* glsl */ `
  uniform float uTime;
  uniform float uScan;
  uniform float uFade;
  varying vec2 vUv;

  void main() {
    if (uScan <= 0.005 || uFade <= 0.005) discard;
    float d = distance(vUv, vec2(0.5));

    float wave1 = fract(uTime * 0.44);
    float wave2 = fract(uTime * 0.44 + 0.5);

    float r1 = wave1 * 0.46;
    float r2 = wave2 * 0.46;

    float ring1 = smoothstep(r1 - 0.02, r1, d) * (1.0 - smoothstep(r1, r1 + 0.018, d)) * (1.0 - wave1);
    float ring2 = smoothstep(r2 - 0.02, r2, d) * (1.0 - smoothstep(r2, r2 + 0.018, d)) * (1.0 - wave2);
    float halo = smoothstep(0.18, 0.0, d) * 0.38;

    float alpha = ((ring1 + ring2) * 0.65 + halo) * uScan * uFade;
    vec3 col = mix(vec3(0.85, 0.51, 0.32), vec3(0.09, 0.30, 0.29), ring2);
    gl_FragColor = vec4(col, clamp(alpha, 0.0, 0.85));
  }
`;

function createWarmPhoneLoginTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const w = 512;
  const h = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  // Warm Ivory screen surface (#F4F1E8)
  ctx.fillStyle = '#F4F1E8';
  ctx.fillRect(0, 0, w, h);

  // Subtle top status bar pill
  ctx.fillStyle = '#174C4A';
  ctx.beginPath();
  ctx.roundRect(w / 2 - 58, 28, 116, 26, 13);
  ctx.fill();

  // CampusFind Logo Mark in Deep Teal (#174C4A) & Terracotta (#D98252)
  const logoY = 175;
  ctx.strokeStyle = '#174C4A';
  ctx.lineWidth = 9;
  ctx.beginPath();
  ctx.arc(w / 2 - 10, logoY - 8, 34, 0, Math.PI * 2);
  ctx.stroke();

  ctx.fillStyle = '#D98252';
  ctx.beginPath();
  ctx.arc(w / 2 - 10, logoY - 8, 12, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = '#174C4A';
  ctx.lineCap = 'round';
  ctx.lineWidth = 10;
  ctx.beginPath();
  ctx.moveTo(w / 2 + 16, logoY + 18);
  ctx.lineTo(w / 2 + 40, logoY + 42);
  ctx.stroke();

  // Brand title
  ctx.fillStyle = '#174C4A';
  ctx.font = '700 44px system-ui, -apple-system, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('CampusFind', w / 2, 280);

  // Role Selector Tabs: Student Login | College Admin
  const padX = 48;
  const cardW = w - padX * 2;
  const tabY = 335;
  const tabH = 58;

  ctx.fillStyle = '#EAE4D5';
  ctx.beginPath();
  ctx.roundRect(padX, tabY, cardW, tabH, 12);
  ctx.fill();

  ctx.fillStyle = '#174C4A';
  ctx.beginPath();
  ctx.roundRect(padX + 6, tabY + 6, cardW / 2 - 8, tabH - 12, 9);
  ctx.fill();

  ctx.fillStyle = '#F4F1E8';
  ctx.font = '600 18px system-ui, -apple-system, sans-serif';
  ctx.fillText('Student Login', padX + cardW / 4, tabY + 35);

  ctx.fillStyle = '#4B5B59';
  ctx.font = '500 18px system-ui, -apple-system, sans-serif';
  ctx.fillText('College Admin', padX + (cardW * 3) / 4, tabY + 35);

  // Clean form fields
  const drawField = (y: number, label: string, placeholder: string) => {
    ctx.textAlign = 'left';
    ctx.fillStyle = '#174C4A';
    ctx.font = '600 16px system-ui, -apple-system, sans-serif';
    ctx.fillText(label, padX + 4, y);

    ctx.fillStyle = '#FFFFFF';
    ctx.strokeStyle = '#D5CEBD';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(padX, y + 12, cardW, 56, 10);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#7A8684';
    ctx.font = '400 16px system-ui, -apple-system, sans-serif';
    ctx.fillText(placeholder, padX + 18, y + 46);
  };

  drawField(442, 'College Institution', 'Mohamed Sathak A J College...');
  drawField(546, 'College Email ID', 'student@msajce-edu.in');
  drawField(650, 'Password', '••••••••••••');

  // Deep Teal Sign In button
  const btnY = 768;
  ctx.fillStyle = '#174C4A';
  ctx.beginPath();
  ctx.roundRect(padX, btnY, cardW, 60, 12);
  ctx.fill();

  ctx.textAlign = 'center';
  ctx.fillStyle = '#F4F1E8';
  ctx.font = '600 20px system-ui, -apple-system, sans-serif';
  ctx.fillText('Sign In', w / 2, btnY + 37);

  // Terracotta accent bar at bottom
  ctx.fillStyle = '#D98252';
  ctx.beginPath();
  ctx.roundRect(w / 2 - 48, h - 38, 96, 6, 3);
  ctx.fill();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = Math.min(8, maxAnisotropy);
  return tex;
}

function createGroundShadowTexture(): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(size / 2, size / 2, 6, size / 2, size / 2, size / 2);
  grad.addColorStop(0, 'rgba(23, 76, 74, 0.36)');
  grad.addColorStop(0.55, 'rgba(23, 76, 74, 0.14)');
  grad.addColorStop(1, 'rgba(23, 76, 74, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createLostSmartphone(
  renderer: THREE.WebGLRenderer,
  isSoftwareGl: boolean
): LostSmartphoneRig {
  const root = new THREE.Group();
  const geometries: THREE.BufferGeometry[] = [];
  const materials: THREE.Material[] = [];
  const textures: THREE.Texture[] = [];

  const trackGeo = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const trackMat = <T extends THREE.Material>(m: T): T => {
    materials.push(m);
    return m;
  };

  // Floor contact shadow (fades out as phone rises toward camera)
  const shadowTex = createGroundShadowTexture();
  textures.push(shadowTex);
  const shadowMat = trackMat(
    new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.72,
    })
  );
  const shadowMesh = new THREE.Mesh(trackGeo(new THREE.PlaneGeometry(0.46, 0.62)), shadowMat);
  shadowMesh.rotation.x = -Math.PI / 2;
  shadowMesh.position.y = 0.004;
  root.add(shadowMesh);

  // Subtle floor ripple when flashlight beam touches phone
  const groundRippleMat = trackMat(
    new THREE.ShaderMaterial({
      vertexShader: RIPPLE_VERTEX_SHADER,
      fragmentShader: GROUND_RIPPLE_FRAGMENT,
      uniforms: {
        uTime: { value: 0 },
        uScan: { value: 0 },
        uFade: { value: 1 },
      },
      transparent: true,
      depthWrite: false,
    })
  );
  const groundRippleMesh = new THREE.Mesh(trackGeo(new THREE.PlaneGeometry(2.2, 2.2)), groundRippleMat);
  groundRippleMesh.rotation.x = -Math.PI / 2;
  groundRippleMesh.position.y = 0.008;
  root.add(groundRippleMesh);

  // Smartphone assembly — starts lying flat on floor (y = 0.012, rotX = -PI/2), rises upright toward camera in Scene 4/5
  const phoneGroup = new THREE.Group();
  phoneGroup.position.set(0, 0.012, 0);
  phoneGroup.rotation.set(-Math.PI / 2, 0, -0.22);
  root.add(phoneGroup);

  const phoneW = 0.175;
  const phoneH = 0.355;
  const phoneD = 0.016;

  // Sleek anodized Deep Teal-charcoal frame
  const chassisMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x1a2c2b,
      metalness: 0.84,
      roughness: 0.22,
    })
  );

  const chassis = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(phoneW, phoneH, phoneD)), chassisMat);
  if (!isSoftwareGl) {
    chassis.castShadow = true;
    chassis.receiveShadow = true;
  }
  phoneGroup.add(chassis);

  // Terracotta subtle edge illumination when flashlight touches phone
  const edgeGeo = trackGeo(new THREE.EdgesGeometry(new THREE.BoxGeometry(phoneW + 0.004, phoneH + 0.004, phoneD + 0.002)));
  const edgeMat = trackMat(
    new THREE.LineBasicMaterial({
      color: 0xd98252,
      transparent: true,
      opacity: 0,
    })
  );
  const edgeLines = new THREE.LineSegments(edgeGeo, edgeMat);
  phoneGroup.add(edgeLines);

  // Front glass screen — starts dark and illuminates with the Warm Ivory CampusFind login interface
  const screenTex = createWarmPhoneLoginTexture(renderer.capabilities.getMaxAnisotropy());
  textures.push(screenTex);

  const screenMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x0a0e0e,
      map: screenTex,
      emissive: 0xffffff,
      emissiveMap: screenTex,
      emissiveIntensity: 0.0,
      roughness: 0.12,
      metalness: 0.18,
    })
  );
  const screenMesh = new THREE.Mesh(trackGeo(new THREE.PlaneGeometry(phoneW - 0.016, phoneH - 0.02)), screenMat);
  screenMesh.position.z = phoneD / 2 + 0.0014;
  phoneGroup.add(screenMesh);

  const screenCenterNode = new THREE.Object3D();
  screenCenterNode.position.set(0, 0, phoneD / 2 + 0.003);
  phoneGroup.add(screenCenterNode);

  // Warm local point light emitted when phone screen wakes
  const screenLight = new THREE.PointLight(0xfff1dc, 0, 4.0, 1.8);
  screenLight.position.set(0, 0.16, 0.08);
  root.add(screenLight);

  const screenCenterWorld = (out: THREE.Vector3) => {
    root.updateMatrixWorld(true);
    return screenCenterNode.getWorldPosition(out);
  };

  const update = (params: {
    elapsed: number;
    beamHit: number;
    loginReveal: number;
    scanIntensity: number;
    riseProgress: number;
  }) => {
    const { elapsed, beamHit, loginReveal, scanIntensity, riseProgress } = params;
    const r = THREE.MathUtils.clamp(riseProgress, 0, 1);
    const lit = THREE.MathUtils.clamp(loginReveal, 0, 1);

    // Smoothly lift phone off the corridor floor and rotate upright facing the camera
    phoneGroup.position.y = THREE.MathUtils.lerp(0.012, 1.02, r);
    phoneGroup.rotation.x = THREE.MathUtils.lerp(-Math.PI / 2, 0.0, r);
    phoneGroup.rotation.z = THREE.MathUtils.lerp(-0.22, 0.0, r);
    phoneGroup.scale.setScalar(THREE.MathUtils.lerp(1.0, 1.32, r));

    // Floor shadow & ground ripple fade gently as the phone rises
    shadowMat.opacity = 0.72 * (1 - r);
    groundRippleMat.uniforms.uTime.value = elapsed;
    groundRippleMat.uniforms.uScan.value = scanIntensity;
    groundRippleMat.uniforms.uFade.value = 1 - r;

    // Screen illuminates smoothly from dark glass to Warm Ivory CampusFind Login
    screenMat.color.setRGB(0.04 + lit * 0.96, 0.05 + lit * 0.95, 0.05 + lit * 0.95);
    screenMat.emissiveIntensity = beamHit * 0.14 + lit * 0.92;
    edgeMat.opacity = THREE.MathUtils.clamp(beamHit * 0.85 * (1 - r * 0.4), 0, 1);
    screenLight.position.set(0, phoneGroup.position.y + 0.06, 0.18);
    screenLight.intensity = beamHit * 0.5 + lit * 1.4;
  };

  const dispose = () => {
    geometries.forEach((g) => g.dispose());
    materials.forEach((m) => m.dispose());
    textures.forEach((t) => t.dispose());
  };

  return {
    root,
    screenCenterWorld,
    update,
    dispose,
  };
}
