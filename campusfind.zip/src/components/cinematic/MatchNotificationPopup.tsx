import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Calendar, Eye, MapPin, Smartphone, Sparkles, X } from 'lucide-react';
import { createRealisticStudentCharacter } from './RealisticStudentCharacter';
import type { CampusNotification } from '../../types/campusfind';

interface MatchNotificationPopupProps {
  notifications: CampusNotification[];
  onViewFoundDevice: (notification: CampusNotification) => void;
  onDismiss: (notification: CampusNotification) => void;
}

export function MatchNotificationPopup({
  notifications,
  onViewFoundDevice,
  onDismiss,
}: MatchNotificationPopupProps) {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const pointerRef = useRef({ x: 0, y: 0 });
  const [webglReady, setWebglReady] = useState(true);

  const activeNotification = notifications[0] ?? null;

  useEffect(() => {
    if (!activeNotification) return;
    const container = stageRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglReady(false);
      return;
    }

    const gl = renderer.getContext();
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    const gpuStr = dbg ? String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL)) : '';
    const isSoftwareGl = /SwiftShader|llvmpipe|Software/i.test(gpuStr);

    const w = container.clientWidth || 260;
    const h = container.clientHeight || 320;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, isSoftwareGl ? 1 : 2));
    renderer.setSize(w, h);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTarget = pmrem.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envTarget.texture;
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(30, w / Math.max(1, h), 0.1, 20);
    camera.position.set(0.05, 1.5, 1.46);
    camera.lookAt(0, 1.42, 0);

    const hemi = new THREE.HemisphereLight(0xfffaf2, 0xd8cfc0, 1.15);
    scene.add(hemi);

    const keyLight = new THREE.DirectionalLight(0xfff6e9, 1.75);
    keyLight.position.set(1.8, 2.8, 2.4);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xdce8e7, 0.7);
    fillLight.position.set(-2.0, 1.9, 1.6);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xf6d3b8, 0.55);
    rimLight.position.set(-0.9, 2.2, -1.8);
    scene.add(rimLight);

    const student = createRealisticStudentCharacter();
    student.root.position.set(0, 0, 0);
    student.root.rotation.y = -0.08;
    scene.add(student.root);

    let disposed = false;
    let frameId = 0;
    let lastTime = performance.now();
    const startTime = lastTime;

    const tick = () => {
      if (disposed) return;
      const now = performance.now();
      const elapsed = (now - startTime) / 1000;
      const delta = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      student.update(elapsed, delta, pointerRef.current.x, pointerRef.current.y, true);
      renderer.render(scene, camera);

      const afterDraw = performance.now();
      if (isSoftwareGl && afterDraw - now > 24) {
        window.setTimeout(() => {
          if (!disposed) frameId = requestAnimationFrame(tick);
        }, 16);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };
    frameId = requestAnimationFrame(tick);

    const onPointerMove = (ev: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      const nx = ((ev.clientX - rect.left) / Math.max(1, rect.width)) * 2 - 1;
      const ny = ((ev.clientY - rect.top) / Math.max(1, rect.height)) * 2 - 1;
      pointerRef.current.x = THREE.MathUtils.clamp(nx, -1, 1);
      pointerRef.current.y = THREE.MathUtils.clamp(ny, -1, 1);
    };
    window.addEventListener('pointermove', onPointerMove, { passive: true });

    const onResize = () => {
      if (!container || disposed) return;
      const cw = container.clientWidth || 260;
      const ch = Math.max(1, container.clientHeight || 320);
      camera.aspect = cw / ch;
      camera.updateProjectionMatrix();
      renderer.setSize(cw, ch);
    };
    window.addEventListener('resize', onResize);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('resize', onResize);
      student.dispose();
      envTarget.dispose();
      renderer.dispose();
    };
  }, [activeNotification?.id]);

  if (!activeNotification) return null;

  const deviceSummary = [
    activeNotification.found_brand,
    activeNotification.found_model,
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1C2524]/55 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="match-popup-heading"
    >
      <div className="w-full max-w-3xl rounded-2xl bg-[#FAF8F3] border border-[#E2DCCB] shadow-2xl overflow-hidden grid grid-cols-1 md:grid-cols-12 relative">
        <button
          type="button"
          onClick={() => onDismiss(activeNotification)}
          aria-label="Dismiss match notification"
          className="absolute top-3.5 right-3.5 z-20 p-1.5 rounded-lg text-[#55615F] hover:text-[#174C4A] hover:bg-[#EFEAE0] transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Left: Existing Realistic 3D College Student Character */}
        <div className="md:col-span-5 bg-[#EFEAE0] border-b md:border-b-0 md:border-r border-[#E2DCCB] flex flex-col items-center justify-end min-h-[240px] md:min-h-[340px] overflow-hidden">
          {webglReady ? (
            <div
              ref={stageRef}
              className="w-full h-[240px] md:h-[310px]"
              aria-label="CampusFind Student Guide"
            />
          ) : (
            <div className="w-full h-[240px] md:h-[310px] flex items-center justify-center p-6 text-center text-xs text-[#55615F]">
              CampusFind Match Alert
            </div>
          )}
          <div className="pb-3 text-center">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-[#174C4A]">
              CampusFind Match Alert
            </p>
          </div>
        </div>

        {/* Right: Speech Bubble & Found Device Summary */}
        <div className="md:col-span-7 p-6 sm:p-7 flex flex-col justify-between gap-5">
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#D98252]">
              <Sparkles className="w-4 h-4 shrink-0" />
              <span>
                Possible Match Detected
                {notifications.length > 1 ? ` (1 of ${notifications.length})` : ''}
              </span>
            </div>

            <div className="rounded-xl bg-[#F4F1E8] border border-[#E2DCCB] p-4 space-y-1.5">
              <h2
                id="match-popup-heading"
                className="font-display text-lg sm:text-xl font-bold text-[#174C4A] leading-snug"
              >
                Good news! A possible match for your lost device has been found.
              </h2>
              <p className="text-xs text-[#55615F] leading-relaxed">
                Open the found device report below to review all details and confirm whether this
                device belongs to you.
              </p>
            </div>

            {/* Genuine Found Device Snapshot */}
            <div className="rounded-xl bg-white border border-[#E2DCCB] p-4 space-y-2.5 text-xs">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-mono-tabular text-[11px] text-[#55615F]">
                    {activeNotification.found_report_code ||
                      (activeNotification.related_found_item_id
                        ? `Found Report #${activeNotification.related_found_item_id}`
                        : 'Found Report')}
                  </p>
                  <p className="text-sm font-bold text-[#174C4A] mt-0.5 truncate">
                    {activeNotification.found_title || 'Found Electronic Device'}
                  </p>
                </div>
                {activeNotification.found_device_type && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#174C4A]/10 text-[#174C4A] font-semibold shrink-0">
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>{activeNotification.found_device_type}</span>
                  </span>
                )}
              </div>

              {deviceSummary && (
                <p className="text-[#1C2524]">
                  <span className="font-semibold text-[#55615F]">Brand / Model:</span>{' '}
                  {deviceSummary}
                  {activeNotification.found_color ? ` · ${activeNotification.found_color}` : ''}
                </p>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-[#55615F]">
                <p className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#D98252] shrink-0" />
                  <span className="truncate">
                    {activeNotification.found_location || 'Location not provided'}
                  </span>
                </p>
                <p className="flex items-center gap-1.5 font-mono-tabular">
                  <Calendar className="w-3.5 h-3.5 text-[#D98252] shrink-0" />
                  <span>{activeNotification.found_date || 'Date not provided'}</span>
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 pt-1">
            <button
              type="button"
              onClick={() => onViewFoundDevice(activeNotification)}
              className="w-full sm:flex-1 h-11 px-4 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold hover:bg-[#123D3B] transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <Eye className="w-4 h-4" />
              <span>VIEW FOUND DEVICE</span>
            </button>
            <button
              type="button"
              onClick={() => onDismiss(activeNotification)}
              className="w-full sm:w-auto h-11 px-5 rounded-xl bg-white border border-[#D8D0BE] text-xs font-semibold text-[#55615F] hover:text-[#174C4A] hover:border-[#174C4A] transition-colors cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
