import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Loader2, X } from 'lucide-react';
import { createRealisticStudentCharacter } from './RealisticStudentCharacter';

interface CharacterConfirmModalProps {
  open: boolean;
  question: string;
  details?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  busy?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export function CharacterConfirmModal({
  open,
  question,
  details,
  confirmLabel = 'YES',
  cancelLabel = 'NO',
  busy = false,
  onConfirm,
  onCancel,
}: CharacterConfirmModalProps) {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const confirmBtnRef = useRef<HTMLButtonElement | null>(null);
  const pointerRef = useRef({ x: 0, y: 0 });
  const [webglReady, setWebglReady] = useState(true);

  useEffect(() => {
    if (!open) return;
    confirmBtnRef.current?.focus();

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !busy) {
        e.preventDefault();
        onCancel();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, busy, onCancel]);

  useEffect(() => {
    if (!open) return;
    const container = stageRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    } catch {
      setWebglReady(false);
      return;
    }

    const gl = renderer.getContext();
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    const gpuStr = dbg ? String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL)) : '';
    const isSoftwareGl = /SwiftShader|llvmpipe|Software/i.test(gpuStr);

    const w = container.clientWidth || 220;
    const h = container.clientHeight || 250;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, isSoftwareGl ? 1 : 2));
    renderer.setSize(w, h);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.04;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTarget = pmrem.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envTarget.texture;
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(30, w / Math.max(1, h), 0.1, 20);
    camera.position.set(0.05, 1.5, 1.48);
    camera.lookAt(0, 1.41, 0);

    const hemi = new THREE.HemisphereLight(0xfffaf2, 0xd8cfc0, 1.2);
    scene.add(hemi);

    const keyLight = new THREE.DirectionalLight(0xfff6e9, 1.7);
    keyLight.position.set(1.8, 2.7, 2.3);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xdce8e7, 0.65);
    fillLight.position.set(-2.0, 1.8, 1.5);
    scene.add(fillLight);

    const student = createRealisticStudentCharacter();
    student.root.position.set(0, 0, 0);
    student.root.rotation.y = -0.08;
    scene.add(student.root);

    let disposed = false;
    let frameId = 0;
    let lastTime = performance.now();
    const startTime = lastTime;

    const tick = () => {
      if (disposed) return;
      const now = performance.now();
      const elapsed = (now - startTime) / 1000;
      const delta = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      student.update(elapsed, delta, pointerRef.current.x, pointerRef.current.y, true);
      renderer.render(scene, camera);

      const afterDraw = performance.now();
      if (isSoftwareGl && afterDraw - now > 24) {
        window.setTimeout(() => {
          if (!disposed) frameId = requestAnimationFrame(tick);
        }, 16);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };
    frameId = requestAnimationFrame(tick);

    const onPointerMove = (ev: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      const nx = ((ev.clientX - rect.left) / Math.max(1, rect.width)) * 2 - 1;
      const ny = ((ev.clientY - rect.top) / Math.max(1, rect.height)) * 2 - 1;
      pointerRef.current.x = THREE.MathUtils.clamp(nx, -1, 1);
      pointerRef.current.y = THREE.MathUtils.clamp(ny, -1, 1);
    };
    window.addEventListener('pointermove', onPointerMove, { passive: true });

    const onResize = () => {
      if (!container || disposed) return;
      const cw = container.clientWidth || 220;
      const ch = Math.max(1, container.clientHeight || 250);
      camera.aspect = cw / ch;
      camera.updateProjectionMatrix();
      renderer.setSize(cw, ch);
    };
    window.addEventListener('resize', onResize);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('resize', onResize);
      student.dispose();
      envTarget.dispose();
      renderer.dispose();
    };
  }, [open]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1C2524]/45 backdrop-blur-[2px] animate-[fadeIn_160ms_ease-out]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="character-confirm-title"
    >
      <div className="relative w-full max-w-xl rounded-2xl bg-[#FAF8F3] border border-[#DFD8C8] shadow-[0_24px_60px_rgba(23,76,74,0.22)] overflow-hidden grid grid-cols-1 sm:grid-cols-12">
        <button
          type="button"
          disabled={busy}
          onClick={onCancel}
          aria-label="Close confirmation dialog"
          className="absolute top-3 right-3 z-10 p-1.5 rounded-lg text-[#55615F] hover:text-[#174C4A] hover:bg-[#EDE8DC] disabled:opacity-50 cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Left: Existing Realistic 3D College Student */}
        <div className="sm:col-span-5 bg-[#EFEAE0] border-b sm:border-b-0 sm:border-r border-[#E2DCCB] flex items-end justify-center min-h-[210px] sm:min-h-[260px]">
          {webglReady ? (
            <div ref={stageRef} className="w-full h-[210px] sm:h-[260px]" aria-hidden="true" />
          ) : (
            <div className="p-6 text-center text-xs font-semibold text-[#174C4A]">
              CampusFind Confirmation
            </div>
          )}
        </div>

        {/* Right: Speech Prompt & Accessible YES / NO Controls */}
        <div className="sm:col-span-7 p-6 flex flex-col justify-center space-y-5">
          <div className="space-y-2 pr-4">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-[#D98252]">
              Confirm Action
            </p>
            <h2
              id="character-confirm-title"
              className="font-display text-lg font-bold text-[#174C4A] leading-snug"
            >
              {question}
            </h2>
            {details && (
              <p className="text-xs text-[#55615F] leading-relaxed">{details}</p>
            )}
          </div>

          <div className="flex items-center gap-3 pt-1">
            <button
              ref={confirmBtnRef}
              type="button"
              disabled={busy}
              onClick={onConfirm}
              className="flex-1 h-10 px-4 rounded-xl bg-[#174C4A] text-[#F4F1E8] text-xs font-semibold hover:bg-[#123D3B] disabled:opacity-60 flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              {busy && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              <span>{confirmLabel}</span>
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={onCancel}
              className="flex-1 h-10 px-4 rounded-xl bg-[#F4F1E8] border border-[#D98252] text-[#174C4A] text-xs font-semibold hover:bg-[#D98252]/12 disabled:opacity-60 transition-colors cursor-pointer"
            >
              {cancelLabel}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
