export type LoginRole = 'user' | 'admin';

export type ItemLifecycleStatus =
  | 'submitted'
  | 'under_review'
  | 'possible_match'
  | 'verified'
  | 'recovered'
  | 'closed';

export interface CollegeSummary {
  id: number;
  code: string;
  name: string;
  city: string;
  address: string;
  domain: string;
  adminEmail?: string;
  studentAccessEnabled?: boolean;
  hasInitialPassword?: boolean;
  latitude: number;
  longitude: number;
  mapsUrl?: string;
  isPrimary?: boolean;
  zones?: string[];
  departments?: string[];
  academicYears?: string[];
}

export interface AuthUser {
  id: number;
  collegeId: number;
  collegeCode: string;
  role: LoginRole;
  identifier: string;
  studentId: string | null;
  fullName: string;
  department: string;
  academicYear?: string;
  firstLoginCompleted: boolean;
  profileCompleted: boolean;
}

export interface DashboardStats {
  missingTotal: number;
  missingOpen: number;
  foundTotal: number;
  foundOpen: number;
  resolvedItems: number;
  pendingVerification: number;
  recoveryRate: number;
  activeMatches: number;
  claimedMatches: number;
  totalMatches: number;
  registeredStudents: number;
  myLostCount: number;
  myFoundCount: number;
  myRecoveredCount: number;
  unreadNotifications: number;
}

export interface CampusItem {
  id: number;
  college_id: number;
  reporter_user_id: number;
  type: 'missing' | 'found';
  title: string;
  category: string;
  device_type: string;
  brand: string;
  model: string;
  color?: string;
  location: string;
  latitude: number | null;
  longitude: number | null;
  description: string;
  additional_info: string;
  image_data: string | null;
  status: 'open' | 'matched' | 'resolved' | 'archived';
  lifecycle_status: ItemLifecycleStatus;
  report_code: string;
  reported_date: string;
  reported_time: string;
  created_at: string;
  reporter_name: string;
  reporter_identifier: string;
  reporter_department: string;
}

export interface FoundDeviceDetails {
  id: number;
  reportCode: string;
  type: 'missing' | 'found';
  title: string;
  category: string;
  deviceType: string;
  brand: string;
  model: string;
  color: string;
  description: string;
  additionalInfo: string;
  imageData: string | null;
  location: string;
  latitude: number | null;
  longitude: number | null;
  reportedDate: string;
  reportedTime: string;
  lifecycleStatus: ItemLifecycleStatus;
  status: 'open' | 'matched' | 'resolved' | 'archived';
  createdAt: string;
  institutionName: string;
  institutionCode: string;
  reporter: {
    name: string;
    department: string;
    academicYear: string;
  };
}

export type MatchWorkflowStatus =
  | 'POSSIBLE_MATCH'
  | 'MATCH_ACCEPTED'
  | 'MATCH_REJECTED'
  | 'HANDOVER_PENDING'
  | 'RECOVERED';

export interface CampusMatch {
  id: number;
  confidence: number;
  status: 'pending' | 'verified' | 'claimed' | 'dismissed';
  workflow_status: MatchWorkflowStatus;
  notes: string;
  created_at: string;
  accepted_by_user_id?: number | null;
  accepted_at?: string | null;
  rejected_by_user_id?: number | null;
  rejected_at?: string | null;
  lost_owner_handover_confirmed?: number;
  lost_owner_handover_at?: string | null;
  found_owner_handover_confirmed?: number;
  found_owner_handover_at?: string | null;
  recovered_at?: string | null;
  missing_item_id: number;
  missing_report_code?: string;
  missing_title: string;
  missing_device_type?: string;
  missing_category: string;
  missing_location: string;
  missing_date: string;
  missing_image?: string | null;
  missing_lifecycle_status?: ItemLifecycleStatus;
  missing_reporter_name: string;
  missing_reporter_user_id?: number;
  found_item_id: number;
  found_report_code?: string;
  found_title: string;
  found_location: string;
  found_date: string;
  found_image?: string | null;
  found_lifecycle_status?: ItemLifecycleStatus;
  found_reporter_name: string;
  found_reporter_user_id?: number;
}

export interface CollegeMember {
  id: number;
  identifier: string;
  student_id: string | null;
  full_name: string;
  department: string;
  academic_year?: string;
  is_authorized: number;
  first_login_completed: number;
  profile_completed?: number;
  created_at: string;
  report_count: number;
}

export interface StudentActivityRecord {
  id: number;
  user_id: number;
  student_email: string;
  student_name: string | null;
  action_type: 'login' | 'lost_report_submitted' | 'found_report_submitted' | 'password_changed';
  summary: string;
  related_item_id: number | null;
  created_at: string;
}

export interface CampusNotification {
  id: number;
  title: string;
  message: string;
  related_match_id: number | null;
  notification_type?: string;
  related_lost_item_id?: number | null;
  related_found_item_id?: number | null;
  found_title?: string | null;
  found_device_type?: string | null;
  found_brand?: string | null;
  found_model?: string | null;
  found_color?: string | null;
  found_location?: string | null;
  found_date?: string | null;
  found_report_code?: string | null;
  match_workflow_status?: MatchWorkflowStatus | null;
  match_accepted_at?: string | null;
  lost_owner_handover_confirmed?: number | null;
  found_owner_handover_confirmed?: number | null;
  match_recovered_at?: string | null;
  is_read: number;
  created_at: string;
}

export interface LocationHotspot {
  location: string;
  missing_count: number;
  found_count: number;
  recovered_count: number;
  avg_lat: number | null;
  avg_lng: number | null;
}

export interface MonthlyLocationStat {
  month: string;
  missing_count: number;
  found_count: number;
  recovered_count: number;
}

export interface DeviceBreakdownStat {
  device_type: string;
  total: number;
  recovered: number;
}

export interface AiComparisonResponse {
  confidence: number;
  visualCharacteristics: string[];
  reasoning: string;
  requiresHumanVerification: boolean;
  usedImages: boolean;
}

export interface RealtimeMessage {
  event: string;
  timestamp: string;
  [key: string]: unknown;
}

export interface BeamScreenState {
  x: number;
  y: number;
  intensity: number;
  radius: number;
  logoReveal: number;
  headingReveal: number;
  panelReveal: number;
  fullReveal: number;
  worldDarkness: number;
  phase: 'white-studio' | 'entering' | 'activating' | 'sweeping' | 'complete';
}
