# CampusFind — Intelligent Matching, Character Notifications & Mandatory Profile Setup Plan

This incremental update adds **intelligent multi-signal Lost & Found matching**, a **realistic 3D character match notification popup**, a **complete Found Device detail view**, and **mandatory post-login student profile completion** (triggered after both YES and NO password choices) while preserving the existing cinematic 3D flashlight login, dashboards, palette, and all stored database records.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Zero Redesign & Zero Data Loss**: All database updates use safe additive columns (`ALTER TABLE ... ADD COLUMN` only when absent). No tables are dropped or reset, no sample data is generated, and the existing 3D flashlight login, walking human intro, Warm Ivory / Deep Teal / Terracotta theme, and 5-item Admin navigation remain untouched.

- **Multi-Signal Matching Threshold**: Matching will NEVER trigger on device category alone. A possible match requires matching device category **plus** corroborating evidence across brand, model, colour, description keywords, location, and date proximity (with AI Vision refinement when photos are uploaded). Duplicate notifications for the same `(lost_report_id, found_report_id)` pair are strictly prevented.
- **Privacy on Found Device Details**: Clicking **VIEW FOUND DEVICE** shows full genuine device details, found location/date/time, report ID, institution, and the finder's approved public academic profile (**Name**, **Department**, **Academic Year**), while strictly withholding private credentials, passwords, email addresses, and phone numbers.
- **Mandatory Profile Completion Flow**: Selecting **NO** on *"Would you like to change your initial password?"* keeps the initial password intact and proceeds directly to mandatory profile setup (**Student Name**, **Department**, **Academic Year**). Selecting **YES** updates the password securely and then proceeds to the same mandatory profile setup. Once `profile_completed = true`, students are never asked again on future logins.

---

## 1. Overview & Core Concept

- **What It Does**: Connects lost and found reports across different student accounts in the same institution through an automated multi-signal matching engine, notifies the original lost-report owner on login via the existing realistic 3D student character, lets them inspect complete genuine found-device details, and ensures every student completes their real academic profile on first onboarding.
- **Target Audience**: Authorized MSAJCE students (`@msajce-edu.in`) and MSAJCE college administrators.
- **Key Value**: Turns CampusFind from a passive listing board into an active, privacy-safe recovery system backed 100% by genuine database records.

---

## 2. User Experience & Visual Design

- **Visual Identity Preserved**: 100% continuity with existing Warm Ivory (`#F4F1E8` / `#FAF8F3`), Deep Teal (`#174C4A`), and Terracotta (`#D98252`) surfaces, typography, and layout.
- **Key User Flows**:
  1. **Mandatory Post-Login Onboarding (Zero Login Loops)**:
     - Student signs in -> if initial password choice is pending, the existing realistic 3D student character asks *"Would you like to change your initial password?"* (**YES** / **NO**).
     - **YES** -> collects & validates `New Password` + `Confirm New Password`, updates bcrypt hash -> transitions seamlessly to **Profile Setup**.
     - **NO** -> preserves initial password -> transitions directly to **Profile Setup**.
     - **Profile Setup**: Character prompts *"Before entering CampusFind, let's complete your student profile."* -> mandatory **Student Name**, **Department** (MSAJCE institution dropdown), and **Academic Year** (institution dropdown) -> saves `profile_completed = 1` -> displays personalized welcome with the student's actual name -> enters Student Dashboard.
  2. **Report Submission with Colour & Intelligent Matching**:
     - Student A submits a Lost report (including new **Colour** field) -> saved to Common Lost & Found.
     - Student B submits a matching Found report -> saved to Common Found Devices -> backend matching engine compares active institution lost reports across category, brand, model, colour, description, location, date, and optional image -> stores a `possible_match` record (deduplicated per pair) and creates an unread `match_found` notification for Student A.
  3. **Character Match Notification Popup & Found Device Detail View**:
     - When Student A logs in (or receives a live SSE event) and has an unread `match_found` notification, the realistic 3D student character appears cleanly saying: *"Hey! Good news! We found a possible match for your lost device."* along with the found device's category, brand, model, found location, and date found.
     - Clicking **VIEW FOUND DEVICE** marks the notification read and opens the **Found Device Detail Modal** showing complete genuine Device Info, Found Report Info, Finder's Public Profile (Name, Department, Academic Year), Report ID/Institution, and a **"View on Campus Map"** button (only if valid coordinates exist).
     - Clicking **Dismiss** marks the notification read so it never interrupts future logins, while keeping it accessible inside the **Notifications** tab.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Weighted Multi-Signal Matching Algorithm (No Category-Only False Positives)**
  - *Chosen Approach*: Require same institution + opposite type + same `device_type`, then compute a weighted confidence score from Brand (+28), Model (+26), Colour (+18), Description/Title token overlap (up to +20), Location match (+12), and Date proximity (+8), optionally refined by Gemini Vision when images are present. Trigger a possible match only when corroborating non-category evidence reaches the threshold (`>= 40` corroborating score) and the pair does not already exist in `matches`.
  - *Why*: Prevents false alerts when two students report unrelated smartphones while reliably catching genuine matches like two Black Samsung Galaxy A phones at the College Library.

- **Decision 2 — Reuse Existing 3D Character Rig Across Onboarding & Match Popups**
  - *Chosen Approach*: Reuse the existing realistic 3D male college student character (`RoomEnvironment` lighting, natural breathing, blinking, eye-contact, software-GL pacing) inside the new Match Notification Popup.
  - *Why*: Consistent visual identity, zero cartoon assets, and zero duplicate 3D code.

- **Decision 3 — Institution-Configured Departments & Academic Years**
  - *Chosen Approach*: Store `departments_json` and `academic_years_json` on the `colleges` table (populated with MSAJCE's actual engineering & architecture departments and academic years) rather than hardcoding a single global list.
  - *Why*: Cleanly supports institution-specific configuration while keeping MSAJCE as the sole active institution.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────────┐
│                         EXISTING REACT FRONTEND                            │
│                                                                            │
│  [Untouched] Cinematic 3D Flashlight Intro & Login Forms                   │
│                                                                            │
│  ┌────────────────────────────────────┐  ┌───────────────────────────────┐ │
│  │ Post-Login Onboarding (3D Guide)   │  │ Student Dashboard             │ │
│  │ 1. Password YES / NO               │  │ • Match Notification Popup    │ │
│  │    ├─ YES -> New/Confirm Password  │  │   (Unread match_found only)   │ │
│  │    └─ NO  -> Keep Initial Password │  │ • Found Device Detail Modal   │ │
│  │ 2. Mandatory Profile Setup         │  │   (Public finder profile +    │ │
│  │    (Name, Dept, Academic Year)     │  │    optional real map link)    │ │
│  │ 3. Personalized Welcome -> Portal  │  │ • Lost & Found + Colour field │ │
│  └─────────────────┬──────────────────┘  │ • Notifications + Profile     │ │
│                    │                     └──────────────┬────────────────┘ │
└────────────────────┼────────────────────────────────────┼──────────────────┘
                     │ REST + Real-Time SSE               │
                     ▼                                    ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                      EXPRESS + SQLITE BACKEND                              │
│  • Additive Migrations (no drops/resets):                                  │
│      colleges: + departments_json, academic_years_json                     │
│      users:    + academic_year, profile_completed                          │
│      items:    + color                                                     │
│      notifications: + notification_type, related_lost_item_id,             │
│                       related_found_item_id                                │
│  • Intelligent Matching Engine on POST /api/items (multi-signal + dedupe)  │
│  • POST /api/profile/complete (mandatory Name, Dept, Academic Year)        │
│  • GET  /api/items/:id/details (complete genuine details, privacy-safe)    │
│  • GET  /api/notifications (enriched with match & found-device summary)    │
└────────────────────────────────────────────────────────────────────────────┘
```

### Potential Risks & Mitigations
- **Existing Student Accounts**: Existing accounts with `first_login_completed = 1` will only see Step 2 (Profile Setup) once if `profile_completed = 0`, and never see the password prompt again — preventing any login loop.
- **Zero Impact on Existing Features**: Cinematic 3D flashlight login, walking human intro, Admin 5-item navigation, MSAJCE-only lock, real-coordinate Campus Map, and existing database records remain completely preserved.

### Verification Plan (Post-Approval)
All 13 mandatory tests (Common Lost/Found visibility, Multi-signal Intelligent Match, Character Match Notification Popup, Complete Found Device Details, No-Match silence, Duplicate Match/Notification prevention, Password YES -> Profile Setup, Password NO -> Profile Setup, Profile Persistence without re-prompting, Map Real-Data Integrity, and Existing Design Preservation) will be verified end-to-end, with temporary test rows cleaned up afterward.
